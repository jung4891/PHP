<?php
error_reporting(E_ALL);
header("Content-type: text/html; charset=utf-8");

class Maintain extends CI_Controller {

	var $id = '';

	function __construct() {
		parent::__construct();
		$this->id = $this->phpsession->get( 'id', 'stc' );
		$this->name = $this->phpsession->get( 'name', 'stc' );
		$this->lv = $this->phpsession->get( 'lv', 'stc' );
                $this->company = $this->phpsession->get( 'company', 'stc' );

		$this->cnum = $this->phpsession->get( 'cnum', 'stc' );
	}

	//포캐스팅 리스트(공통)
	function maintain_list() {
		if( $this->id === null ) {
			redirect( 'account' );
		}

		$this->load->Model(array('STC_Maintain', 'STC_Common'));
//		$cur_page = $this->input->get( 'cur_page' );			//	현재 페이지
		if(isset($_GET['cur_page'])) { 
			$cur_page = $_GET['cur_page'];
		} 
		else { 
			$cur_page = 0; 
		}														//	현재 페이지
		$no_page_list = 10;										//	한페이지에 나타나는 목록 개수

		if(isset($_GET['searchkeyword'])) { 
			$search_keyword = $_GET['searchkeyword'];
		} 
		else { 
			$search_keyword = "";
		}
		
//		if(isset($_GET['search1'])) { 
//			$search1 = $_GET['search1'];
//		} 
//		else { 
//			$search1 = "";
//		}
		
		$search1 = "";
		if(isset($_GET['search2'])) { 
			$search2 = $_GET['search2'];
		} 
		else { 
			$search2 = "";
		}

		$data['search_keyword'] = $search_keyword;
//		$data['search1'] = $search1;
		$data['search2'] = $search2;
		
		if  ( $cur_page <= 0 )
			$cur_page = 1;
		
		$data['cur_page'] = $cur_page;

		$user_list_data = $this->STC_Maintain->maintain_list($search_keyword, $search1, $search2, ( $cur_page - 1 ) * $no_page_list, $no_page_list, $this->cnum);
		$data['count'] = $this->STC_Maintain->maintain_list_count($search_keyword, $search1, $search2, $this->cnum)->ucount;
		
		$data['list_val'] = $user_list_data['data'];
		$data['list_val_count'] = $user_list_data['count'];
		
		$total_page = 1;
		if  ( $data['count'] % $no_page_list == 0 )
			$total_page = floor( ( $data['count'] / $no_page_list ) );
		else
			$total_page = floor( ( $data['count'] / $no_page_list + 1 ) );			//	전체 페이지 개수

		$start_page =  floor(($cur_page - 1 ) / 10) * 10  + 1 ;
		$end_page = 0;
		if  ( floor( ( $cur_page - 1 ) / 10 ) < floor( ( $total_page - 1 ) / 10 ) )
			$end_page = ( floor( ( $cur_page - 1 ) / 10 ) + 1 ) * 10;
		else
			$end_page = $total_page;
		
		$data['category'] = $this->STC_Common->get_category();

		$data['no_page_list'] = $no_page_list;
		$data['total_page'] = $total_page;
		$data['start_page'] = $start_page;
		$data['end_page'] = $end_page;
		$data['cnum'] = $this->cnum;
		
		$this->load->view( 'maintain_list', $data );
	}
	
	
	//포캐스팅 입력/수정 처리
	function maintain_input_action() {
		if( $this->id === null ) {
			redirect( 'account' );
		}
		
		$this->load->model( 'STC_Maintain' );
		$seq = $this->input->post('seq');

		$customer_companyname = $this->input->post('customer_companyname');
		$customer_username = $this->input->post('customer_username');
		$customer_tel = $this->input->post('customer_tel');
		$customer_email = $this->input->post('customer_email');
		$project_name = $this->input->post('project_name');
		$progress_step = $this->input->post('progress_step');
		$cooperation_companyname = $this->input->post('cooperation_companyname');
		$cooperation_username = $this->input->post('cooperation_username');
		$cooperation_tel = $this->input->post('cooperation_tel');
		$cooperation_email = $this->input->post('cooperation_email');
		$exception_saledate = trim($this->input->post('exception_saledate'));
		$exception_saledate2 = trim($this->input->post('exception_saledate2'));
		$complete_status = $this->input->post('complete_status');
		
		$main_array = $this->input->post('main_array');
		$product_array = $this->input->post('product_array');
//		print "<pre>";
//		print_r($product_array);
//		print "</pre>";
//		exit;

//		echo "seq::".$seq."<br>";
//		echo "customer_companyname::".$customer_companyname."<br>";
//		echo "customer_username::".$customer_username."<br>";
//		echo "customer_tel::".$customer_tel."<br>";
//		echo "customer_email::".$customer_email."<br>";
//		echo "project_name::".$project_name."<br>";
//		echo "progress_step::".$progress_step."<br>";
//		echo "cooperation_companyname::".$cooperation_companyname."<br>";
//		echo "cooperation_username::".$cooperation_username."<br>";
//		echo "cooperation_tel::".$cooperation_tel."<br>";
//		echo "cooperation_email::".$cooperation_email."<br>";
//		echo "exception_saledate::".$exception_saledate."<br>";
//		echo "complete_status::".$complete_status."<br>";
//
//		echo "main_companyname::".$main_companyname."<br>";
//		echo "main_username::".$main_username."<br>";
//		echo "main_tel::".$main_tel."<br>";
//		echo "main_email::".$main_email."<br>";
//
//		echo "product_company::".$product_company."<br>";
//		echo "product_item::".$product_item."<br>";
//		echo "product_name::".$product_name."<br>";
//		echo "product_count::".$product_count."<br>";
//		exit;
		
		// 기본
		$data = array(
			'customer_companyname' => $customer_companyname,
			'customer_username' => $customer_username,
			'customer_tel' => $customer_tel,
			'customer_email' => $customer_email,
			'project_name' => $project_name,
			'progress_step' => $progress_step,
			'cooperation_companyname' => $cooperation_companyname,
			'cooperation_username' => $cooperation_username,
			'cooperation_tel' => $cooperation_tel,
			'cooperation_email' => $cooperation_email,
			'exception_saledate' => $exception_saledate,
			'exception_saledate2' => $exception_saledate2,
			'complete_status' => $complete_status,
			'write_id' => $this->id,
			'main_array' => $main_array,
			'product_array' => $product_array
		);

print_r($data);
		if ($seq == null) {
			$result = $this->STC_Maintain->maintain_insert($data, $mode = 1);
		} else {
			$result = $this->STC_Maintain->maintain_insert($data, $mode = 1, $seq);
		}
		
		if($result) {
			echo "<script>alert('정상적으로 처리되었습니다.');location.href='".site_url()."/maintain/maintain_list'</script>";
		} else {
			echo "<script>alert('정상적으로 처리되지 못했습니다. 다시 입력해 주세요.');history.go(-1);</script>";
		}
		
	}

	// 포캐스팅 쓰기 뷰
	function maintain_input() {
		if( $this->id === null ) {
			redirect( 'account' );
		}

		$this->load->Model(array('STC_Maintain', 'STC_Common'));
		$data['product'] = $this->STC_Common->get_product();   //제조사, 품목, 제품명
		$this->load->view( 'maintain_input', $data);
	}

	// 포캐스팅 수정 뷰
	function maintain_view() {
		if( $this->id === null ) {
			redirect( 'account' );
		}

		$this->load->Model(array('STC_Maintain', 'STC_Common'));
//		$user_id = $this->idx;
		
		$seq = $this->input->get( 'seq' );
		$mode = $this->input->get( 'mode' );
		
		$data['view_val'] = $this->STC_Maintain->maintain_view($seq);		//기본
		$data['view_val2'] = $this->STC_Maintain->maintain_view2($seq);		//주사업자
		$data['view_val3'] = $this->STC_Maintain->maintain_view3($seq);		//제품명
		$data['clist_val'] = $this->STC_Maintain->maintain_comment_list($seq);	//코멘트
		
		$data['product'] = $this->STC_Common->get_product();	//제조사, 품목, 제품명
	
//		print "<pre>";
//		print_r($data);
//		print "</pre>";
//		echo "----------<br>";
//		print "<pre>";
//		print_r($view_val2);
//		print "</pre>";
//		echo "----------<br>";
//		print "<pre>";
//		print_r($view_val3);
//		print "</pre>";
//		exit;

		$data['seq'] = $seq;
		
		//print_r($data);

		$this->load->view( 'maintain_modify', $data );
	}
	
	// 포캐스팅 삭제
	function maintain_delete_action() {
		if( $this->id === null ) {
			redirect( 'account' );
		}

		$this->load->helper('alert');
		$this->load->model( 'STC_Maintain' );
		$seq = $this->input->post( 'seq' );

		if ($seq != null) {
			$tdata = $this->STC_Maintain->maintain_delete($seq);
		} 
		
		if ($tdata) {
			echo "<script>alert('삭제완료 되었습니다.');location.href='".site_url()."/maintain/maintain_list'</script>";
		} else {
			alert("정상적으로 처리되지 못했습니다.\n다시 시도해 주세요.");
		}
	}

	//포캐스팅 코멘트 등록 처리
	function maintain_comment_action() {
		if( $this->id === null ) {
			redirect( 'account' );
		}

		$this->load->Model(array('STC_Maintain', 'STC_Common'));
		
		$data = array(
			'maintain_seq' => $this->input->post('seq'),
			'user_id' => $this->id,
			'user_name' => $this->name,
			'contents' => $this->input->post('comment'),
			'insert_date' => date("Y-m-d H:i:s")
		);
		
		$result = $this->STC_Maintain->maintain_comment_insert($data);
		$result2 = $this->STC_Maintain->maintain_cnum_update($this->input->post('seq'));
		
		if($result && $result2) {
			echo "<script>alert('정상적으로 처리되었습니다.');history.go(-1);</script>";
		} else {
			echo "<script>alert('정상적으로 처리되지 못했습니다. 다시 입력해 주세요.');history.go(-1);</script>";
		}
		
	}

	// 포캐스팅 코멘트 삭제처리
	function maintain_comment_delete() {
		if( $this->id === null ) {
			redirect( 'account' );
		}

		$this->load->helper('alert');
		$this->load->model( 'STC_Maintain' );
		$seq = $this->input->post( 'seq' );
		$cseq = $this->input->post( 'cseq' );
		
		if ($seq != null && $cseq != null) {
			$tdata = $this->STC_Maintain->maintain_comment_delete($seq, $cseq);
			$result = $this->STC_Maintain->maintain_cnum_update2($this->input->post('seq'));
		} 
		
		if ($tdata && $result) {
			echo "<script>alert('삭제완료 되었습니다.');history.go(-1);</script>";
		} else {
			alert("정상적으로 처리되지 못했습니다.\n다시 시도해 주세요.");
		}
	}
}
?>
