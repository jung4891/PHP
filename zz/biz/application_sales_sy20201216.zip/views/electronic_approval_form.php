<?php
  include $this->input->server('DOCUMENT_ROOT')."/include/base.php";
  include $this->input->server('DOCUMENT_ROOT')."/include/sales_top.php";
  $mode = $_GET['mode'];
?>
<style>
   p, div, span, a, a:hover, a:visited, a:active, label, input, h1,h2,h3,h4,h5,h6{font-family: "Noto Sans KR";}
   .tabs {position: relative;margin: 35px auto;width: 600px;}
   .tabs_input {position: absolute;z-index: 1000;width: 120px;height: 35px;left: 0px;top: 0px;opacity: 0;-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";filter: alpha(opacity=0);}
   .tabs_input:not(:checked) {cursor: pointer;}
   .tabs_input:not(:checked) + label {color:#fff;}
   .tabs_input:not(:checked) + label {background: #f8f8f9;color:#777;z-index: 6;}
   .tabs_input:hover + label {background: #666666;color:#fff;}
   .tabs_input#tab-2{left: 120px;}
   .tabs_input#tab-3{left: 240px;}
   .tabs_input#tab-4{left: 360px;}
   .tabs_input.tab-selector-1:checked ~ .content .content-1,
   .tabs_input.tab-selector-2:checked ~ .content .content-2,
   .tabs_input.tab-selector-3:checked ~ .content .content-3,
   .tabs_input.tab-selector-4:checked ~ .content .content-4 
   {z-index: 100;filter: alpha(opacity=100);opacity: 1;}

   .tabs label {background:#666666;color:#fff;font-size: 14px;line-height: 35px;height: 35px;position: relative;padding: 0 20px;float: left;display: block;width: 80px;letter-spacing: 0px;text-align: center;border-radius: 12px 12px 0 0;box-shadow: 2px 0 2px rgba(0,0,0,0.1), -2px 0 2px rgba(0,0,0,0.1);}
   .tabs label:after {content: '';background: #fff;position: absolute;bottom: -2px;left: 0;width: 100%;height: 2px;display: block;}
   .tabs label:first-of-type {z-index: 4;box-shadow: 1px 0 3px rgba(0,0,0,0.1);}

   .tab-label-2 {z-index: 2;}
   .tab-label-3 {z-index: 3;}
   .tab-label-4 {z-index: 4;}
   
   .clear-shadow {clear: both;}

   .content {background: #fff;position: relative;width: 100%;height:auto; min-height:600px;overflow: auto;z-index: 999;box-shadow: 0 -2px 3px -2px rgba(0,0,0,0.2), 0 2px 2px rgba(0,0,0,0.1);border-radius: 0 12px 3px 3px;}
   /* .content div {width:100%;position: absolute;top: 0;left: 0;padding: 10px 40px;z-index: 1;opacity: 0;box-sizing: border-box;} */
   .content div {width:100%;position: absolute;left: 0;padding: 10px 40px;z-index: 1;opacity: 0;box-sizing: border-box;}
   .content div h3{color: #398080;border-bottom:1px solid rgba(63,148,148, 0.1);}
   .content div h3:before{content: " - ";}
   .content div p {font-size: 14px;line-height: 22px;text-align: left;margin: 0;color: #777;padding-left: 15px;}
   .basic_td{
      border:1px solid;
      border-color:#d7d7d7;
   }
   .basic_table{
      border-collapse:collapse;
      border:1px solid;
      border-color:#d7d7d7;
   }

   .popupLayer {
      position: absolute;
      display: none;
      background-color: #ffffff;
      border: solid 2px #d0d0d0;
      width: 200px;
      height: 200px;
      padding: 10px;
      z-index: 1001;
   }
   .popup_menu:hover{
      color:#d0d0d0; 
   }

   /* 모달 css */
   .searchModal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 10; /* Sit on top */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
      z-index: 1002;
   }
      /* Modal Content/Box */
   .search-modal-content {
      background-color: #fefefe;
      margin: 15% auto; /* 15% from the top and centered */
      padding: 20px;
      border: 1px solid #888;
      width: 70%; /* Could be more or less, depending on screen size */
      z-index: 1002;
   }

   ul{
      list-style:none;
      padding-left:0px;
   }

   li{
      list-style:none;
      padding-left:0px;
   }
</style>
<link href="https://fonts.googleapis.com/css?family=Noto+Sans+KR" rel="stylesheet">
<script>
</script>
<body>
<form name="cform" action="<?php echo site_url(); ?>/approval/electronic_approval_form_popup" method="post" target="popup_window" onSubmit="javascript:openPopup();return false;">
   <input type="hidden" id="select_user_id" name="select_user_id" value="">
   <input type="hidden" name="popup_id" value="">
   <input type="hidden" name="popup_multi" value="">
   <input type="hidden" name="popup_template" value="">
</form>
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
      <input type="hidden" name="mode" value="<?php echo $mode; ?>">
      <?php include $this->input->server('DOCUMENT_ROOT')."/include/sales_header.php"; ?>
      <tr>
         <td align="center" valign="top">
            <table width="90%" height="100%" cellspacing="0" cellpadding="0">
               <tr>
                  <?php if($mode == "input"){ ?>
                  <td width="100%" align="center" valign="top">
                     <!--내용-->
                     <input type="hidden" id="seq" name="seq" value="">
                     <table width="100%" border="0" style="margin-top:50px; margin-bottom: 50px;">
                        <!--타이틀-->
                        <tr>
                           <td class="title3">전자결재 양식 작성</td>
                        </tr>
                        <!--타이틀-->
                        <tr>
                           <td>&nbsp;</td>
                        </tr>
                        <tr>
                           <td>
                              <section class="tabs" style="width:100%">
                                 <input id="tab-1" type="radio" name="radio-set" class="tab-selector-1 tabs_input" checked="checked">
                                 <label for="tab-1" class="tab-label-1">결재정보</label>
                                 <input id="tab-2" type="radio" name="radio-set" class="tab-selector-2 tabs_input" onclick="approval_info_save_check();">
                                 <label for="tab-2" class="tab-label-2">양식내용</label>
                                 <div class="clear-shadow"></div>
                                 <div class="content">
                                    <div class="content-1">
                                       <input type="hidden" id="approval_info_check" name="approval_info_check" value="N" />
                                       <input type="hidden" id="form_table_html" name="form_table_html" />
                                       <input type="hidden" id="preview_html" name="preview_html" />
                                       <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;" border="0" onClick=""/>
                                       <img src="<?php echo $misc;?>img/btn_ok.jpg" style="cursor:pointer;float:right" border="0" onClick="approval_info_save();"/><br>
                                       <h3>기본 정보</h3>
                                       <table width="100%" class ="basic_table">
                                          <tr >
                                             <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                <span style="color:red;" > * </span>양식명
                                             </td>
                                             <td width="35%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <input type="text" class="input2" id="template_name" name="template_name" />
                                             </td>
                                             <td width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                <span style="color:red;"> * </span>서식함
                                             </td>
                                             <td width="35%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <select class="input2" id="template_category" name="template_category">
                                                   <option value="">미선택</option>
                                                   <?php foreach($category as $format_categroy){
                                                      echo "<option value='{$format_categroy['category_name']}'>{$format_categroy['category_name']}</option>";
                                                   } ?>
                                                </select> 
                                             </td>
                                          </tr>
                                          <tr >
                                             <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                양식유형
                                             </td>
                                             <td colspan=3 width="35%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <input type="radio" name="template_type" value="내부결제" checked="checked"  />내부결제
                                                <input type="radio" name="template_type" value="협조문" />협조문
                                             </td>
                                          </tr>
                                          <tr >
                                             <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                정렬순서
                                             </td>
                                             <td colspan=3 width="35%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <input type="text" id="template_sort_seq" name="template_sort_seq" class="input5" />&nbsp * 기안문 작성 시 표시되는 양식의 정렬 순서, 숫자가 낮을 수록 상단에 표시됨.
                                             </td>
                                          </tr>
                                          <tr >
                                             <td width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                <span style="color:red;"> * </span>양식설명
                                             </td>
                                             <td height="60" colspan=3 width="35%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <textarea id="template_explanation" name="template_explanation" class="input7" style="height:85%"></textarea> 
                                             </td>
                                          </tr>
                                       </table>
                                       <h3>결재선 지정</h3>
                                       <table width="100%" class ="basic_table">
                                          <tr >
                                             <td width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                기본결재선
                                             </td>
                                             <td width="85%" height="40" colspan=3 class="basic_td" align="left" style="font-weight:bold;" >
                                                <select  id="default_approval_line" name="default_approval_line" class="input2" >
                                                   <option value="N" selected>결재선 설정 안함(기안문 작성 시 설정)</option>
                                                </select>
                                             </td>
                                          </tr>
                                       </table>
                                       <h3>추가정보</h3>
                                       <table width="100%" class ="basic_table">
                                          <tr >
                                             <td width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                기본 참조자
                                             </td>
                                             <td width="85%" height=40 colspan=3 class="basic_td" align="left" style="font-weight:bold;" >
                                                <input id="default_referrer" name="default_referrer" type="text" class="input7" />
                                                <img src="<?php echo $misc;?>img/btn_add.jpg" style="cursor:pointer;vertical-align:middle;" border="0" onClick="select_user('default_referrer');"/>
                                             </td>
                                          </tr>
                                       </table><br>
                                       <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;" border="0" onClick=""/>
                                       <img src="<?php echo $misc;?>img/btn_ok.jpg" style="cursor:pointer;float:right" border="0" onClick="approval_info_save();"/>
                                    </div>
                                    <div class="content-2">
                                       <img src="<?php echo $misc;?>img/btn_delete.jpg" style="cursor:pointer;float:right;margin-left:5px;" border="0" onClick=""/>
                                       <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;" border="0" onClick=""/>
                                       <img src="<?php echo $misc;?>img/btn_ok.jpg" style="cursor:pointer;float:right" border="0" onClick="template_info_save();"/><br>
                                       <h3>양식정보</h3>
                                       <table width="100%" class ="basic_table">
                                          <tr >
                                             <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                에디터
                                             </td>
                                             <td colspan=3 width="85%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <input type="radio" name="editor_use" value="Y" />사용
                                                <input type="radio" name="editor_use" value="N" checked="checked" />미사용
                                             </td>
                                          </tr>
                                          <tr >
                                             <td height="60" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                작성가이드
                                             </td>
                                             <td height="60" colspan=3 width="85%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <textarea id="writing_guide" name="writing_guide" class="input7" style="height:85%"></textarea> 
                                             </td>
                                          </tr>
                                       </table>
                                       <h3>양식 작성기</h3>
                                       <div class="content-2" style="width:100%">
                                          <input type="button" class="basicBtn" value="미리보기" onclick="preview();" style="margin-bottom:5px;">
                                          <br>
                                          <?php for($i=1; $i<=10; $i++){
                                             echo "<input type='button' value='{$i}' style='margin-left:2px;' onclick='form_add($i);'>";
                                          } ?>
                                          <input type="button" value="구분선" style='margin-left:2px;' onclick="form_add('line');" />
                                          <div class="content-2" style="width:100%">
                                             <table id="form_table" width="80%" class ="basic_table sortable">
                                             </table>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </section>
                           </td>
                        </tr>
                     </table>
                     <!--내용-->
                     <!-- 모달 -->
                     <div id="modal" class="searchModal">
                        <div class="search-modal-content">
                           <h2>폼 항목 선택</h2>
                           <table width="100%" class ="basic_table">
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">제목</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="multi_subject" class="input7" />
                                 </td>
                              </tr>
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">개수</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="multi_num" class="input2" value="1" />
                                 </td>
                              </tr>
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">넓이</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="multi_width" class="input2" /><span id ="multi_width_comment"></span>
                                 </td>
                              </tr>
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">합계</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="multi_sum" class="input2" />
                                 </td>
                              </tr>
                           </table>
                           <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;" border="0" onClick="closeMultiForm();"/>
                           <img src="<?php echo $misc;?>img/btn_ok.jpg" style="cursor:pointer;float:right;margin-top:5px;" border="0" onClick="multiForm_save();"/><br>
                        </div>
                     </div>
                     <div id="preview_modal" class="searchModal">
                        <div class="search-modal-content">
                           <img src="<?php echo $misc;?>img/btn_del2.jpg" style="cursor:pointer;float:right;" border="0" onClick="preview_close();"/>
                           <h2>미리보기</h2>
                           <table id="html" width="100%" border="0" style='font-family: "Noto Sans KR";border-collapse:collapse;'></table>
                        </div>
                     </div>
                     <div id="line_modal" class="searchModal">
                        <div class="search-modal-content">
                           <h2>구분선 추가</h2>
                           <table width="100%" class ="basic_table">
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">제목</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="line_subject" class="input7" />
                                 </td>
                              </tr>
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">설명</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="line_comment" class="input2" />
                                 </td>
                              </tr>
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">높이</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="line_height" class="input2" />
                                 </td>
                              </tr>

                           </table>
                           <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;" border="0" onClick="closeLineModal();"/>
                           <img src="<?php echo $misc;?>img/btn_ok.jpg" style="cursor:pointer;float:right;margin-top:5px;" border="0" onClick="saveLineModal();"/><br>
                        </div>
                     </div>
                     <div id="group_tree_modal" class="searchModal">
                        <div class="search-modal-content" style='height:auto; min-height:400px;overflow: auto;'>
                           <h2>사용자 선택</h2>
                              <div style="margin-top:30px;height:auto; min-height:300px;overflow:auto;">
                                 <input type="button" value="조직원 전체 선택" style="float:right;margin-bottom:5px;" onclick="select_user_add('all');" >
                                 <table class="basic_table" style="width:100%;height:300px;vertical-align:middle;">
                                    <tr>
                                       <td class ="basic_td" width="30%">
                                          <div id="groupTree">
                                             <ul>
                                                <li>
                                                <span style="cursor:pointer;" id="all" onclick="groupView(this)">
                                                   (주)두리안정보기술
                                                </span>
                                                <ul>
                                                <?php
                                                foreach ( $group_data as $parentGroup ) {
                                                   if($parentGroup['childGroupNum'] <= 1){
                                                   ?>
                                                      <li>
                                                         <ins>&nbsp;</ins>
                                                         <span style="cursor:pointer;" id="<?php echo $parentGroup['groupName'];?>" onclick="groupView(this)">
                                                         <ins>&nbsp;</ins>
                                                         <?php echo $parentGroup['groupName'];?>
                                                         </span>
                                                      </li>
                                                   <?php
                                                   }else{
                                                   ?>
                                                      <li>
                                                         <img src="<?php echo $misc; ?>img/btn_add.jpg" id="<?php echo $parentGroup['groupName'];?>Btn" width="13" style="cursor:pointer;" onclick="viewMore(this)">
                                                         <span style="cursor:pointer;" id="<?php echo $parentGroup['groupName'];?>" onclick="groupView(this)">
                                                         <?php echo $parentGroup['groupName'];?>
                                                         </span>
                                                      </li>
                                                   <?php
                                                   }
                                                }
                                                ?>
                                                </ul>
                                                </li>
                                             </ul>
                                          </div>
                                       </td>
                                       <td class ="basic_td" width="30%" align="center">
                                          <div id="click_group_user"></div>
                                       </td>
                                       <td class ="basic_td" width="10%" align="center">
                                          <div id="user_select_delete">
                                             <img src="<?php echo $misc;?>img/btn_right.jpg" style="cursor:pointer;width:22px;height:22px;" border="0" onClick="select_user_add();"/><br><br>
                                             <img src="<?php echo $misc;?>img/btn_left.jpg" style="cursor:pointer;width:22px;height:22px;" border="0" onClick="select_user_del();"/><br><br>
                                             <img src="<?php echo $misc;?>img/btn_del.jpg" style="cursor:pointer;width:22px;height:22px;" border="0" onClick="select_user_del('all');"/>
                                          </div>
                                       </td>
                                       <td class ="basic_td" width="30%" align="center">
                                          <div id="select_user">
                                          </div>
                                       </td>
                                    </tr>
                                 </table>
                              </div>
                              <div>
                                 <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;" border="0" onClick="closeUserModal();"/>
                                 <img src="<?php echo $misc;?>img/btn_ok.jpg" style="cursor:pointer;float:right;margin-top:5px;" border="0" onClick="saveUserModal();"/><br>
                              </div>
                        </div>
                     </div>
                     <!-- 모달끝 -->
                  </td>
                  <?php }else{?>
                  <td width="100%" align="center" valign="top">
                     <!--내용-->
                     <input type="hidden" id="seq" name="seq" value="<?php echo $view_val['seq']; ?>">
                     <table width="100%" border="0" style="margin-top:50px; margin-bottom: 50px;">
                        <!--타이틀-->
                        <tr>
                           <td class="title3">전자결재 양식 수정</td>
                        </tr>
                        <!--타이틀-->
                        <tr>
                           <td>&nbsp;</td>
                        </tr>
                        <tr>
                           <td>
                              <section class="tabs" style="width:100%">
                                 <input id="tab-1" type="radio" name="radio-set" class="tab-selector-1 tabs_input" checked="checked">
                                 <label for="tab-1" class="tab-label-1">결재정보</label>
                                 <input id="tab-2" type="radio" name="radio-set" class="tab-selector-2 tabs_input" onclick="approval_info_save_check();">
                                 <label for="tab-2" class="tab-label-2">양식내용</label>
                                 <div class="clear-shadow"></div>
                                 <div class="content">
                                    <div class="content-1">
                                       <input type="hidden" id="approval_info_check" name="approval_info_check" value="N" />
                                       <input type="hidden" id="form_table_html" name="form_table_html" />
                                       <input type="hidden" id="preview_html" name="preview_html" />
                                       <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;" border="0" onClick=""/>
                                       <img src="<?php echo $misc;?>img/btn_adjust.jpg" style="cursor:pointer;float:right" border="0" onClick="approval_info_save();"/><br>
                                       <h3>기본 정보</h3>
                                       <table width="100%" class ="basic_table">
                                          <tr >
                                             <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                <span style="color:red;" > * </span>양식명
                                             </td>
                                             <td width="35%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <input type="text" class="input2" id="template_name" name="template_name" value="<?php echo $view_val['template_name']; ?>" />
                                             </td>
                                             <td width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                <span style="color:red;"> * </span>서식함
                                             </td>
                                             <td width="35%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <select class="input2" id="template_category" name="template_category">
                                                   <option value="">미선택</option>
                                                   <?php foreach($category as $format_categroy){
                                                      echo "<option value='{$format_categroy['category_name']}'";
                                                      if($view_val['template_category'] == $format_categroy['category_name']){
                                                         echo "selected";
                                                      }
                                                      echo ">{$format_categroy['category_name']}</option>";
                                                   } ?>
                                                </select> 
                                             </td>
                                          </tr>
                                          <tr >
                                             <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                양식유형
                                             </td>
                                             <td colspan=3 width="35%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <input type="radio" name="template_type" value="내부결제" <?php if($view_val['template_type'] == "내부결제"){echo 'checked';} ?>  />내부결제
                                                <input type="radio" name="template_type" value="협조문" <?php if($view_val['template_type'] == "협조문"){echo 'checked';} ?> />협조문
                                             </td>
                                          </tr>
                                          <tr >
                                             <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                정렬순서
                                             </td>
                                             <td colspan=3 width="35%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <input type="text" id="template_sort_seq" name="template_sort_seq" class="input5" value="<?php echo $view_val['template_sort_seq'] ;?>" />&nbsp * 기안문 작성 시 표시되는 양식의 정렬 순서, 숫자가 낮을 수록 상단에 표시됨.
                                             </td>
                                          </tr>
                                          <tr >
                                             <td width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                <span style="color:red;"> * </span>양식설명
                                             </td>
                                             <td height="60" colspan=3 width="35%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <textarea id="template_explanation" name="template_explanation" class="input7" style="height:85%"><?php echo $view_val['template_explanation'] ;?></textarea> 
                                             </td>
                                          </tr>
                                       </table>
                                       <h3>결재선 지정</h3>
                                       <table width="100%" class ="basic_table">
                                          <tr >
                                             <td width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                기본결재선
                                             </td>
                                             <td width="85%" height="40" colspan=3 class="basic_td" align="left" style="font-weight:bold;" >
                                                <select id="default_approval_line" name="default_approval_line" class="input2" >
                                                   <option value="N" <?php if($view_val['default_approval_line'] == "협조문"){echo 'selected';} ?>>결재선 설정 안함(기안문 작성 시 설정)</option>
                                                </select>
                                             </td>
                                          </tr>
                                       </table>
                                       <h3>추가정보</h3>
                                       <table width="100%" class ="basic_table">
                                          <tr >
                                             <td width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                기본 참조자
                                             </td>
                                             <td width="85%" height=40 colspan=3 class="basic_td" align="left" style="font-weight:bold;" >
                                                <input id="default_referrer" name="default_referrer" type="text" class="input7" value="<?php echo $view_val['default_referrer']; ?>" />
                                                <img src="<?php echo $misc;?>img/btn_add.jpg" style="cursor:pointer;vertical-align:middle;" border="0" onClick="select_user('default_referrer');"/>
                                             </td>
                                          </tr>
                                       </table><br>
                                       <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;" border="0" onClick=""/>
                                       <img src="<?php echo $misc;?>img/btn_adjust.jpg" style="cursor:pointer;float:right" border="0" onClick="approval_info_save();"/>
                                    </div>
                                    <div class="content-2">
                                       <img src="<?php echo $misc;?>img/btn_delete.jpg" style="cursor:pointer;float:right;margin-left:5px;" border="0" onClick=""/>
                                       <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;" border="0" onClick=""/>
                                       <img src="<?php echo $misc;?>img/btn_adjust.jpg" style="cursor:pointer;float:right" border="0" onClick="template_info_save();"/><br>
                                       <h3>양식정보</h3>
                                       <table width="100%" class ="basic_table">
                                          <tr >
                                             <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                에디터
                                             </td>
                                             <td colspan=3 width="85%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <input type="radio" name="editor_use" value="Y" <?php if($view_val['editor_use'] == "Y"){echo 'checked';} ?>/>사용
                                                <input type="radio" name="editor_use" value="N" <?php if($view_val['editor_use'] == "N"){echo 'checked';} ?> />미사용
                                             </td>
                                          </tr>
                                          <tr >
                                             <td height="60" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;" >
                                                작성가이드
                                             </td>
                                             <td height="60" colspan=3 width="85%" class="basic_td" align="left" style="font-weight:bold;" >
                                                <textarea id="writing_guide" name="writing_guide" class="input7" style="height:85%"><?php echo $view_val['writing_guide']; ?></textarea> 
                                             </td>
                                          </tr>
                                       </table>
                                       <h3>양식 작성기</h3>
                                       <div class="content-2" style="width:100%">
                                          <input type="button" class="basicBtn" value="미리보기" onclick="preview();" style="margin-bottom:5px;">
                                          <br>
                                          <?php for($i=1; $i<=10; $i++){
                                             echo "<input type='button' value='{$i}' style='margin-left:2px;' onclick='form_add($i);'>";
                                          } ?>
                                          <input type="button" value="구분선" style='margin-left:2px;' onclick="form_add('line');" />
                                          <div class="content-2" style="width:100%">
                                             <!-- <table id="form_table" width="80%" class ="basic_table sortable">
                                             </table> -->
                                             <?php echo $view_val['form_table_html']; ?>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </section>
                           </td>
                        </tr>
                     </table>
                     <!--내용-->
                     <!-- 모달 -->
                     <div id="modal" class="searchModal">
                        <div class="search-modal-content">
                           <h2>폼 항목 선택</h2>
                           <table width="100%" class ="basic_table">
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">제목</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="multi_subject" class="input7" />
                                 </td>
                              </tr>
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">개수</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="multi_num" class="input2" value="1" />
                                 </td>
                              </tr>
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">넓이</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="multi_width" class="input2" /><span id ="multi_width_comment"></span>
                                 </td>
                              </tr>
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">합계</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="multi_sum" class="input2" />
                                 </td>
                              </tr>
                           </table>
                           <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;" border="0" onClick="closeMultiForm();"/>
                           <img src="<?php echo $misc;?>img/btn_ok.jpg" style="cursor:pointer;float:right;margin-top:5px;" border="0" onClick="multiForm_save();"/><br>
                        </div>
                     </div>
                     <div id="preview_modal" class="searchModal">
                        <div class="search-modal-content">
                           <img src="<?php echo $misc;?>img/btn_del2.jpg" style="cursor:pointer;float:right;" border="0" onClick="preview_close();"/>
                           <h2>미리보기</h2>
                           <table id="html" width="100%" border="0" style='font-family: "Noto Sans KR";border-collapse:collapse;'></table>
                        </div>
                     </div>
                     <div id="line_modal" class="searchModal">
                        <div class="search-modal-content">
                           <h2>구분선 추가</h2>
                           <table width="100%" class ="basic_table">
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">제목</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="line_subject" class="input7" />
                                 </td>
                              </tr>
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">설명</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="line_comment" class="input2" />
                                 </td>
                              </tr>
                              <tr>
                                 <td height="40" width="15%" bgcolor="#f8f8f9" class="basic_td" align="center" style="font-weight:bold;">높이</td>
                                 <td width="35%" class="basic_td" align="left">
                                    <input type="text" id ="line_height" class="input2" />
                                 </td>
                              </tr>

                           </table>
                           <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;" border="0" onClick="closeLineModal();"/>
                           <img src="<?php echo $misc;?>img/btn_ok.jpg" style="cursor:pointer;float:right;margin-top:5px;" border="0" onClick="saveLineModal();"/><br>
                        </div>
                     </div>
                     <div id="group_tree_modal" class="searchModal">
                        <div class="search-modal-content" style='height:auto; min-height:400px;overflow: auto;'>
                           <h2>사용자 선택</h2>
                              <div style="margin-top:30px;height:auto; min-height:300px;overflow:auto;">
                                 <input type="button" value="조직원 전체 선택" style="float:right;margin-bottom:5px;" onclick="select_user_add('all');" >
                                 <table class="basic_table" style="width:100%;height:300px;vertical-align:middle;">
                                    <tr>
                                       <td class ="basic_td" width="30%">
                                          <div id="groupTree">
                                             <ul>
                                                <li>
                                                <span style="cursor:pointer;" id="all" onclick="groupView(this)">
                                                   (주)두리안정보기술
                                                </span>
                                                <ul>
                                                <?php
                                                foreach ( $group_data as $parentGroup ) {
                                                   if($parentGroup['childGroupNum'] <= 1){
                                                   ?>
                                                      <li>
                                                         <ins>&nbsp;</ins>
                                                         <span style="cursor:pointer;" id="<?php echo $parentGroup['groupName'];?>" onclick="groupView(this)">
                                                         <ins>&nbsp;</ins>
                                                         <?php echo $parentGroup['groupName'];?>
                                                         </span>
                                                      </li>
                                                   <?php
                                                   }else{
                                                   ?>
                                                      <li>
                                                         <img src="<?php echo $misc; ?>img/btn_add.jpg" id="<?php echo $parentGroup['groupName'];?>Btn" width="13" style="cursor:pointer;" onclick="viewMore(this)">
                                                         <span style="cursor:pointer;" id="<?php echo $parentGroup['groupName'];?>" onclick="groupView(this)">
                                                         <?php echo $parentGroup['groupName'];?>
                                                         </span>
                                                      </li>
                                                   <?php
                                                   }
                                                }
                                                ?>
                                                </ul>
                                                </li>
                                             </ul>
                                          </div>
                                       </td>
                                       <td class ="basic_td" width="30%" align="center">
                                          <div id="click_group_user"></div>
                                       </td>
                                       <td class ="basic_td" width="10%" align="center">
                                          <div id="user_select_delete">
                                             <img src="<?php echo $misc;?>img/btn_right.jpg" style="cursor:pointer;width:22px;height:22px;" border="0" onClick="select_user_add();"/><br><br>
                                             <img src="<?php echo $misc;?>img/btn_left.jpg" style="cursor:pointer;width:22px;height:22px;" border="0" onClick="select_user_del();"/><br><br>
                                             <img src="<?php echo $misc;?>img/btn_del.jpg" style="cursor:pointer;width:22px;height:22px;" border="0" onClick="select_user_del('all');"/>
                                          </div>
                                       </td>
                                       <td class ="basic_td" width="30%" align="center">
                                          <div id="select_user">
                                          </div>
                                       </td>
                                    </tr>
                                 </table>
                              </div>
                              <div>
                                 <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;" border="0" onClick="closeUserModal();"/>
                                 <img src="<?php echo $misc;?>img/btn_ok.jpg" style="cursor:pointer;float:right;margin-top:5px;" border="0" onClick="saveUserModal();"/><br>
                              </div>
                        </div>
                     </div>
                     <!-- 모달끝 -->
                  </td>

                  <?php } ?>
               </tr>
            </table>
         </td>
      </tr>
      <!--하단-->
      <tr>
         <td align="center" height="100" bgcolor="#CCCCCC">
            <table width="1130" cellspacing="0" cellpadding="0">
               <tr>
                  <td width="197" height="100" align="center" background="<?php echo $misc;?>img/customer_f_bg.png"><img
                        src="<?php echo $misc;?>img/f_ci.png" /></td>
                  <td><?php include $this->input->server('DOCUMENT_ROOT')."/include/sales_bottom.php"; ?></td>
               </tr>
            </table>
         </td>
      </tr>
      <!--하단-->
   <div class="popupLayer">
      <div style="float:left;width:50%;">
         <input type="hidden" id="popup_td" value="" /> 
         <div width="50px" class="popup_menu" style="cursor:pointer;" onclick="openMultiForm();">멀티</div>
         <div width="50px" class="popup_menu" id="multi_delete_btn" style="cursor:pointer;display:none;" onclick="deleteMultiForm();">멀티삭제</div>
         <div width="50px" class="popup_menu" style="cursor:pointer;" onclick="add_item();">item추가</div>
         <div width="50px" class="popup_menu" style="cursor:pointer;" onclick="delete_item('td');">item삭제</div>
         <div width="50px" class="popup_menu" style="cursor:pointer;" onclick="element_change('left');">왼쪽</div>
         <div width="50px" class="popup_menu" style="cursor:pointer;" onclick="element_change('right');">오른쪽</div>
         <div width="50px" class="popup_menu" style="cursor:pointer;" onclick="delete_item('row');">줄 삭제</div>
      </div>
      <div id='template_info' style="float:left;width:50%;">
      </div>
   </div>
</table>
<script>
   if("<?php echo $mode; ?>" == "input"){
      var trLength = 1;
   }else{

      var trLength = Number($("#form_table").find($("tr")).eq(($("#form_table").find($("tr")).length)-1).attr('id').replace("tr",""))+1;
   }
   console.log(trLength);
   
   //항목추가
   function form_add(add_num){
      if(add_num != 'line'){
         var add_html = "<tr id='tr"+trLength+"' style='cursor:pointer'>";
         var col = 100 / add_num;
         for(i=1; i<=add_num; i++){
            add_html += "<td height='40' id='tr"+trLength+"_td"+i+"' colspan='"+col+"' align='center' class='basic_td'><span style='cursor:pointer;' onclick='openPopup(this);' onmousedown='others(event,this);'>항목추가</span></td>";
         }
         add_html += "</tr>";
         $("#form_table").html($("#form_table").html()+add_html);
      }else{
         var add_html = "<tr id='tr"+trLength+"' style='cursor:pointer'><td height='40' id='tr"+trLength+"_td1' colspan='100' align='center' class='basic_td'><span style='cursor:pointer;' onclick='openLineModal(this);' onmousedown='others(event,this);'>구분선</span></td></tr>";
         $("#form_table").html($("#form_table").html()+add_html);
      }
      trLength++ 
   }

   //팝업~
   function openPopup(obj){

      var mform = document.cform;
      var parentId = $(obj).parent().attr('id');
      
      var tr = $("#"+parentId).parent();
      if(tr.find($("input[name=multi_row]")).length > 0){
         var multi = "Y"
      }else{
         var multi = "N"
      }

      var template = $("#"+parentId).find($("input[name=template]")).val();
      if(template != undefined){
         template = template;
      }else{
         template='';
      }

      mform.popup_id.value = parentId;
      mform.popup_multi.value = multi;
      mform.popup_template.value = template;
     
      window.open("", "popup_window", "width = 1200, height = 500, top = 100, left = 400, location = no,status=no,status=no,toolbar=no,scrollbars=no");
      mform.submit();
		return false;
   }

   //항목추가에 오른쪽 클릭  기타 메뉴들
   function others(e,obj){
      document.addEventListener('contextmenu', function() {
         event.preventDefault();
      });
      if ((e.button == 2) || (e.which == 3)) {
         var sWidth = window.innerWidth;
         var sHeight = window.innerHeight;

         var oWidth = $('.popupLayer').width();
         var oHeight = $('.popupLayer').height();

         // 레이어가 나타날 위치를 셋팅한다.
         var divLeft = $("#form_table").offset().left + $("#form_table").width() + 30;

         var divTop = $("#form_table").offset().top + 5;

         //오른쪽 마우스 클릭해서 메뉴박스 띄운 td 어딘지 확인
         if($(obj).parent().css('background-color') == "rgba(0, 0, 0, 0)" || $(obj).parent().css('background-color') == "transparent"){
            $(obj).parent().css('background-color','#666666');
            var click_td = $(obj).parent();
            $("#form_table").find('td').not(click_td).css('background-color','');
            $('.popupLayer').show();
         }else{
            $(obj).parent().css('background-color','');
            $('.popupLayer').hide();
         }

         $("#popup_td").val($(obj).parent().attr('id'));//팝업 띄운 td 저장해놓기

         template_info_change(); // template 정보 띄워주기
         
         //멀티 있으면 멀티삭제 메뉴 show()
         var tr = $("#"+$("#popup_td").val()).parent();
         var multiLength = tr.find($('input[name=multi_row]')).length; 
         if(multiLength > 0){
            $("#multi_delete_btn").show();
         }else{
            $("#multi_delete_btn").hide();
         }

         $('.popupLayer').css({
            "top": divTop,
            "left": divLeft,
            "position": "absolute"
         })
      }
   }

   //sortable tr 상하이동
   $(".sortable").sortable({

   });

   //td 좌우로 이동
   function element_change(direction){
      if(direction == "left"){//한칸 앞으로
         $("#"+$("#popup_td").val()).prev().before($("#"+$("#popup_td").val()));
      }else{//한칸뒤로
         $("#"+$("#popup_td").val()).next().after($("#"+$("#popup_td").val()));
      }
   }

   //아이템 추가
   function add_item(){
      var tr = $("#"+$("#popup_td").val()).parent();
      var tr_num = $(tr).attr('id').replace('tr','');
      var tdLength = tr.find('td').length; // tr안에 있는 td 개수
      var col = 100/(tdLength+1);
      var add_html = "<td height='40' id='tr"+tr_num+"_td"+(tdLength+1)+"' colspan='"+col+"' align='center' class='basic_td'><span style='cursor:pointer;' onclick='openPopup(this);' onmousedown='others(event,this);'>항목추가</span></td>";
      $(tr).append(add_html);
      $(tr).find('td').attr("colspan",col);
   }

   //아이템 삭제
   function delete_item(type){
      var tr = $("#"+$("#popup_td").val()).parent();
      if(type == 'td'){
         var tdLength = tr.find('td').length;
         if(tdLength == 1){ // 하나 남은 td 지울땐 그냥 tr 지워
            $(tr).remove();
         }else{
            $("#"+$("#popup_td").val()).remove(); // 해당 td 삭제
            var tdLength = tr.find('td').length; // tr안에 있는 td 개수
            var col = 100/(tdLength-1);
            $(tr).find('td').attr("colspan",col);//colspan 변경
         }
      }else{
         $(tr).remove();
      }
      $('.popupLayer').hide();
   }

   //멀티폼 오픈
   function openMultiForm(){
      var multi_check = true;
      var tr = $("#"+$("#popup_td").val()).parent();
      var column_length = tr.find($("td")).length;
      var width_comment = "  ex)컬럼수("+column_length+")+버튼=";
      for(i=0; i<column_length; i++){
         width_comment += (90/column_length)+',';
      }
      width_comment += "10";
      $("#multi_width_comment").text(width_comment);
      for(i=0; i<tr.find($("input[name=template]")).length; i++){
         var template_type = tr.find($("input[name=template]")).eq(i).val().split('|');
         if(template_type[0] != 1 && template_type[0] != 3){
            multi_check = false;
         }
      }
      if(multi_check == true){
         var multiLength = tr.find($('input[name=multi_row]')).length;
         $("#modal").find($('input')).val(''); //input창 비워주기~!
         $("#multi_num").val(1)
         if(multiLength == 0){
            $("#modal").show();
         }else{
            var multi_info = tr.find($('input[name=multi_row]')).val().split('|');
            $("#multi_subject").val(multi_info[0]);
            if(multi_info[1] != ''){
               $("#multi_num").val(multi_info[1]);
            }
            
            $("#multi_width").val(multi_info[2]);
            $("#multi_sum").val(multi_info[3]);
            $("#modal").show();
         }
      }else{
         alert("멀티는 텍스트와 셀렉트박스만 가능합니다.");
         $("#"+$("#popup_td").val()).css('background-color','');
         $('.popupLayer').hide();
      }
   }

   //멀티폼 종료
   function closeMultiForm() {
      var check = confirm("이 페이지에서 나가시겠습니까? 작성중인 내용은 저장 되지 않습니다.")
      if(check == true){ 
         $("#modal").hide();
         $('.popupLayer').hide();
      }else{
         return false;
      }
   };

   //멀티폼 저장
   function multiForm_save(){
      var tr = $("#"+$("#popup_td").val()).parent();
       
      var multi_subject = $("#multi_subject").val();
      var multi_num = $("#multi_num").val();
      var multi_width = $("#multi_width").val();
      var multi_sum = $("#multi_sum").val();

      var multi_info = multi_subject +'|'+ multi_num +'|'+ multi_width +'|'+ multi_sum;

      var multiLength = tr.find($('input[name=multi_row]')).length;
      if(multiLength == 0){//멀티 없을때
         var txt = "<input type='hidden' name='multi_row' value='"+multi_info+"'>";
         tr.html(tr.html()+txt);
      }else{
         tr.find($('input[name=multi_row]')).val(multi_info);
      }
      
      $("#modal").hide();
      $('.popupLayer').hide();
   }

   //멀티폼 삭제
   function deleteMultiForm(){
      var tr = $("#"+$("#popup_td").val()).parent();
      var check = confirm("멀티를 삭제하시겠습니까?");
      if(check == true){
         tr.find($('input[name=multi_row]')).remove();
         $('.popupLayer').hide();
      }else{
         return false;
      }
   }
   
   //구분선 모달 열기
   function openLineModal(obj){
      var td = $(obj).parent().attr('id');

      $("#popup_td").val(td);

      var tr = $("#"+$("#popup_td").val()).parent();
      var templateLength = tr.find($('input[name=template]')).length;
      $("#line_modal").find($('input')).val('');
      if(templateLength == 0){
         $("#line_modal").show();
      }else{
         var template_info = tr.find($('input[name=template]')).val().split('|');
         $("#line_subject").val(template_info[1]);
         $("#line_comment").val(template_info[2]);
         $("#line_height").val(template_info[3]);
         $("#line_modal").show();
      } 

   }

   //구분선 모달 닫기
   function closeLineModal(){
      var check = confirm("이 페이지에서 나가시겠습니까? 작성중인 내용은 저장 되지 않습니다.")
      if(check == true){ 
         $("#line_modal").hide();
         $('.popupLayer').hide();
      }else{
         return false;
      }
   }

   //구분선 모달 저장
   function saveLineModal(){
      var td = $("#"+$("#popup_td").val());
      var tr = td.parent();
      var tr_row = tr.attr('id').replace('tr','');
       
      var line_subject = $("#line_subject").val();
      var line_comment = $("#line_comment").val();
      var line_height = $("#line_height").val();

      var line_info = '0' + '|' + line_subject +'|'+ line_comment +'|'+ line_height;

      var templateLength = tr.find($('input[name=template]')).length;
      if(templateLength == 0){//template 없을때
         var txt = "<input type='hidden' name='template' id='template"+tr_row+"' value='"+line_info+"'>";
         td.html(td.html()+txt);
      }else{
         td.find($('input[name=template]')).val(line_info);
      }
      $("#line_modal").hide();
      $('.popupLayer').hide();
   }

   //미리보기
   function preview(){
      var tdLength = $("#form_table").find($("td")).length;
      var templateLength = $("#form_table").find($("input[name=template]")).length;
      if(tdLength==templateLength){
         makeHtml();
         $("#preview_modal").show(); 
      }else{
         alert("항목들을 채워주세요")
         return false;
      }
   }

   //미리보기 닫기
   function preview_close(){
      $("#preview_modal").hide();
   }

   //사용자 선택 모달 닫아
   function closeUserModal(){
      var check = confirm("이 페이지에서 나가시겠습니까? 작성중인 내용은 저장 되지 않습니다.")
      if(check == true){ 
         $("#group_tree_modal").hide();
         $('.popupLayer').hide();
      }else{
         return false;
      }
   }

   //아아아악 폼으로 html 만드는 거
   function makeHtml() {
      var tr = $("#form_table").find('tr');
      var html =''; 

      for (i = 0; i < tr.length; i++) {//tr
         var text = '';
         var th = '';
         var multi = '';
         var multi_sum = '';
         var template = tr.eq(i).find($('input[name=template]'));

         if(tr.eq(i).find($('input[name=multi_row]')).length > 0){
            var multi_row = tr.eq(i).find($('input[name=multi_row]')).val().split('|');
            var button_width ='';
            var button_colspan ='';
            if(multi_row[2] != ""){
               var multi_width = multi_row[2].split(',');
               button_width = " width:" + multi_width[multi_width.length-1]+"%";
               button_colspan= " colspan="+multi_width[multi_width.length-1];
            }

            th += "<tr name='multi_row"+i+"'>"
            multi = "<tr name='multi_row"+i+"'>";
            if(multi_row[3] != ""){
               multi_sum = "<tr name='multi_row"+i+"sum'>";
            }
         }else{
            text += "<tr>";
         }
         
         
         for (j = 0; j < template.length; j++) {//td
            var template_info = template.eq(j).val().split('|');
            var type = template_info[0];

            if(type == 0){ //구분선
               var line_subject = template_info[1];
               var line_comment = template_info[2];
               var line_height = template_info[3];

               text += "<td height="+line_height+" align='left' style='border:none;border-bottom:1px solid;border-color:#d7d7d7'>" + line_subject + "</td>";
               text += "<td height="+line_height+"  style='border:none;border-bottom:1px solid;border-color:#d7d7d7'>"+line_comment+"</td>";

            }else if (type == 1) { //input
               var column_name = template_info[1];
               if (template_info[2] == "Y") {
                  column_name = '';
               }

               if (template_info[3] == "Y") {
                  var essential = "required";
                  var required_input_display = "<span style='color:red;'> * </span>"
               } else {
                  var essential = "";
                  var required_input_display = "";
               }

               if (template_info[4] == 0) { //전체
                  var input_type = ''
               } else if (template_info[4] == 1) { //숫자
                  var input_type = 'pattern="[0-9]+"';
               } else if (template_info[4] == 2) { //숫자 소숫점
                  var input_type = 'type="number" step="any"';
               } else if (template_info[4] == 3) { //금액
                  var input_type = 'pattern="[0-9]+" oninput="this.value = this.value.replace(/\,/g,' + "'')" + '"';
               } else if (template_info[4] == 4) { //날짜
                  var input_type = 'type="date"'
               } else if (template_info[4] == 5) { //이메일
                  var input_type = 'type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2, 4}$"';
               } else if (template_info[4] == 6) { //전화번호
                  var input_type = 'pattern="[0-9]{2,3}-[0-9]{3,4}-[0-9]{3,4}"';
               } else if (template_info[4] == 7) { //우편번호
                  var input_type = "[A-Za-z0-9]{4,10}"
               } else { //표현식
                  var input_type = "";
               }

               if(template_info[4].indexOf('//') != -1){ //표현식일때 $("input[name=zgzgz]").val()
                  var round_num  = template_info[4].split('//')[1];
                  var round_type  = template_info[4].split('//')[2];
                  var onChange = "round(this,"+round_num+","+'"'+round_type+'"'+")";
                  if(template_info[5].trim() != ''){
                     var default_value = " value='expression="+template_info[5]+"'";
                  }else{//표현식이지만 계산은 따로 없을경우(소수점자리는 있구)
                     var default_value = " value='" + template_info[5] + "'";
                  }
               }else{
                  var onChange = "";
                  var default_value = " value='" + template_info[5] + "'";
               }
               
               if (template_info[6] != "") {
                  var width = " width:" + template_info[6] + template_info[7];
               } else {
                  var width = '';
               }

               if (template_info[8] != "") {
                  var maximum = "maxlength=" + template_info[8];
               } else {
                  var maximum = "";
               }

               if (template_info[9] != "") {
                  var comment =  "<br>"+template_info[9];
               }else{
                  var comment =  "";
               }

               var name = template_info[10];
               
               if(tr.eq(i).find($('input[name=multi_row]')).length > 0){
                  var td_width = "";
                  var colspan = "";
                  if(multi_row[2]!=""){
                     td_width = " width:" + multi_width[j]+"%";
                     colspan = " colspan="+multi_width[j];
                  }
                  th += "<td height=40 "+colspan+" bgcolor='#f8f8f9' align='center' class='basic_td' style='"+td_width+"'>"+required_input_display+column_name+"</td>";
                  multi += "<td height=40 "+colspan+" class='basic_td' style='"+td_width+"'><input " + input_type + " class='"+name+" input7' "+default_value + maximum + " onchange='"+onChange+"' style='" + width + "' " + essential + "/>"+comment+"</td>";          
                  if(multi_row[3] != ""){
                     if(multi_row[3].indexOf(name) != -1){
                        multi_sum += "<td height=40 "+colspan+" class='basic_td'  style='"+td_width+"'><input " + input_type + " id='"+name+"_sum' name='multisum'  class='input7' style='" + width + "' readonly/></td>";
                     }else{
                        multi_sum += "<td height=40 "+colspan+" class='basic_td' style='"+td_width+"'></td>";
                     }
                  }
               }else{
                  text += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td'>" +required_input_display+ column_name + "</td>";
                  text += "<td height=40 class='basic_td'><input " + input_type + " class='"+name+" input7' "+ default_value + maximum + " onchange='"+onChange+"' style='" + width + "' " + essential + "/>"+comment+"</td>";
               }
            } else if (type == 2) { //textarea
               var column_name = template_info[1];
               if (template_info[2] == "Y") {
                  column_name = '';
               }

               if (template_info[3] == "Y") {
                  var essential = "required";
                  var required_input_display = "<span style='color:red;'> * </span>"
               } else {
                  var essential = "";
                  var required_input_display = "";
               }

               if (template_info[4] != "") {
                  var width = "width:" + template_info[4] + template_info[5] + ";";
               } else {
                  var width = '';
               }

               if (template_info[6] != "") {
                  var height = "height:" + template_info[6] + "px;";
               } else {
                  var height = '';
               }

               var textarea_value =  template_info[7];

               if (template_info[8] != "") {
                  var comment =  "<br>"+template_info[8];
               }else{
                  var comment =  "";
               }

               var name = template_info[9];


               if(tr.eq(i).find($('input[name=multi_row]')).length >0){
                  th += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td'>"+required_input_display+column_name+"</td>";
                  multi += "<td height=40 class='basic_td'><textarea class='"+name+" input7' style='" + width + height + "' " + essential + ">"+textarea_value+"</textarea>"+comment+"</td>";
               }else{
                  text += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td'>" + required_input_display + column_name + "</td>";
                  text += "<td height=40 class='basic_td'><textarea class='"+name+" input7' style='" + width + height + "' " + essential + ">"+textarea_value+"</textarea>"+comment+"</td>";
               }

            } else if (type == 3) { //select box
               var column_name = template_info[1];
               if (template_info[2] == "Y") {
                  column_name = '';
               }

               if (template_info[3] == "Y") {
                  var essential = "required";
                  var required_input_display = "<span style='color:red;'> * </span>";
               } else {
                  var essential = "";
                  var required_input_display = "";
               }

               var option_html = '';
               if (template_info[4] != "") {
                  var option = template_info[4].split('**');
                  for (k = 0; k < option.length; k++) {
                     var option_value = option[k].split('//')[1];
                     if (option[k].split('//')[0] == 'true') {
                        var option_selected = 'selected';
                     } else {
                        var option_selected = '';
                     }
                     option_html += "<option value='" + option_value + "'" + option_selected + ">" + option_value + "</option>";
                  }
               }

               if (template_info[5] != "") {
                  var comment =  "<br>"+template_info[5];
               }else{
                  var comment =  "";
               }

               var name = template_info[6];

               if(tr.eq(i).find($('input[name=multi_row]')).length >0){
                  th += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td'>"+required_input_display+column_name+"</td>";
                  multi += "<td height=40 class='basic_td'><select class='"+name+" input2' " + essential + ">" + option_html + "</select>"+comment+"</td>";
                  if(multi_row[3] != ""){
                     multi_sum += "<td height=40 class='basic_td'></td>";
                  }
               }else{
                  text += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td'>" + required_input_display +column_name + "</td>";
                  text += "<td height=40 class='basic_td'><select class='"+name+" input2' " + essential + ">" + option_html + "</select>"+comment+"</td>";
               }

            } else if (type == 4) { //radio
               var column_name = template_info[1];
               if (template_info[2] == "Y") {
                  column_name = '';
               }

               var name = template_info[7];

               if (template_info[3] == "Y") {
                  var essential = " required";
                  var required_input_display = "<span style='color:red;'> * </span>";
               } else {
                  var essential = "";
                  var required_input_display = "";
               }

               if(template_info[4] == "horizontal"){
                  var sort = '';
               }else{
                  var sort = '<br>';
               }

               var option_html = '';
               if (template_info[5] != "") {
                  var option = template_info[5].split('**');
                  for (k = 0; k < option.length; k++) {
                     var option_value = option[k].split('//')[1];
                     if (option[k].split('//')[0] == 'true') {
                        var option_selected = ' checked';
                     } else {
                        var option_selected = '';
                     }
                     option_html += '<input type="radio" name="'+name+'" class="'+name+'" value="'+option_value+'" '+option_selected+essential+'>'+option_value+sort;
                  }
               }

               if (template_info[6] != "") {
                  var comment =  "<br>"+template_info[6];
               }else{
                  var comment =  "";
               }

               
               if(tr.eq(i).find($('input[name=multi_row]')).length >0){
                  th += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td'>"+required_input_display+column_name+"</td>";
                  multi += "<td height=40 class='basic_td'>"+option_html+comment+"</td>";
               }else{
                  text += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td'>" +required_input_display+ column_name + "</td>";
                  text += "<td height=40 class='basic_td'>"+option_html+comment+"</td>";
               }
            } else if (type == 5) { //check_box
               var column_name = template_info[1];
               if (template_info[2] == "Y") {
                  column_name = '';
               }

               var name = template_info[6];

               if(template_info[3] == "horizontal"){
                  var sort = '';
               }else{
                  var sort = '<br>';
               }

               var option_html = '';
               if (template_info[4] != "") {
                  var option = template_info[4].split('**');
                  for (k = 0; k < option.length; k++) {
                     var option_value = option[k].split('//')[1];
                     if (option[k].split('//')[0] == 'true') {
                        var option_selected = ' checked';
                     } else {
                        var option_selected = '';
                     }
                     option_html += '<input type="checkbox" name="'+name+'" class="'+name+'" value="'+option_value+'" '+option_selected+'>'+option_value+sort;
                  }
               }

               if (template_info[5] != "") {
                  var comment =  "<br>"+template_info[5];
               }else{
                  var comment =  "";
               }


               if(tr.eq(i).find($('input[name=multi_row]')).length >0){
                  th += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td'>"+column_name+"</td>";
                  multi += "<td height=40 class='basic_td'>"+option_html+comment+"</td>";
               }else{
                  text += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td'>" + column_name + "</td>";
                  text += "<td height=40 class='basic_td'>"+option_html+comment+"</td>";
               }
            
            } else if (type == 6) { //글상자
               if(template_info[1] == "Y"){
                  var header1 = "background-color:#f8f8f9;border-right:none;";
                  var header2 = "background-color:#f8f8f9;border-left:none;";
               }else{
                  var header1 = "";
                  var header2 = "";
               }

               var column_name = template_info[2];
               if (template_info[3] == "Y") {
                  column_name = '';
               }
               var comment = template_info[4];
               if(tr.eq(i).find($('input[name=multi_row]')).length >0){
                  th += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td' style='"+header1+"'>" + column_name + "</td>";
                  multi += "<td height=40 class='basic_td' style='"+header2+"'>"+comment+"</td>";  
               }else{
                  text += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td' style='"+header1+"'>" + column_name + "</td>";
                  text += "<td height=40 class='basic_td' style='"+header2+"'>"+comment+"</td>";    
               }

            }else if(type == 7) { //컴포넌트
               var column_name = template_info[1];
               if (template_info[2] == "Y") {
                  column_name = '';
               }

               if (template_info[3] == "Y") {
                  var essential = " required";
                  var required_input_display = "<span style='color:red;'> * </span>";
               } else {
                  var essential = "";
                  var required_input_display = "";
               }

               var component = template_info[4];
               var maximum = template_info[5];

               if (template_info[6] != "") {
                  var comment =  "<br>"+template_info[6];
               }else{
                  var comment =  "";
               }

               var name = template_info[7];

               if(tr.eq(i).find($('input[name=multi_row]')).length >0){
                  th += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td' >" + required_input_display +column_name + "</td>";
                  multi += "<td height=40 class='basic_td'><div><input name='"+name+"' title='"+component+"' placeholder='"+component+"' style='border:none;background:transparent;vertical-align:middle;'/><img src='<?php echo $misc;?>img/btn_add.jpg' style='cursor:pointer;vertical-align:middle;' border='0' onClick='component(this);'/></div>"+comment+"</td>";
               }else{
                  text += "<td height=40 bgcolor='#f8f8f9' align='center' class='basic_td' >" + required_input_display + column_name + "</td>";
                  text += "<td height=40 class='basic_td'><div><input name='"+name+"' title='"+component+"' placeholder='"+component+"' style='border:none;background:transparent;vertical-align:middle;'/><img src='<?php echo $misc;?>img/btn_add.jpg' style='cursor:pointer;vertical-align:middle;' border='0' onClick='component(this);'/></div>"+comment+"</td>";
               }    
            }
         }
         if(tr.eq(i).find($('input[name=multi_row]')).length > 0){//멀티 있을때
            th += "<td "+button_colspan+" align='center' class='basic_td' style='"+button_width+"'><img src='<?php echo $misc;?>/img/btn_add.jpg' style='cursor:pointer;' onclick='addRow(this)'></td></tr>";
            html += th;
            multi += "<td "+button_colspan+" align='center' class='basic_td' style='"+button_width+"'><img src='<?php echo $misc;?>/img/btn_del0.jpg' style='cursor:pointer;' onclick='delRow(this)'></td></tr>";
            if(multi_row[1] != ''){
               for(z=0; z < multi_row[1]; z++){
                  html += multi;
               }
            }
            if(multi_row[3] != ""){
               multi_sum +="<td class='basic_td'>"+multi_row[0]+"</td></tr>"
            }
            html += multi_sum;
         }else{
            text += "</tr>";
            html += text
         }
      }

      $("#html").html(html);

      //가로 input멀티함수넣어주는거야
      var html_input = $("#html").find($("input"));
      for (i = 0; i < html_input.length; i++) {
         if (html_input.eq(i).val().indexOf('expression=') != -1 && html_input.eq(i).val() != '') {
            var html_input_class = html_input.eq(i).attr('class').replace("input7", "") // 클래스 우선 구해바
            $("." + html_input_class).attr('readonly', true);

            if ($("." + html_input_class).length == 1 && html_input.eq(i).parent().parent().attr('name') == undefined) {

               var expression = $("." + html_input_class).eq(0).val().replace('expression=', '');
               var expression2 = expression.split(/[+-/*)(]/g);
               var calculation_symbol = expression.match(/[+-/*)(]/g);
               //좀따 다시와서 확인행
               var onchange_name = '';
               var expression3 = expression.split(/[+-/*)(]/g);

               for (k = 0; k < expression2.length; k++) {
                  if (isNaN(expression2[k]) == true) {
                     expression2[k] = expression2[k].replace('[', '').replace(']', '');
                     var sum = 0;
                     for (l = 0; l < $("." + expression2[k]).length; l++) {
                        var onchange = $("." + expression2[k]).eq(l).attr("onchange");
                        sum += Number($("." + expression2[k]).eq(l).val());
                        var txt = '';
                        for (f = 0; f < expression2.length; f++) {
                           if (expression2[f] != undefined) {
                              txt += expression2[f] + ',';
                           }
                           if (calculation_symbol[f] != undefined) {
                              txt += calculation_symbol[f] + ',';
                           }
                        }
                        $("." + expression2[k]).eq(l).attr("onchange", onchange + ";multi_calculation('" + txt + "','" + html_input_class + "','all')");
                     }
                     expression3[k] = sum;
                  }
               }

               if (calculation_symbol != null) {
                  var txt2 = '';
                  for (f = 0; f < expression3.length; f++) {
                     if (expression3[f] != undefined) {
                        txt2 += expression3[f] + ',';
                     }
                     if (calculation_symbol[f] != undefined) {
                        txt2 += calculation_symbol[f] + ',';
                     }
                  }

                  txt2 = txt2.replace(/[,]/g, '');
                  $("." + html_input_class).eq(0).val(eval(txt2));
                  $("." + html_input_class).each(function(){ this.defaultValue = this.value;});
               }
            }

            if(($("." + html_input_class).length >= 1 && html_input.eq(i).parent().parent().attr('name') != undefined)) {
               for (j = 0; j < $("." + html_input_class).length; j++) {
                  var expression = $("." + html_input_class).eq(0).val().replace('expression=', '');
                  var expression2 = expression.split(/[+-/*]/g);
                  expression = expression.replace(/\[/gi, 'Number($(".').replace(/\]/gi, '").eq(' + j + ').val())');

                  var onchange_name = '';
                  for (k = 0; k < expression2.length; k++) {
                     if (isNaN(expression2[k]) == true) {
                        expression2[k] = expression2[k].replace('[', '').replace(']', '');
                        var onchange = $("." + expression2[k]).eq(j).attr("onchange");
                        // $("." + expression2[k]).eq(j).attr("onchange", onchange + ";multi_calculation('" + expression + "','" + html_input_class + "','" + j + "')");
                        for(l = 0; l < expression2[k].length; l++){
                           $("." + expression2[k]).eq(l).attr("onchange", onchange + ";multi_calculation('" + expression + "','" + html_input_class + "'," + 'this' + ")");
                        }
                     }
                  } 
                  $("." + html_input_class).eq(j).val(eval(expression));
                  $("." + html_input_class).each(function(){ this.defaultValue = this.value;});
               }
            }
         }
      }
      


      //세로 멀티...
      var multi_sum_input = $("input[name=multisum]");

      for(i=0; i<multi_sum_input.length; i++){
         var multi_input = $("input[name=multisum]").eq(i)
         var multi_id = multi_input.attr('id').replace("_sum",'');
         var sum_value = 0;
         
         for(j=0; j < $("."+multi_id).length; j++){
            sum_value += Number($("."+multi_id).eq(j).val());
            var multi_id_onchange = $("."+multi_id).eq(j).attr('onchange');
            $("."+multi_id).eq(j).attr('onchange',multi_id_onchange+';multi_sum("'+multi_id+'")');
         }

         multi_input.val(sum_value);
         $(multi_input).each(function(){ this.defaultValue = this.value;});
         
      }

      //colspan width 조절 (좋은방법잇으면 수정)
      for(i=0; i< $("#html").find($("tr")).length; i++){
         var tdLength = $("#html").find($("tr")).eq(i).find($('td')).length;
         var td_col=[];
         if(tdLength == 2){
            td_col[0] = 15
            td_col[1] = 85 
         }else if (tdLength == 4){
            td_col[0] = 15
            td_col[1] = 35
            td_col[2] = 15 
            td_col[3] = 35  
         }else{
            var col = 100 / tdLength;
            for(k=0; k<tdLength; k++){
               td_col[k] = col;
            }
         }
         
         for(j=0; j< $("#html").find($("tr")).eq(i).find($('td')).length; j++){
            if($("#html").find($("tr")).eq(i).find($('td')).eq(j).attr("colspan") == undefined){
               $("#html").find($("tr")).eq(i).find($('td')).eq(j).attr("colspan",td_col[j]);
               $("#html").find($("tr")).eq(i).find($('td')).eq(j).width( td_col[j]+'%');
            }
            
         }
      }

      //멀티 width ...

   }


   //이거슨 버튼 동작
   function addRow(obj){
      var tr_name = $(obj).parent().parent().attr('name');
      var tr_last = $('tr[name='+tr_name+']')[$('tr[name='+tr_name+']').length-1];
      var tr_last_html = tr_last.outerHTML;
      $(tr_last).after(tr_last_html);
      var new_tr = $('tr[name='+tr_name+']')[$('tr[name='+tr_name+']').length-1]
      for(i=0; i<$(new_tr).find($("input")).length; i++){
         if($(new_tr).find($("input")).eq(i).val().indexOf("express") != -1){
            $(new_tr).find($("input")).eq(i).val(''); //표현식 들어있는 input 비워
         }
      }
   }

   function delRow(obj){
      $(obj).parent().parent().remove();
   }

   function template_info_change(){
      var td = $("#"+$("#popup_td").val());

      if(td.find($("input[name=template]")).length > 0){
         var templateInfo = td.find($("input[name=template]")).val().split('|');

         if(templateInfo[0] == 1){//input
            var input_type;
            if(templateInfo[4] == '0'){
               input_type="전체";
            }else if(templateInfo[4] == '1'){
               input_type="숫자";
            }else if(templateInfo[4] == '2'){
               input_type="숫자(소숫점포함)";
            }else if(templateInfo[4] == '3'){
               input_type="금액";
            }else if(templateInfo[4] == '4'){
               input_type="날짜";
            }else if(templateInfo[4] == '5'){
               input_type="이메일";
            }else if(templateInfo[4] == '6'){
               input_type="전화번호";
            }else if(templateInfo[4] == '7'){
               input_type="우편번호";
            }else{
               input_type="표현식";
            }
            var txt ="<div>제목 : "+templateInfo[1]+"</div>";
            txt += "<div>타입 : 텍스트</div>";
            txt += "<div>name : "+templateInfo[10]+"</div>";
            txt += "<div>필수 : "+templateInfo[3]+"</div>";
            txt += "<div>제목표시 : "+templateInfo[2]+"</div>";
            txt += "<div>입력타입 : "+input_type+"</div>";
            txt += "<div>넓이 : "+templateInfo[6]+templateInfo[7]+"</div>";
            txt += "<div>최대 : "+templateInfo[8]+"</div>";
            txt += "<div>기본값 : "+templateInfo[5]+"</div>";
         }else if (templateInfo[0] == 2){ //textarea
            var txt ="<div>제목 : "+templateInfo[1]+"</div>";
            txt += "<div>타입 : 텍스트박스</div>";
            txt += "<div>name : "+templateInfo[9]+"</div>";
            txt += "<div>필수 : "+templateInfo[3]+"</div>";
            txt += "<div>제목표시 : "+templateInfo[2]+"</div>";
            txt += "<div>넓이 : "+templateInfo[4]+templateInfo[5]+"</div>";
            txt += "<div>높이 : "+templateInfo[6]+"</div>";
            txt += "<div>기본값 : "+templateInfo[7]+"</div>";
         }else if (templateInfo[0] == 3){ //select
            var txt ="<div>제목 : "+templateInfo[1]+"</div>";
            txt += "<div>타입 : 셀렉트</div>";
            txt += "<div>name : "+templateInfo[6]+"</div>";
            txt += "<div>필수 : "+templateInfo[3]+"</div>";
            txt += "<div>제목표시 : "+templateInfo[2]+"</div>";
         }else if (templateInfo[0] == 4){ //radio
            var txt ="<div>제목 : "+templateInfo[1]+"</div>";
            txt += "<div>타입 : 라디오</div>";
            txt += "<div>name : "+templateInfo[7]+"</div>";
            txt += "<div>필수 : "+templateInfo[3]+"</div>";
            txt += "<div>제목표시 : "+templateInfo[2]+"</div>";
            txt += "<div>정렬 : "+templateInfo[4]+"</div>";
         }else if (templateInfo[0] == 5){ //체크박스
            var txt ="<div>제목 : "+templateInfo[1]+"</div>";
            txt += "<div>타입 : 체크박스</div>";
            txt += "<div>name : "+templateInfo[6]+"</div>";
            txt += "<div>제목표시 : "+templateInfo[2]+"</div>";
            txt += "<div>정렬 : "+templateInfo[3]+"</div>";
         }else if (templateInfo[0] == 6){ //글상자
            var txt ="<div>제목 : "+templateInfo[2]+"</div>";
            txt += "<div>타입 : 글상자</div>";
            txt += "<div>헤더표시 : "+templateInfo[1]+"</div>";
            txt += "<div>제목표시 : "+templateInfo[3]+"</div>";
         }else if (templateInfo[0] == 7){ //컴포넌트
            var txt ="<div>제목 : "+templateInfo[1]+"</div>";
            txt += "<div>타입 : 컴포넌트</div>";
            txt += "<div>항목 : "+templateInfo[4]+"</div>";
            txt += "<div>name : "+templateInfo[7]+"</div>";
            txt += "<div>필수 : "+templateInfo[3]+"</div>";
            txt += "<div>제목표시 : "+templateInfo[2]+"</div>";
            txt += "<div>최대 : "+templateInfo[5]+"</div>";
         }
         $("#template_info").html(txt);
      }
   }


   function multi_calculation(expression,changeInput,eq){
      if(eq == 'all'){
         var class_name = expression.replace(/\[/gi,'').replace(/\]/gi,'');
         class_name = class_name.split(',');
         expression='';
         for(i=0; i<class_name.length; i++){
            if(isNaN(class_name[i]) == true && /[+-/)(*]/g.test(class_name[i]) == false){
               class_name[i] = $('.'+class_name[i]);
               var sum = 0;
               for(j=0; j<class_name[i].length; j++){
                  sum += Number(class_name[i].eq(j).val());
               }
               class_name[i] = sum; 
            }
            expression += class_name[i];
         }
         var html_input = $("#html").find($("."+changeInput)).eq(0);
         html_input.val(eval(expression));
         html_input.trigger("change");
      }else{
         var class_name = $(eq).attr("class").replace("input7","");
         var index = $("."+class_name).index($(eq));
         expression=expression.split("eq(0)").join("eq("+index+")");
         var html_input = $("#html").find($("."+changeInput)).eq(index);
         html_input.val(eval(expression));
         html_input.trigger("change");
      }

   }

   function multi_sum(multi_id){
      var multi_input = multi_id + "_sum"
      var sum_value = 0;
   
      for(j=0; j < $("."+multi_id).length; j++){
         sum_value += Number($("."+multi_id).eq(j).val());
      }
      $("#"+multi_input).val(sum_value);
   }
   
   //결재정보 저장
   function approval_info_save(){
      //필수입력칸 채웠냐궁
      if($("#template_name").val() == ''){ //양식명
         $("#template_name").focus();
         alert("양식명을 입력해주세요.");
         return false;
      }

      if($("#template_category").val() == ''){ //서식함
         $("#template_category").focus();
         alert("서식함을 선택해주세요.");
         return false;
      }

      if($("#template_explanation").val() == ''){ //양식설명
         $("#template_explanation").focus();
         alert("양식설명을 입력해주세요.");
         return false;
      }
      
      if('<?php echo $mode; ?>' == "input"){ //등록일때
         $.ajax({
            type: "POST",
            cache: false,
            url: "<?php echo site_url();?>/ajax/approval_info_save",
            dataType: "json",
            async: false,
            data: {
               template_name: $("#template_name").val(),
               template_category: $("#template_category").val(),
               template_type: $("input[name=template_type]:checked").val(),
               template_sort_seq: $("#template_sort_seq").val(),
               template_explanation: $("#template_explanation").val(),
               default_approval_line: $("#default_approval_line").val(),
               default_referrer: $("#default_referrer").val(),
            },
            success: function (data) {
               alert("저장성공 ㅎ");
               $("#seq").val(data);
               $("#approval_info_check").val("Y");
            }
         });
      }else{ // 수정일때
         $.ajax({
            type: "POST",
            cache: false,
            url: "<?php echo site_url();?>/ajax/approval_info_save",
            dataType: "json",
            async: false,
            data: {
               seq: $("#seq").val(),
               template_name: $("#template_name").val(),
               template_category: $("#template_category").val(),
               template_type: $("input[name=template_type]:checked").val(),
               template_sort_seq: $("#template_sort_seq").val(),
               template_explanation: $("#template_explanation").val(),
               default_approval_line: $("#default_approval_line").val(),
               default_referrer: $("#default_referrer").val(),
            },
            success: function (data) {
              if(data == true){
                 alert("수정 성공");
              }else{
                 alert("수정 실패");
              }
            }
         });
      }
   }

   //결재정보 저장해야 양식정보로 넘어가지롱
   function approval_info_save_check(){
      // if($("#approval_info_check").val() == "N"){
      //    alert("결재정보 저장 후 양식내용으로 넘어갈 수 있습니다.")
      //    $("input:radio[name='radio-set']:radio[id='tab-1']").prop('checked', true); // 선택하기
      //    return false;
      // }
   }

   //양식내용 저장 
   function template_info_save(){
      var tdLength = $("#form_table").find($("td")).length;
      var templateLength = $("#form_table").find($("input[name=template]")).length;
      if(tdLength==templateLength){
         makeHtml();
         $("#form_table_html").val(document.getElementById('form_table').outerHTML);
         $("#preview_html").val(document.getElementById('html').outerHTML);
      }else{
         alert("항목들을 채워주세요");
         return false;
      }

      $.ajax({
			type: "POST",
			cache: false,
			url: "<?php echo site_url();?>/ajax/template_info_save",
			dataType: "json",
			async: false,
			data: {
				seq : $("#seq").val(),
            editor_use: $("input[name=editor_use]:checked").val(),
            writing_guide: $("#writing_guide").val(),
            form_table_html: $("#form_table_html").val(),
            preview_html: $("#preview_html").val()
			},
			success: function (data) {
            if(data == true){
               alert("양식저장성공 ㅎ");
            }else{
               alert("실패");
            }
           
			}
		});
   }

   //사용자 선택
   function select_user(s_id){
      // $("#group_tree_modal").show();
      $("#click_user").remove();
      $("#group_tree_modal").show();
      $("#select_user_id").val(s_id);
      if($("#"+$("#select_user_id").val()).val() != ""){
         var select_user = ($("#"+$("#select_user_id").val()).val()).split(',');
         var txt = '';
         for(i=0; i<select_user.length; i++){
            txt += "<div class='select_user' onclick='click_user("+'"'+select_user[i]+'"'+",this)'>"+select_user[i]+"</div>";
         }
         $("#select_user").html(txt);
      }
   }

   //사용자 선택 저장
   function saveUserModal(){
      var txt ='';
      for(i=0; i <$(".select_user").length; i++){
         var val = $(".select_user").eq(i).text().split(' ');
         if(i == 0){
            txt += val[0]+" "+val[1];
         }else{
            txt += "," + val[0]+" "+val[1];
         }
         $("#"+$("#select_user_id").val()).val(txt);
         $("#group_tree_modal").hide();
      }
   }

   // groupView();

   //상위 그룹에서 하위 그룹 보기
   function viewMore(button){
   var parentGroup = (button.id).replace('Btn','');
   if($(button).attr("src")==="<?php echo $misc; ?>img/btn_add.jpg"){
      var src = "<?php echo $misc; ?>img/btn_del0.jpg";
      $.ajax({
         type: "POST",
         cache: false,
         url: "<?php echo site_url(); ?>/ajax/childGroup",
         dataType: "json",
         async: false,
         data: {
         parentGroup:parentGroup
         },
         success: function (data) {
         var text = '<ul id="'+parentGroup+'Group" class="'+parentGroup+'" >';
         for(i=0; i<data.length; i++){
               text += '<li><ins>&nbsp;</ins><span style="cursor:pointer;" id="'+data[i].groupName+'" onclick="groupView(this)"><ins>&nbsp;</ins>'+data[i].groupName+'</span></li>';
         }
         text += '</ul>'
         //   $("#"+parentGroup).html($("#"+parentGroup).html()+text);
         $("#"+parentGroup).after(text);

         }
      }); 
   }else{
      var src = "<?php echo $misc; ?>img/btn_add.jpg";
      $("#"+parentGroup+"Group").hide();
      $("."+parentGroup).remove();
   }
   $("#"+parentGroup+"Btn").attr('src', src); 
   }

   //그룹 클릭했을 떄 해당하는 user 보여주기
   function groupView(group){
   if(group == undefined){
      var groupName = "all";
   }else{
      var groupName = $(group).attr("id");
   }
   
   $.ajax({
         type: "POST",
         cache: false,
         url: "<?php echo site_url(); ?>/ajax/groupView",
         dataType: "json",
         async: false,
         data: {
         group:groupName
         },
         success: function (data) {
            var txt = '';
            for(i=0; i<data.length; i++){
                  txt +=  "<div class='click_user' onclick='click_user("+'"'+data[i].user_name+'",this'+");'>"+data[i].user_name+" "+data[i].user_duty+" "+data[i].user_group+ "</div>";
            }
            $("#click_group_user").html(txt);
         }
   });
   }

   //user 선택
   function click_user(name,obj){
      $(".click_user").css('background-color','');
      $(".select_user").css('background-color','');
      $(".click_user").attr('id','');
      $(".select_user").attr('id','');
      $(obj).css('background-color','#f8f8f9');
      $(obj).attr('id','click_user');
   }

   //user 추가
   function select_user_add(type){
      if(type == 'all'){
         var result = confirm("회사 내 전체 조직원을 선택하시겠습니까?");
         if(result){
            $.ajax({
               type: "POST",
               cache: false,
               url: "<?php echo site_url(); ?>/ajax/groupView",
               dataType: "json",
               async :false,
               data: {
                  group: 'all'
               },
               success: function (data) {
                  var html = '';
                  for (i = 0; i < data.length; i++) {
                     html += "<div class='select_user' onclick='click_user("+'"'+data[i].user_name+'"'+",this)'>"+data[i].user_name+" "+data[i].user_duty+" "+data[i].user_group+"</div>";
                  }
                  $("#select_user").html(html);
               }
            });
         }else{
         return false;
         }
      }else{
         var duplicate_check = false;
         for(i=0; i<$(".select_user").length; i++){
            if($("#click_user").html() == $(".select_user").eq(i).text()){
               duplicate_check = true
            }
         }
         if(duplicate_check == true){
            return false;
         }else{
            var html = "<div class='select_user' onclick='click_user("+'"'+$("#click_user").html()+'"'+",this)'>"+$("#click_user").html()+"</div>";
            $("#select_user").html($("#select_user").html()+html);
         }
      }

   }

   //추가된 user 중에 삭제
   function select_user_del(type){
      if(type == "all"){
         $(".select_user").remove();
      }else{
         if($("#click_user").attr('class') == 'select_user'){
            $("#click_user").remove();
         }
      }
   }

   //반올림 올림 , 내림
   function round(obj,n,type){
      if(n != 0){
         if(type == "round"){//반올림
            var num = Number(obj.value);
            $(obj).val(num.toFixed(n));
         }else if(type == "down"){//내림
            var decimal_point = obj.value.indexOf('.');
            var num = (obj.value).substring(0,(decimal_point+n+1));
            $(obj).val(num);
         }else if(type == "up"){//올림
            var decimal_point = obj.value.indexOf('.');
            var num = (obj.value).substring(0,(decimal_point+n+1));
            var up_value = String(Number(num[(decimal_point+n)])+1);
            up_value = num.substr(0,(decimal_point+n)) + up_value + num.substr((decimal_point+n)+ up_value.length);
            $(obj).val(up_value);
         }
      }else{
         if(type == "round"){//반올림
            var num = Math.round(obj.value);
            $(obj).val(num);
         }else if(type == "down"){//내림
            var num = Math.floor(obj.value);
            $(obj).val(num);
         }else if(type == "up"){//올림
            var num = Math.ceil(obj.value);
            $(obj).val(num);
         }
      }
   }
</script>
</body>
</html>
