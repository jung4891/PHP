<?php
header("Content-type: text/html; charset=utf-8");
class Approval extends CI_Controller {

    var $id = '';

    function __construct() {
        parent::__construct();
        $this->id = $this->phpsession->get( 'id', 'stc' );
        $this->customerid = $this->phpsession->get( 'customerid', 'stc' );
        $this->cooperative_id = $this->phpsession->get( 'cooperative_id', 'stc' );
        $this->name = $this->phpsession->get( 'name', 'stc' );
        $this->lv = $this->phpsession->get( 'lv', 'stc' );
        $this->at = $this->phpsession->get( 'at', 'stc' );
        $this->company = $this->phpsession->get( 'company', 'stc' );
        $this->email = $this->phpsession->get('email','stc'); //김수성추가
        $this->pGroupName = $this->phpsession->get( 'pGroupName', 'stc' );
        $this->group = $this->phpsession->get( 'group', 'stc' );
        $this->load->helper('form');
        $this->load->helper('url');
        
    }

	function electronic_approval_form() {
        $this->load->model('STC_Approval' );
		$data['group_data'] = $this->STC_Approval->parentGroup();
        $data['category'] = $this->STC_Approval->select_format_category();
        if($_GET['mode']=="modify"){
            $seq = $_GET['seq'];
            $data['view_val'] = $this->STC_Approval->approval_form_view($seq);
        }
		$this->load->view( 'electronic_approval_form',$data);
    }
    
    function electronic_approval_form_popup() {
        $this->load->model( 'STC_Approval' );
        $data['category'] = $this->STC_Approval->select_format_category();
        $data['td_id'] = $_POST['popup_id'];
        $data['multi'] = $_POST['popup_multi'];
        $data['template'] = $_POST['popup_template'];
		$this->load->view( 'electronic_approval_form_popup',$data);
    }

    function electronic_approval_form_list() {
        $this->load->model('STC_Approval' );
        $data['category'] = $this->STC_Approval->select_format_category();
        $data['view_val'] = $this->STC_Approval->approval_form_list();
		$this->load->view( 'electronic_approval_form_list',$data);
    }

    function electronic_approval_doc_input() {
        $this->load->model('STC_Approval' );
        $seq = $_GET['seq'];
        $data['seq']= $seq;
        $data['category'] = $this->STC_Approval->select_format_category();
        $data['view_val'] = $this->STC_Approval->approval_form_view($seq);
        $data['user_approval_line'] = $this->STC_Approval->user_approval_line_select($this->id);
        $data['group_val'] = $this->STC_Approval->parentGroup();
		$this->load->view('electronic_approval_doc_input',$data);
    }

    //기안문 저장
    function electronic_approval_doc_input_action(){
        $this->load->model( 'STC_Approval' );
        $this->load->helper('download');
        $approval_form_seq = $this->input->post('approval_form_seq' );
        // $template_name = $this->input->post( 'template_name' );
        $write_date = $this->input->post( 'write_date' );
		$writer_name = $this->input->post( 'writer_name' );
		$writer_group = $this->input->post( 'writer_group' );
        $referrer = $this->input->post( 'referrer' );
        $approval_attach = $this->input->post( 'approval_attach' );
		$approval_doc_name = $this->input->post( 'approval_doc_name' );
        $contents_html = $this->input->post( 'contents_html' );
        $editor_contents = $this->input->post( 'editor_contents' );
		$approver_line = $this->input->post( 'approver_line' );
        $approval_doc_status = $this->input->post( 'approval_doc_status' );

        $file_count = $_POST['file_length'];
        $file_realname='';
        $file_changename='';


        if($file_count > 0){
            for($i=0; $i<$file_count; $i++){
                // $csize = $_FILES["files".$i]["size"];
                $f = "files".$i;
                $cname = $_FILES[$f]["name"];
                $ext = substr(strrchr($cname,"."),1);
                $ext = strtolower($ext);
                if($ext != "doc" && $ext != "docx" && $ext != "txt" && $ext != "ppt" && $ext != "pptx" && $ext != "xls" && $ext != "xlsx" && $ext != "zip" && $ext != "rar" && $ext != "gif" && $ext != "jpg" && $ext != "jpeg" && $ext != "png" && $ext != "pdf" && $ext != "hwp") {
                    echo "<script>alert('이미지, 문서, 압축 파일만 올릴수 있습니다.');history.go(-1);</script>";
                    exit;
                }
                $upload_dir = "D:/";
                $conf_file['upload_path'] = $upload_dir;
                $conf_file['allowed_types'] = 'zip|rar|txt|doc|pdf|ppt|xls|pptx|docx|xlsx|gif|jpg|png|hwp|jpeg';
                $conf_file['overwrite']  = false;
                $conf_file['encrypt_name']  = true;
                $conf_file['remove_spaces']  = true;
    
                $this->load->library('upload', $conf_file );
                $result = $this->upload->do_upload($f); 
                if($result) {
                    $file_data = array('upload_data' => $this->upload->data());
                    $file_realname .= ','.$file_data['upload_data']['orig_name'];
                    $file_changename .= ','.$file_data['upload_data']['file_name'];
                } else {
                    alert('업로드 파일에 문제가 있습니다. 다시 처리해 주시기 바랍니다.');
                    exit;
                }
            }

            $file_realname = trim($file_realname,',');
            $file_changename = trim($file_changename,',');
        }
        

        
        $data = array(
            'approval_form_seq' =>$approval_form_seq,
			'write_date' => $write_date,
			'writer_name' => $writer_name,
			'writer_group' => $writer_group,
			'referrer' => $referrer,
            'approval_doc_name' =>$approval_doc_name,
			'contents_html' => $contents_html,
			'editor_contents' => $editor_contents,
			'approver_line' => $approver_line,
            'file_realname' => $file_realname,
            'file_changename' => $file_changename,
            'approval_attach' => $approval_attach,
            'approval_doc_status' => $approval_doc_status,
            'writer_id' => $this->id,
			'insert_date' => date("Y-m-d H:i:s")
         );
         
        $doc_seq = $this->STC_Approval->electronic_approval_doc_insert( $data, $mode = 1);
        if($doc_seq){
            $result = true;
        }

        if(isset($_POST['test1']) && isset($_POST['test2'])){
            $approval_line_seq = explode(',',$_POST['test1']);
            $approval_line_type = explode(',',$_POST['test2']);

            for($i=0; $i<count($approval_line_seq); $i++){
                $result = $this->STC_Approval->electronic_approval_line_insert($doc_seq,$approval_line_seq[$i],$i,$approval_line_type[$i]);
            }
        }
     
        echo json_encode($result);
    }

    //작성된 기안문 보기!
    function electronic_approval_doc_view() {
        $this->load->model('STC_Approval' );
        $seq = $_GET['seq'];
        if(isset($_GET['type'])){
            $data['type'] = $_GET['type'];  
        }else{
            $data['type'] ="";
        }
        $data['seq']= $seq;
        $data['category'] = $this->STC_Approval->select_format_category();
        $data['view_val'] = $this->STC_Approval->approval_doc_view($seq);
        $data['group_val'] = $this->STC_Approval->parentGroup();
        $data['cur_approval_line'] = $this->STC_Approval->cur_approval_line($seq);
        if(!empty($data['cur_approval_line'])){
            $data['next_approval_line'] = $this->STC_Approval->next_approval_line($seq,$data['cur_approval_line']['seq']);
        }
        $data['approval_line'] = $this->STC_Approval->approval_line($seq);
        $data['hold'] =$this->STC_Approval->approval_hold_select($seq);
        if(!empty($data['cur_approval_line'])){
            $data['mandatary'] = $this->STC_Approval->mandatary_whether($data['cur_approval_line']['user_id']);
        }
		$this->load->view( 'electronic_approval_doc_view',$data);
    }

    function electronic_approval_doc_list() {
        $this->load->model('STC_Approval' );
        $data['category'] = $this->STC_Approval->select_format_category();
        $data['view_val'] = $this->STC_Approval->approval_doc_list($_GET['type']);//진행중인고
		$this->load->view( 'electronic_approval_doc_list',$data);
    }

    function approval_attachment(){
        $this->load->model('STC_Approval' );
        $data['view_val'] = $this->STC_Approval->approval_doc_list('002');//완료된고
		$this->load->view( 'approval_attachment',$data);
    }

    //결재 문서함
    function electronic_approval_list() {
        $this->load->model('STC_Approval' );
        // $type = '';
        $type= $_GET['type'];
        // if($_GET['type'] == "standby"){
        //     $type = "001";
        // }else if($_GET['type'] == "progress"){
        //     $type= "005";
        // }else if($_GET['type'] == "completion"){
        //     $type= "005";
        // }else if($_GET['type'] == "back"){
        //     $type= "005";
        // }else if($_GET['type'] == "reference"){
        //     $type= "005";
        // }
        $data['category'] = $this->STC_Approval->select_format_category();
        $data['view_val'] = $this->STC_Approval->approval_list($type);//진행중인고
        if($type == "standby"){
          $data['delegation'] = $this->STC_Approval->delegation_list();  
        }
        $data['type'] = $type;
        $this->load->view('electronic_approval_list',$data);
    }

    //결재승인/반려 저장
    function approval_save(){
        $this->load->model('STC_Approval' );
        $seq = $this->input->post('seq');
        $next_seq = $this->input->post('next_seq');
        $approval_status = $this->input->post('approval_status'); //N 이면 반려~
        $approval_opinion = $this->input->post('approval_opinion');
        $approval_doc_seq = $this->input->post('approval_doc_seq');
        $final_approval = $this->input->post('final_approval');
        $delegation_seq = $this->input->post('delegation_seq');

        if($approval_status != ""){
            $data = array(
                'seq' => $seq,
                'approval_status' => $approval_status,
                'approval_opinion' => $approval_opinion,
                'approval_date' => date("Y-m-d H:i:s"),
                'delegation_seq' => $delegation_seq

            );
        }else{ //결재취소할때임
            $data = array(
                'seq' => $seq,
                'approval_status' => $approval_status,
                'approval_opinion' => $approval_opinion,
                'approval_date' => null,
                'delegation_seq' => $delegation_seq
            );
        }

        $result = $this->STC_Approval->approval_save($data,$next_seq);

        if($approval_status == "N" && $result){
            $data2 = array(
                'seq' => $approval_doc_seq,
                'completion_date' => date("Y-m-d H:i:s"),
                'approval_doc_status' => "003", //반려
                'update_id' => $this->id,
                'update_date' => date("Y-m-d H:i:s")
            );
            $result = $this->STC_Approval->electronic_approval_doc_update($data2);
        }
        
        if($approval_status != "N" && $final_approval == "Y" && $result){
            $data2 = array(
                'seq' => $approval_doc_seq,
                'completion_date' => date("Y-m-d H:i:s"),
                'approval_doc_status' => "002", //완료
                'update_id' => $this->id,
                'update_date' => date("Y-m-d H:i:s")
            );
            $result = $this->STC_Approval->electronic_approval_doc_update($data2);
        }
        echo json_encode($result);
    }


    //결재회수 
    function approval_withdraw(){
        $this->load->model('STC_Approval' );
        $seq = $this->input->post('seq');
        $approval_doc_status = $this->input->post('approval_doc_status');
        $data = array(
            'seq' => $seq,
            'approval_doc_status' => $approval_doc_status, //회수
            'update_id' => $this->id,
            'update_date' => date("Y-m-d H:i:s")
        );

        $result = $this->STC_Approval->electronic_approval_doc_update($data);
        if($result){
            $result = $this->STC_Approval->electronic_approval_line_delete($seq);
        }
        echo json_encode($result);
    }

    //결재 보류 처리
    function approval_hold(){
        $this->load->model('STC_Approval' );
        $seq = $this->input->post('seq');
        $approval_doc_hold = $this->input->post('approval_doc_hold');
        $hold_opinion = $this->input->post('hold_opinion');

        $data = array(
            'seq' => $seq,
            'approval_doc_hold' => $approval_doc_hold, //보류 여부
            'update_id' => $this->id,
            'update_date' => date("Y-m-d H:i:s")
        );

        $result = $this->STC_Approval->electronic_approval_doc_update($data);

        if($result && $approval_doc_hold == "Y"){
            $data2 = array(
                'approval_doc_seq' => $seq,
                'hold_status' => $approval_doc_hold, //보류 여부
                'holder' => $this->name, //보류자
                'user_group' => $this->group , //보류자
                'processing_date' => date("Y-m-d H:i:s"),
                'hold_opinion' => $hold_opinion
            );
            $result = $this->STC_Approval->electronic_approval_hold_insert($data2,1);
        }else if($result && $approval_doc_hold == "N"){
            $data2 = array(
                'approval_doc_seq' => $seq,
                'hold_status' => $approval_doc_hold, //보류 여부
                'processing_date' => date("Y-m-d H:i:s") 
            );
            $result = $this->STC_Approval->electronic_approval_hold_insert($data2,0);
        }
        echo json_encode($result);
    }

    // 결재라인 문서확인시간 저장
    function approval_check_date_update(){
        $this->load->model('STC_Approval');
        $seq = $this->input->post('seq');
        $data = array(
            'seq' => $seq,
            'check_date' => date("Y-m-d H:i:s")
        );
        $result = $this->STC_Approval->electronic_approval_line_update($data);
        echo json_encode($result);
    }

    //사용자 결재선 저장 
    function user_approval_line_save(){
        $this->load->model('STC_Approval');
        $approval_line_name = $this->input->post('approval_line_name');
        $approver_seq = $this->input->post('approver_seq');
        $approval_type = $this->input->post('approval_type');
        $data = array(
            'approval_line_name' => $approval_line_name,
            'approver_seq' => $approver_seq,
            'approval_type' => $approval_type,
            'user_id' => $this->id,
            'insert_date' => date("Y-m-d H:i:s")
        );
        $result = $this->STC_Approval->user_approval_line_save($data,1); // insert
        echo json_encode($result);
    }

    //사용자 결재선의 결재자 가져오기
    function user_approval_line_approver(){
        $this->load->model('STC_Approval');
        $user_seq = $this->input->post('user_seq');
        $result = $this->STC_Approval->select_user($user_seq);
        echo json_encode($result);
    }

    //위임 관리
    function electronic_approval_delegation_management(){
        $this->load->model('STC_Approval' );
        $data['group_data'] = $this->STC_Approval->parentGroup();
        $data['category'] = $this->STC_Approval->select_format_category();
        $data['view_val'] = $this->STC_Approval->electronic_approval_delegation_list();
        $this->load->view('electronic_approval_delegation_management',$data);
    }
    
    //위임등록 
    function delegation_save(){
        $this->load->model('STC_Approval' );
        $delegate_group = $this->input->post('delegate_group');
        $start_date = $this->input->post('start_date');
        $end_date = $this->input->post('end_date');
        $mandatary = $this->input->post('mandatary');
        $mandatary_seq = $this->input->post('mandatary_seq');
        $delegation_reason = $this->input->post('delegation_reason');

        $data = array(
            'delegate_group' => $delegate_group,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'mandatary' => $mandatary,
            'mandatary_seq' => $mandatary_seq,
            'delegation_reason' => $delegation_reason,
            'write_id' => $this->id,
            'insert_date' => date("Y-m-d H:i:s")
        );

        $result = $this->STC_Approval->delegation_save($data,1); // insert
        echo json_encode($result);
    }

    //위임설정해제
    function delegation_unset(){
        $this->load->model('STC_Approval' );
        $check_seq = $this->input->post('check_seq');
        $result = $this->STC_Approval->delegation_save($check_seq,2); // 설정해제
        echo json_encode($result);
    }

    //위임 상세보기
    function delegation_detail_view(){
        $this->load->model('STC_Approval');
        $seq = $this->input->post('seq');
        $result = $this->STC_Approval->delegation_detail_view($seq); // 설정해제
        echo json_encode($result);
    }

    //개인보관함 관리 뷰
    function electronic_approval_personal_storage(){
        $this->load->model('STC_Approval');
        $data['view_val'] = $this->STC_Approval->electronic_approval_personal_storage_select('all');
        $this->load->view('electronic_approval_personal_storage',$data);
    }

    //개인보관함 팝업 뷰
    function electronic_approval_personal_storage_popup(){
        $this->load->model('STC_Approval');
        $data['view_val'] = $this->STC_Approval->electronic_approval_personal_storage_select('all');
        $this->load->view('electronic_approval_personal_storage_popup',$data);
    }

    //개인보관함 리스트 뷰
    function electronic_approval_personal_storage_list(){
        $this->load->model('STC_Approval');
        $seq = $_GET['seq'];
        $data['view_val'] = $this->STC_Approval->electronic_approval_personal_storage_select('all');
        $data['view_val2'] = $this->STC_Approval->electronic_approval_personal_storage_list($seq);
        $this->load->view('electronic_approval_personal_storage_list',$data);
    }

    //개인보관함 저장
    function storageSave(){
        $this->load->model('STC_Approval' );
        $type = $this->input->post('type');

        if($type == 1){ //추가
            $data = array(
                'user_id' => $this->id,
                'storage_name' => $this->input->post('storage_name'),
                'parent_id' => $this->input->post('parent_id'),
                'insert_date' => date("Y-m-d H:i:s")
            );
            $result = $this->STC_Approval->storageSave($data,$type); // 개인보관함 추가
        }else if($type == 2){ //수정
            $data = array(
                'seq'=> $this->input->post('seq'),
                'storage_name' => $this->input->post('storage_name'),
                'update_date' => date("Y-m-d H:i:s")
            );
            $result = $this->STC_Approval->storageSave($data,$type); // 개인보관함 수정
        }else if($type == 3){ //삭제
            $seq = $this->input->post('seq');
            $result = $this->STC_Approval->storageSave($seq,$type); // 개인보관함 수정
        }
        
        echo json_encode($result);
    }

    //개인보관함 세부 목록
    function storageView(){
        $this->load->model('STC_Approval' );
        $seq = $this->input->post('seq');
        $result = $this->STC_Approval->electronic_approval_personal_storage_select($seq); //개인보관함 폴더 하위목록
        echo json_encode($result);
    }

    //완료문서 개인보관함 저장 
    function saveToPersonalStorage(){
        $this->load->model('STC_Approval' );
        $seq = $this->input->post('seq');
        $save_doc_seq = $this->input->post('save_doc_seq');
        $data = array(
            'seq'=> $seq,
            'save_doc_seq' => $save_doc_seq,
            'update_date' => date("Y-m-d H:i:s")
        );
        $result = $this->STC_Approval->storageSave($data,4);
        echo json_encode($result);
    }

    //개인보관함 저장 문서 삭제
    function storage_doc_delete(){
        $this->load->model('STC_Approval');
        $seq = $this->input->post('storage_seq');
        $delete_doc_seq = $this->input->post('delete_doc_seq');
        $result = $this->STC_Approval->storage_doc_delete($seq,$delete_doc_seq);
        echo json_encode($result);
    }
}
?>