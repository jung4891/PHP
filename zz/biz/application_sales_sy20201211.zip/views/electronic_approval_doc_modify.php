<?php
include $this->input->server('DOCUMENT_ROOT')."/include/base.php";
include $this->input->server('DOCUMENT_ROOT')."/include/sales_top.php";
$duty = $this->phpsession->get( 'duty', 'stc' );

$ap = "N"; //결재라인에 들어있니?
$approval_completion ='';
$next_approval_completion ='';
$filnal_approval="N";
if(empty($cur_approval_line) != true){
   $ap = "Y";
   $approval_completion = $cur_approval_line['approval_status'];
}

if(empty($next_approval_line) != true){
   $next_approval_completion = $next_approval_line['approval_status'];
}
if($ap == "Y" && empty($next_approval_line) == true){ //마지막 결재라인인지
   $filnal_approval ="Y";
}
?>
<style>
   p, div, span, a, a:hover, a:visited, a:active, label, input, h1,h2,h3,h4,h5,h6{font-family: "Noto Sans KR";}
   .basic_td{
      padding:0px 10px 0px 10px;
      border:1px solid;
      border-color:#d7d7d7;
   }
   .basic_table{
      border-collapse:collapse;
      border:1px solid;
      border-color:#d7d7d7;
   }

   .basic_table td{
      padding:0px 10px 0px 10px;
      border:1px solid;
      border-color:#d7d7d7;
   }

   .basicBtn2{
      cursor:pointer;
      height:31px;
      background-color:#fff;
      vertical-align:top;
      font-weight:bold;
      border : .5px solid;
      margin-right: 5px;
   }

   .file_upload{
      outline: 2px dashed #92b0b3 ;
      outline-offset:-10px;  
      text-align: center;
      transition: all .15s ease-in-out;
      width: 300px;
      height: 300px;
      background-color: gray;
   }

   /* 모달 css */
   .searchModal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 10; /* Sit on top */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
      z-index: 1002;
   }
      /* Modal Content/Box */
   .search-modal-content {
      background-color: #fefefe;
      margin: 15% auto; /* 15% from the top and centered */
      padding: 20px;
      border: 1px solid #888;
      width: 70%; /* Could be more or less, depending on screen size */
      z-index: 1002;
   }
   ul{
      list-style:none;
      padding-left:0px;
   }

   li{
      list-style:none;
      padding-left:0px;
   }

   input{
      border: none; 
      background: transparent;
   }
</style>
<link href="https://fonts.googleapis.com/css?family=Noto+Sans+KR" rel="stylesheet"> 
<script>
   function chkForm(){
		var mform = document.cform;
      $("#contents_html").val($("#formLayoutDiv").html());
      $("#editor_contents").val($('#summernote').summernote('code'));
      $("#approver_line").val($("#select_approver").html());
      alert($("#approver_line").val());
      $("#approval_request").val();  
		// var regex3 = /^[0-9]+$/;

		mform.submit();
		return false;
	}
</script>
<body>
<form name="cform" action="<?php echo site_url(); ?>/approval/electronic_approval_doc_input_action" method="post" onSubmit="javascript:chkForm();return false;">
   <input type="hidden" id="seq" name="seq" value="<?php echo $seq; ?>">
   <input type="hidden" id="select_user_id" name="select_user_id" value="">
   <input type="hidden" id="approval_form_seq" name="approval_form_seq" value="<?php echo $view_val['approval_form_seq']; ?>">
   <input type="hidden" id="contents_html" name="contents_html" value="" />
   <input type="hidden" id="editor_contents" name="editor_contents" value="<?php echo $view_val['editor_contents']; ?>" />
   <input type="hidden" id="approver_line" name="approver_line" value="" />
   <input type="hidden" id="approver_line_seq" name="approver_line_seq" value="<?php if(empty($cur_approval_line) != true){echo $cur_approval_line['seq']; }?>" />
   <input type="hidden" id="approval_doc_seq" name="approval_doc_seq" value="<?php echo $view_val['seq']; ?>" />
   <input type="hidden" id="next_approver_line_seq" name="next_approver_line_seq" value="<?php if(empty($next_approval_line) != true){echo $next_approval_line['seq']; } ?>" />
   <!-- <input type="hidden" id="approval_request" name="approval_request" value="" /> -->
   <table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
      <?php include $this->input->server('DOCUMENT_ROOT')."/include/sales_header.php"; ?>
      <tr>
         <td align="center" valign="top">
            <table width="90%" height="100%" cellspacing="0" cellpadding="0">
               <tr>
                  <td width="100%" align="center" valign="top">
                     <!--내용-->
                     <table width="100%" border="0" style="margin-top:50px; margin-bottom: 50px;">
                        <!--타이틀-->
                        <tr>
                           <td class="title3">
                           <?php if($type == "request"){
                              echo "결재요청함";
                           }else if($type == "temporary"){
                              echo "임시저장함";
                           }else if($type == "standby"){
                              echo "결재대기함";
                           }else if ($type == "progress"){
                              echo "결재진행함";
                           }else if ($type == "completion"){
                              echo "완료문서함";
                           }else if ($type == "back"){
                              echo "반려문서함";
                           }else if ($type == "reference"){
                              echo "참조/열람문서함";
                           }
                           ?>
                           </td>
                        </tr>
                        <!--타이틀-->
                        <tr>
                           <td>&nbsp;</td>
                        </tr>

                        <tr>
                           <!-- 내용 -->
                           <td>
                              <div style="font-family:Noto Sans KR;">
                                 <div style="text-align:right">
                                 <?php
                                    if($type == "standby"){
                                       echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="'.$cur_approval_line['approval_type'].'" onclick="approval_ok();" />';
                                       if($cur_approval_line['approval_type'] == "결재" && $view_val['approval_doc_hold'] == "N"){
                                          echo '<input type="button" class="basicBtn2" value="보류" onclick="hold(1)" />';
                                       }else if ($cur_approval_line['approval_type'] == "결재" && $view_val['approval_doc_hold'] == "Y"){
                                          echo '<input type="button" class="basicBtn2" value="보류취소" onclick="hold(0)" />';
                                       }
                                       echo '<input type="button" class="basicBtn2" value="결재선" />';
                                       echo '<input type="button" class="basicBtn2" value="참조자" />';
                                       echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                       echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                       echo '<input type="button" class="basicBtn2" value="목록" />';
                                    }else if($type == "progress"){
                                       if($next_approval_completion != "Y" && $next_approval_completion != ""){
                                          echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="결재취소" onclick="approval_save(0)" />';
                                       }
                                       
                                       if($id == $view_val['writer_id'] && $approval_line[0]['approval_status'] == "" && $view_val['approval_doc_hold'] != "Y" ){
                                          echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="결재회수" onclick="approval_withdraw();" />';
                                       }
                                       echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                       echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                       echo '<input type="button" class="basicBtn2" value="목록" />';
   
                                    }else if($type == "completion"){
                                       echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="재기안" />';
                                       echo '<input type="button" class="basicBtn2" value="pdf변환" />';
                                       echo '<input type="button" class="basicBtn2" value="열람권한" />';
                                       echo '<input type="button" class="basicBtn2" value="개인보관" />';
                                       echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                       echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                       echo '<input type="button" class="basicBtn2" value="목록" />';
                                    }else if($type == "back"){
                                       echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="재기안" />';
                                       echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                       echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                       echo '<input type="button" class="basicBtn2" value="목록" />';
                                    }else if($type == "request"){
                                       if($_GET['type2'] == "004"){
                                          echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="수정" />';
                                          echo '<input type="button" class="basicBtn2" value="삭제" />';
                                          echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                          echo '<input type="button" class="basicBtn2" value="목록" />';
                                       }else if ($_GET['type2'] == "002"){
                                          echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="재기안" />';
                                          echo '<input type="button" class="basicBtn2" value="pdf변환" />';
                                          echo '<input type="button" class="basicBtn2" value="열람권한" />';
                                          echo '<input type="button" class="basicBtn2" value="개인보관" />';
                                          echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                          echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                          echo '<input type="button" class="basicBtn2" value="목록" />';
                                       }else if ($_GET['type2'] == "003"){
                                          echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="재기안" />';
                                          echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                          echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                          echo '<input type="button" class="basicBtn2" value="목록" />';
                                       }else if($_GET['type2'] == "001"){
                                          if($next_approval_completion != "Y" && $next_approval_completion != ""){
                                             echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="결재취소" onclick="approval_save(0)" />';
                                          }
                                          if($id == $view_val['writer_id'] && $approval_line[0]['approval_status'] == "" && $view_val['approval_doc_hold'] != "Y" ){
                                             echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="결재회수" onclick="approval_withdraw();" />';
                                          }
                                          echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                          echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                          echo '<input type="button" class="basicBtn2" value="목록" />';
                                       }
                                    }
                                 ?>
                                 </div>
                                 <div style="text-align:center;font-size:30px;height:40px;">
                                 <!-- <input type="hidden" id="template_name" name="template_name" value="<?php echo $view_val['template_name']; ?>"> -->
                                    <?php echo $view_val['template_name']; ?>
                                 </div>
                                 <div>
                                    <table id="approver_line_table" class="basic_table" style="width:auto;text-align:center;margin-bottom:30px;">
                                       <tr><td height=40 rowspan=2 class="basic_td" width="20px" bgcolor="f8f8f9" >결재</td><td class="basic_td" width="100px" bgcolor="f8f8f9"><?php echo $duty; ?></td></tr>
                                       <tr><td height=40 class="basic_td" width="80px"><?php echo $name; ?></td></tr>
                                    </table>
                                 </div>
                                 <div>
                                    <table id="agreement_line_table" class="basic_table" style="width:auto;text-align:center;margin-bottom:30px;">
                                       <tr></tr>
                                       <tr></tr>
                                    </table>
                                 </div>
                                 <div>
                                    <table class="basic_table" style="width:100%;">
                                       <tr>
                                          <td width="15%" align="center" height=40 class="basic_td" bgcolor="f8f8f9">문서번호</td>
                                          <td width="35%" class="basic_td">자동채번</td>
                                          <td width="15%" align="center" class="basic_td" bgcolor="f8f8f9">기안일자</td>
                                          <td width="35%" class="basic_td"><input type="hidden" name="write_date" id="write_date" value="<?php echo $view_val['write_date']; ?>" /><?php echo $view_val['write_date']; ?></td>
                                       </tr>
                                       <tr>
                                          <td width="15%" align="center" height=40 class="basic_td" bgcolor="f8f8f9">기안자</td>
                                          <td width="35%" class="basic_td"><input type="hidden" name="writer_name" id="writer_name" value="<?php echo $view_val['writer_name']; ?>" /><?php echo $view_val['writer_name']; ?></td>
                                          <td width="15%" align="center" class="basic_td" bgcolor="f8f8f9">기안부서</td>
                                          <td width="35%" class="basic_td"><input type="hidden" name="writer_group" id="writer_group" value="<?php echo $view_val['writer_group']; ?>" /><?php echo $view_val['writer_group'];  ?></td>
                                       </tr>
                                       <tr>
                                          <td width="15%" align="center" height=40 class="basic_td" bgcolor="f8f8f9">참조자</td>
                                          <td width="35%" class="basic_td">
                                                <input id="referrer" name="referrer" type="text" class="input2" value="<?php echo $view_val['referrer']; ?>" />
                                                <img src="<?php echo $misc;?>img/btn_add.jpg" style="cursor:pointer;vertical-align:middle;" border="0" onClick="select_user('referrer');"/>
                                          </td>
                                          <td width="15%" align="center" class="basic_td" bgcolor="f8f8f9">기결재첨부</td>
                                          <td width="35%" class="basic_td">
                                             <?php
                                                $attach_seq = '';
                                                $attach_list = '';
                                                if($view_val['approval_attach'] != ''){
                                                   $attach = explode(',',$view_val['approval_attach']);
                                                   for($i=0; $i<count($attach); $i++){
                                                      $attach_seq .= ','.explode('--',$attach[$i])[0];
                                                      $attach_list .= "<div id='attach_".explode('--',$attach[$i])[0]."'><span name='attach_name' onclick='attach_view(".explode('--',$attach[$i])[0].")'>".explode('--',$attach[$i])[1]."</span><img src='{$misc}/img/btn_del2.jpg' style='vertical-align:middle;cursor:pointer;margin-left:5px;' onclick='attachRemove(".explode('--',$attach[$i])[0].")'/></div>";
                                                   }
                                                }
                                              ?>
                                             <input id="approval_attach" name="approval_attach" type="hidden" class="input7" value="<?php echo $attach_seq; ?>" />
                                             <div id="approval_attach_list" name="approval_attach_list">
                                                <?php echo $attach_list; ?>
                                             </div>   
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="15%" align="center" height=40 class="basic_td" bgcolor="f8f8f9">문서제목</td>
                                          <td colspan=3 class="basic_td">
                                             <input type="text" id="approval_doc_name" name="approval_doc_name" class="input7" value="<?php echo $view_val['approval_doc_name']; ?>">
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="15%" align="center" height=40 class="basic_td" bgcolor="f8f8f9">첨부파일</td>
                                          <td colspan=3 class="basic_td">
                                             <?php
                                                if($view_val['file_realname'] != ""){
                                                   $file = explode(',',$view_val['file_realname']);
                                                   $file_url = explode(',',$view_val['file_changename']);
                                                   for($i=0; $i<count($file); $i++){
                                                      echo $file[$i];
                                                      echo "<a href='{$misc}upload/electronic_approval/{$file_url[$i]}' download='{$file[$i]}'> <img src='{$misc}/img/download.svg' style='width:15px;vertical-align:middle;cursor:pointer'></a><br>";
                                                      // echo "<img src='{$misc}/img/download.svg' style='width:15px;vertical-align:middle;cursor:pointer' onclick='download(".'"'.$file_url[$i].'"'.")'><br>";
                                                   }
                                                } 
                                             ?>
                                             
                                            
                                          </td>
                                       </tr>
                                    </table>
                                 </div>
                                 <div id="formLayoutDiv" style="margin-top:30px;">
                                    <?php
                                       echo $view_val['contents_html']; 
                                    ?>
                                 </div>
                                 <?php if($view_val['editor_use'] == 'Y'){ ?>
                                    <!-- <div id="summernote" style="margin-top:30px;"></div> -->
                                    <textarea id="summernote"><?php echo $view_val['editor_contents']; ?></textarea>
                                 <?php } ?>
                                 <div style="margin-top:30px;">
                                    <img src="<?php echo $misc; ?>/img/file_upload.png" style="width:20px;float:left;vertical-align:middle;"><h3 style="float:left;margin:0px;">&nbsp;파일업로드</h3><br>
                                    <!-- <form name="uploadForm" id="uploadForm" enctype="multipart/form-data" method="post" > -->
                                       <?php
                                       $file_html = "";
                                       if($view_val['file_realname'] != ""){
                                          $file = explode(',',$view_val['file_realname']);
                                          for($i=0; $i<count($file); $i++){
                                             $file_html .= "<tr id='fileTr_{$i}'>";
                                             $file_html .= "<td class='left' >";
                                             $file_html .= $file[$i]." <a href='#' onclick='deleteFile({$i}); return false;' class='btn small bg_02'><img src='{$misc}/img/btn_del2.jpg' style='vertical-align:middle;'></a>";
                                             $file_html .= "</td>";
                                             $file_html .= "</tr>"; 
                                          }
                                       }
                                       ?>
                                       <table class="basic_table" width="100%" bgcolor="f8f8f9" height="auto" border="1px" style="margin-top:20px;" >
                                             <tbody id="fileTableTbody">
                                                <tr>
                                                   <td id="dropZone" height="100px">
                                                         이곳에 파일을 드래그 하세요.
                                                   </td>
                                                </tr>
                                             </tbody>
                                             <?php echo $file_html; ?>
                                       </table>
                                    <!-- </form> -->
                                    <!-- <a href="#" onclick="uploadFile(); return false;" class="btn bg_01">파일 업로드</a> -->
                                 </div>
                                 <?php if(empty($approval_line) != true){?>
                                 <div style="margin-top:30px;">
                                    <h3>결재의견</h3>
                                    <table class="basic_table" style="text-align:center;width:100%">
                                       <tr bgcolor="f8f8f9">
                                          <td width="15%" height="30" class="basic_td">결재</td>
                                          <td width="15%" class="basic_td">결재자</td>
                                          <td width="15%" class="basic_td">부서</td>
                                          <td width="20%" class="basic_td">결재일시</td>
                                          <td width="35%" class="basic_td">의견</td>
                                       </tr>
                                       <?php foreach($approval_line as $al){
                                          if($al['approval_status'] != ""){
                                             echo "<tr>";
                                             if($al['approval_status'] == "N"){
                                                echo "<td height='30' class='basic_td' style='color:red;'>반려</td>";
                                             }else{
                                                echo "<td height='30' class='basic_td'>{$al['approval_type']}</td>";
                                             }
                                             echo "<td height='30' class='basic_td'>{$al['user_name']}</td>";
                                             echo "<td height='30' class='basic_td'>{$al['user_group']}</td>";
                                             echo "<td height='30' class='basic_td'>{$al['approval_date']}</td>";
                                             echo "<td height='30' class='basic_td'>{$al['approval_opinion']}</td>";
                                             echo "</tr>";
                                          }
                                       }?>
                                    </table>
                                 </div>
                                 <?php }?>
                                 <?php if(empty($hold) != true){?>
                                 <div style="margin-top:30px;">
                                    <h3>보류의견</h3>
                                    <table class="basic_table" style="text-align:center;width:100%">
                                       <tr bgcolor="f8f8f9">
                                          <td width="15%" height="30" class="basic_td">상태</td>
                                          <td width="15%" class="basic_td">보류자</td>
                                          <td width="15%" class="basic_td">부서</td>
                                          <td width="20%" class="basic_td">처리일시</td>
                                          <td width="35%" class="basic_td">의견</td>
                                       </tr>
                                       <?php foreach($hold as $h){
                                          echo "<tr>";
                                          if($h['hold_status'] == "Y"){
                                             echo "<td height='30' class='basic_td'>보류</td>";
                                          }else{
                                             echo "<td height='30' class='basic_td'>해제</td>";
                                          }
                                          echo "<td height='30' class='basic_td'>{$h['holder']}</td>";
                                          echo "<td height='30' class='basic_td'>{$h['user_group']}</td>";
                                          echo "<td height='30' class='basic_td'>{$h['processing_date']}</td>";
                                          echo "<td height='30' class='basic_td'>{$h['hold_opinion']}</td>";
                                          echo "</tr>";
                                       }?>
                                    </table>
                                 </div>
                                 <?php }?>
                                 <div style="text-align:right;margin-top:30px;">
                                 <?php
                                    if($type == "standby"){
                                       echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="'.$cur_approval_line['approval_type'].'" onclick="approval_ok();" />';
                                       if($cur_approval_line['approval_type'] == "결재" && $view_val['approval_doc_hold'] == "N"){
                                          echo '<input type="button" class="basicBtn2" value="보류" onclick="hold(1)" />';
                                       }else if ($cur_approval_line['approval_type'] == "결재" && $view_val['approval_doc_hold'] == "Y"){
                                          echo '<input type="button" class="basicBtn2" value="보류취소" onclick="hold(0)" />';
                                       }
                                       echo '<input type="button" class="basicBtn2" value="결재선" />';
                                       echo '<input type="button" class="basicBtn2" value="참조자" />';
                                       echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                       echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                       echo '<input type="button" class="basicBtn2" value="목록" />';
                                    }else if($type == "progress"){
                                       if($next_approval_completion != "Y" && $next_approval_completion != ""){
                                          echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="결재취소" onclick="approval_save(0)" />';
                                       }
                                       
                                       if($id == $view_val['writer_id'] && $approval_line[0]['approval_status'] == "" && $view_val['approval_doc_hold'] != "Y" ){
                                          echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="결재회수" onclick="approval_withdraw();" />';
                                       }
                                       echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                       echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                       echo '<input type="button" class="basicBtn2" value="목록" />';
   
                                    }else if($type == "completion"){
                                       echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="재기안" />';
                                       echo '<input type="button" class="basicBtn2" value="pdf변환" />';
                                       echo '<input type="button" class="basicBtn2" value="열람권한" />';
                                       echo '<input type="button" class="basicBtn2" value="개인보관" />';
                                       echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                       echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                       echo '<input type="button" class="basicBtn2" value="목록" />';
                                    }else if($type == "back"){
                                       echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="재기안" />';
                                       echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                       echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                       echo '<input type="button" class="basicBtn2" value="목록" />';
                                    }else if($type == "request"){
                                       if($_GET['type2'] == "004"){
                                          echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="수정" />';
                                          echo '<input type="button" class="basicBtn2" value="삭제" />';
                                          echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                          echo '<input type="button" class="basicBtn2" value="목록" />';
                                       }else if ($_GET['type2'] == "002"){
                                          echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="재기안" />';
                                          echo '<input type="button" class="basicBtn2" value="pdf변환" />';
                                          echo '<input type="button" class="basicBtn2" value="열람권한" />';
                                          echo '<input type="button" class="basicBtn2" value="개인보관" />';
                                          echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                          echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                          echo '<input type="button" class="basicBtn2" value="목록" />';
                                       }else if ($_GET['type2'] == "003"){
                                          echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="재기안" />';
                                          echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                          echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                          echo '<input type="button" class="basicBtn2" value="목록" />';
                                       }else if($_GET['type2'] == "001"){
                                          if($next_approval_completion != "Y" && $next_approval_completion != ""){
                                             echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="결재취소" onclick="approval_save(0)" />';
                                          }
                                          if($id == $view_val['writer_id'] && $approval_line[0]['approval_status'] == "" && $view_val['approval_doc_hold'] != "Y" ){
                                             echo '<input type="button" class="basicBtn" style="margin-right:5px;" value="결재회수" onclick="approval_withdraw();" />';
                                          }
                                          echo '<input type="button" class="basicBtn2" value="진행현황" onclick="progressStatus();" />';
                                          echo '<input type="button" class="basicBtn2" value="인쇄" />';
                                          echo '<input type="button" class="basicBtn2" value="목록" />';
                                       }
                                    }
                                 ?>
                                 </div>
                              </div> 
                           </td>
                        </tr>
                     </table>
                     <div id="group_tree_modal" class="searchModal">
                        <div class="search-modal-content" style='height:auto; min-height:400px;overflow: auto;'>
                           <h2>사용자 선택</h2>
                              <div style="margin-top:30px;height:auto; min-height:300px;overflow:auto;">
                                 <input type="button" value="조직원 전체 선택" style="float:right;margin-bottom:5px;" onclick="select_user_add('all');" >
                                 <table class="basic_table" style="width:100%;height:300px;vertical-align:middle;">
                                    <tr>
                                       <td class ="basic_td" width="30%">
                                          <div id="groupTree">
                                             <ul>
                                                <li>
                                                <span style="cursor:pointer;" id="all" onclick="groupView(this)">
                                                   (주)두리안정보기술
                                                </span>
                                                <ul>
                                                <?php
                                                   foreach ( $group_val as $parentGroup ) {
                                                      if($parentGroup['childGroupNum'] <= 1){
                                                      ?>
                                                         <li>
                                                            <ins>&nbsp;</ins>
                                                            <span style="cursor:pointer;" id="<?php echo $parentGroup['groupName'];?>" onclick="groupView(this)">
                                                            <ins>&nbsp;</ins>
                                                            <?php echo $parentGroup['groupName'];?>
                                                            </span>
                                                         </li>
                                                      <?php
                                                      }else{
                                                      ?>
                                                         <li>
                                                            <img src="<?php echo $misc; ?>img/btn_add.jpg" id="<?php echo $parentGroup['groupName'];?>Btn" width="13" style="cursor:pointer;" onclick="viewMore(this)">
                                                            <span style="cursor:pointer;" id="<?php echo $parentGroup['groupName'];?>" onclick="groupView(this)">
                                                            <?php echo $parentGroup['groupName'];?>
                                                            </span>
                                                         </li>
                                                      <?php
                                                      }
                                                   }
                                                ?>
                                                </ul>
                                                </li>
                                             </ul>
                                          </div>
                                       </td>
                                       <td class ="basic_td" width="30%" align="center">
                                          <div class="click_group_user"></div>
                                       </td>
                                       <td class ="basic_td" width="10%" align="center">
                                          <div>
                                             <img src="<?php echo $misc;?>img/btn_right.jpg" style="cursor:pointer;width:22px;height:22px;" border="0" onClick="select_user_add();"/><br><br>
                                             <img src="<?php echo $misc;?>img/btn_left.jpg" style="cursor:pointer;width:22px;height:22px;" border="0" onClick="select_user_del();"/><br><br>
                                             <img src="<?php echo $misc;?>img/btn_del.jpg" style="cursor:pointer;width:22px;height:22px;" border="0" onClick="select_user_del('all');"/>
                                          </div>
                                       </td>
                                       <td class ="basic_td" width="30%" align="center">
                                          <div id="select_user">
                                          </div>
                                       </td>
                                    </tr>
                                 </table>
                              </div>
                              <div>
                                 <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;" border="0" onClick="closeModal();"/>
                                 <img src="<?php echo $misc;?>img/btn_ok.jpg" style="cursor:pointer;float:right;margin-top:5px;" border="0" onClick="saveUserModal();"/><br>
                              </div>
                        </div>
                     </div>
                     <div id="select_approval_modal" class="searchModal">
                        <div class="search-modal-content" style='height:auto; min-height:400px;overflow: auto;'>
                           <h2>결재선지정</h2>
                              <div style="margin-top:30px;height:auto; min-height:300px;overflow:auto;">
                                 <!-- <input type="button" value="조직원 전체 선택" style="float:right;margin-bottom:5px;" onclick="select_user_add('all');" > -->
                                 <table class="basic_table" style="width:100%;height:300px;vertical-align:middle;">
                                    <tr>
                                       <td class ="basic_td" width="30%">
                                          <div id="groupTree">
                                             <ul>
                                                <li>
                                                <span style="cursor:pointer;" id="all" onclick="groupView(this)">
                                                   (주)두리안정보기술
                                                </span>
                                                <ul>
                                                <?php
                                                   foreach ( $group_val as $parentGroup ) {
                                                      if($parentGroup['childGroupNum'] <= 1){
                                                      ?>
                                                         <li>
                                                            <ins>&nbsp;</ins>
                                                            <span style="cursor:pointer;" id="<?php echo $parentGroup['groupName'];?>" onclick="groupView(this)">
                                                            <ins>&nbsp;</ins>
                                                            <?php echo $parentGroup['groupName'];?>
                                                            </span>
                                                         </li>
                                                      <?php
                                                      }else{
                                                      ?>
                                                         <li>
                                                            <img src="<?php echo $misc; ?>img/btn_add.jpg" id="<?php echo $parentGroup['groupName'];?>Btn" width="13" style="cursor:pointer;" onclick="viewMore(this)">
                                                            <span style="cursor:pointer;" id="<?php echo $parentGroup['groupName'];?>" onclick="groupView(this)">
                                                            <?php echo $parentGroup['groupName'];?>
                                                            </span>
                                                         </li>
                                                      <?php
                                                      }
                                                   }
                                                ?>
                                                </ul>
                                                </li>
                                             </ul>
                                          </div>
                                       </td>
                                       <td class ="basic_td" width="30%" align="center">
                                          <div class="click_group_user"></div>
                                       </td>
                                       <td class ="basic_td" width="10%" align="center">
                                          결재방법
                                          <div>
                                             <input type="radio" name="approval_type" value="결재" checked />결재<br>
                                             <input type="radio" name="approval_type" value="합의" />합의<br><br>
                                             <img src="<?php echo $misc;?>img/btn_right.jpg" style="cursor:pointer;width:22px;height:22px;" border="0" onClick="approver_add();"/><br><br>
                                             <img src="<?php echo $misc;?>img/btn_left.jpg" style="cursor:pointer;width:22px;height:22px;" border="0" onClick="approver_del();"/><br><br>
                                          </div>
                                       </td>
                                       <td class ="basic_td" width="30%" align="center">
                                          <table id="select_approver" width="90%" class="basic_table sortable">
                                             <?php echo $view_val['approver_line']; ?>
                                             <!-- <tr bgcolor="f8f8f9">
                                                <td height="30"></td>
                                                <td height="30">결재</td>
                                                <td height="30"><?php echo $name." ".$duty." ".$group; ?></td>
                                             </tr> -->
                                          </table>
                                       </td>
                                    </tr>
                                 </table>
                              </div>
                              <div>
                                 <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;" border="0" onClick="closeModal();"/>
                                 <img src="<?php echo $misc;?>img/btn_ok.jpg" style="cursor:pointer;float:right;margin-top:5px;" border="0" onClick="saveApproverLineModal();"/><br>
                              </div>
                        </div>
                     </div>
                     <!-- 결재모달 -->
                     <div id="approval_modal" class="searchModal">
                        <div class="search-modal-content" style='height:auto; min-height:400px;overflow: auto;'>
                           <h2>결재처리</h2>
                              <div style="margin-top:30px;height:auto; min-height:300px;overflow:auto;">
                                 <table class="basic_table" style="width:100%;">
                                    <tr>
                                       <td bgcolor="f8f8f9" height="40" align="right" class="basic_td">결재처리</td>
                                       <td class="basic_td">
                                          <input type="radio" name="approval_status" value="Y" checked /><?php echo $cur_approval_line['approval_type']; ?>
                                          <input type="radio" name="approval_status" value="N" />반려
                                       </td>
                                    </tr>
                                    <tr>
                                       <td bgcolor="f8f8f9" align="right" class="basic_td">결재의견</td>
                                       <td class="basic_td">
                                          <textarea id="approval_opinion" name="approval_opinion" style="width:100%;height:200px;"></textarea>
                                       </td>
                                    </tr>
                                 </table>

                              </div>
                              <div>
                                 <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;" border="0" onClick="closeModal();"/>
                                 <input type="button" value="결재" class="basicBtn" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;width:64px;height:31px;" onclick="approval_save(1);" >
                              </div>
                        </div>
                     </div>
                     <!-- 진행현황모달 -->
                     <div id="progress_status_modal" class="searchModal">
                        <div class="search-modal-content" style='height:auto; min-height:400px;overflow: auto;'>
                           <h2>진행현황</h2>
                              <div style="margin-top:30px;height:auto; min-height:300px;overflow:auto;">
                                 <table class="basic_table" style="width:100%;text-align:center;">
                                    <tr bgcolor="f8f8f9">
                                       <td height=50 class="basic_td">순번</td>
                                       <td class="basic_td">결재자</td>
                                       <td class="basic_td">결재유형</td>
                                       <td class="basic_td">결재</td>
                                       <td class="basic_td">배정일시</td>
                                       <td class="basic_td">확인일시</td>
                                       <td class="basic_td">결재일시</td>
                                       <td class="basic_td">상세</td>
                                    </tr>
                                 
                                    <?php 
                                    $idx=1;
                                    foreach($approval_line as $al){
                                       echo "<tr>";
                                       echo "<td height=40 class='basic_td'>{$idx}</td>";
                                       echo "<td class='basic_td'>{$al['user_name']} {$al['user_duty']} {$al['user_group']}</td>";
                                       echo "<td class='basic_td'>{$al['approval_type']}</td>";
                                       if($al['approval_status'] == "N"){
                                          echo "<td class='basic_td'>반려</td>";
                                       }else if($al['approval_status'] == "Y" && $al['approval_type']=="결재"){
                                          echo "<td class='basic_td'>승인</td>";
                                       }else if($al['approval_status'] == "Y" && $al['approval_type']=="합의"){
                                          echo "<td class='basic_td'>합의</td>";
                                       }else{
                                          echo "<td class='basic_td'>미결</td>";
                                       }
                                       
                                       echo "<td class='basic_td'>{$al['assignment_date']}</td>";
                                       echo "<td class='basic_td'>{$al['check_date']}</td>";
                                       echo "<td class='basic_td'>{$al['approval_date']}</td>";
                                       echo "<td class='basic_td'>{$al['details']}</td>";    
                                       echo "</tr>";
                                    }?>
                                 </table>
                              </div>
                              <div>
                                 <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;" border="0" onClick="closeModal();"/>
                                 <input type="button" value="결재" class="basicBtn" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;width:64px;height:31px;" onclick="approval_save(1);" >
                              </div>
                        </div>
                     </div>
                     <!-- 보류모달 -->
                     <div id="hold_modal" class="searchModal">
                        <div class="search-modal-content" style='height:auto; min-height:400px;overflow: auto;'>
                           <h2>보류</h2>
                              <div style="margin-top:30px;height:auto; min-height:300px;overflow:auto;">
                                 <table class="basic_table" style="width:100%;text-align:center;">
                                    <tr>
                                       <td bgcolor="f8f8f9" align="right" height=200 class="basic_td">보류의견</td>
                                       <td  height=200 class="basic_td">
                                          <textarea id="hold_opinion" name="hold_opinion" style="width:100%;height:100%"></textarea>
                                       </td>
                                    </tr>
                                 </table>
                              </div>
                              <div>
                                 <img src="<?php echo $misc;?>img/btn_cancel.jpg" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;" border="0" onClick="closeModal();"/>
                                 <input type="button" value="저장" class="basicBtn" style="cursor:pointer;float:right;margin-left:5px;margin-top:5px;width:64px;height:31px;" onclick="hold('save');" >
                              </div>
                        </div>
                     </div>
                     <!--내용-->
                  </td>
               </tr>
            </table>
         </td>
      </tr>
      <!--하단-->
      <tr>
         <td align="center" height="100" bgcolor="#CCCCCC">
            <table width="1130" cellspacing="0" cellpadding="0">
               <tr>
                  <td width="197" height="100" align="center" background="<?php echo $misc;?>img/customer_f_bg.png"><img
                        src="<?php echo $misc;?>img/f_ci.png" /></td>
                  <td><?php include $this->input->server('DOCUMENT_ROOT')."/include/sales_bottom.php"; ?></td>
               </tr>
            </table>
         </td>
      </tr>
   </table>
</form>
<!-- <input type="button" value="썸머노트" onclick="summer();"> -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css" rel="stylesheet"> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>
<script>
   saveApproverLineModal();
    // 파일 리스트 번호
    var fileIndex = 0;
    // 등록할 전체 파일 사이즈
    var totalFileSize = 0;
    // 파일 리스트
    var fileList = new Array();
    // 파일 사이즈 리스트
    var fileSizeList = new Array();
    // 등록 가능한 파일 사이즈 MB
    var uploadSize = 50;
    // 등록 가능한 총 파일 사이즈 MB
    var maxUploadSize = 500;
 
    $(function (){
        // 파일 드롭 다운
        fileDropDown();
    });
 
    // 파일 드롭 다운
    function fileDropDown(){
        var dropZone = $("#dropZone");
        //Drag기능 
        dropZone.on('dragenter',function(e){
            e.stopPropagation();
            e.preventDefault();
            // 드롭다운 영역 css
            dropZone.css('background-color','#E3F2FC');
        });
        dropZone.on('dragleave',function(e){
            e.stopPropagation();
            e.preventDefault();
            // 드롭다운 영역 css
            dropZone.css('background-color','#FFFFFF');
        });
        dropZone.on('dragover',function(e){
            e.stopPropagation();
            e.preventDefault();
            // 드롭다운 영역 css
            dropZone.css('background-color','#E3F2FC');
        });
        dropZone.on('drop',function(e){
            e.preventDefault();
            // 드롭다운 영역 css
            dropZone.css('background-color','#FFFFFF');
            
            var files = e.originalEvent.dataTransfer.files;
            if(files != null){
                if(files.length < 1){
                    alert("폴더 업로드 불가");
                    return;
                }
                selectFile(files)
            }else{
                alert("ERROR");
            }
        });
    }
 
    // 파일 선택시
    function selectFile(files){
        // 다중파일 등록
        if(files != null){
            for(var i = 0; i < files.length; i++){
                // 파일 이름
                var fileName = files[i].name;
                var fileNameArr = fileName.split("\.");
                // 확장자
                var ext = fileNameArr[fileNameArr.length - 1];
                // 파일 사이즈(단위 :MB)
                var fileSize = files[i].size / 1024 / 1024;
                
                if($.inArray(ext, ['exe', 'bat', 'sh', 'java', 'jsp', 'html', 'js', 'css', 'xml']) >= 0){
                    // 확장자 체크
                    alert("등록 불가 확장자");
                    break;
                }else if(fileSize > uploadSize){
                    // 파일 사이즈 체크
                    alert("용량 초과\n업로드 가능 용량 : " + uploadSize + " MB");
                    break;
                }else{
                    // 전체 파일 사이즈
                    totalFileSize += fileSize;
                    
                    // 파일 배열에 넣기
                    fileList[fileIndex] = files[i];
                    
                    // 파일 사이즈 배열에 넣기
                    fileSizeList[fileIndex] = fileSize;
 
                    // 업로드 파일 목록 생성
                    addFileList(fileIndex, fileName, fileSize);
 
                    // 파일 번호 증가
                    fileIndex++;
                }
            }
        }else{
            alert("ERROR");
        }
    }
 
    // 업로드 파일 목록 생성
    function addFileList(fIndex, fileName, fileSize){
        var html = "";
        html += "<tr id='fileTr_" + fIndex + "'>";
        html += "    <td class='left' >";
        html +=         fileName + " / " + fileSize + "MB "  + "<a href='#' onclick='deleteFile(" + fIndex + "); return false;' class='btn small bg_02'><img src='<?php echo $misc;?>/img/btn_del2.jpg' style='vertical-align:middle;'></a>"
        html += "    </td>"
        html += "</tr>"
 
        $('#fileTableTbody').append(html);
    }
 
    // 업로드 파일 삭제
    function deleteFile(fIndex){
        // 전체 파일 사이즈 수정
        totalFileSize -= fileSizeList[fIndex];
        
        // 파일 배열에서 삭제
        delete fileList[fIndex];
        
        // 파일 사이즈 배열 삭제
        delete fileSizeList[fIndex];
        
        // 업로드 파일 테이블 목록에서 삭제
        $("#fileTr_" + fIndex).remove();
    }
 
    // 파일 등록
    function uploadFile(){
        // 등록할 파일 리스트
        var uploadFileList = Object.keys(fileList);
 
        // 파일이 있는지 체크
        if(uploadFileList.length == 0){
            // 파일등록 경고창
            alert("파일이 없습니다.");
            return;
        }
        
        // 용량을 500MB를 넘을 경우 업로드 불가
        if(totalFileSize > maxUploadSize){
            // 파일 사이즈 초과 경고창
            alert("총 용량 초과\n총 업로드 가능 용량 : " + maxUploadSize + " MB");
            return;
        }
            
        if(confirm("등록 하시겠습니까?")){
            // 등록할 파일 리스트를 formData로 데이터 입력
            var form = $('#uploadForm');
            var formData = new FormData(form);
            for(var i = 0; i < uploadFileList.length; i++){
                formData.append('files', fileList[uploadFileList[i]]);
            }
            
            $.ajax({
                url:"업로드 경로",
                data:formData,
                type:'POST',
                enctype:'multipart/form-data',
                processData:false,
                contentType:false,
                dataType:'json',
                cache:false,
                success:function(result){
                    if(result.data.length > 0){
                        alert("성공");
                        location.reload();
                    }else{
                        alert("실패");
                        location.reload();
                    }
                }
            });
        }
    }


    $('#summernote').summernote({ placeholder: 'Hello stand alone ui', tabsize: 2, height: 200 });

     //사용자 선택
   function select_user(s_id){
      $("#click_user").remove();
      $("#group_tree_modal").show();
      $("#select_user_id").val(s_id);
      if($("#"+$("#select_user_id").val()).val() != ""){
         var select_user = ($("#"+$("#select_user_id").val()).val()).split(',');
         var txt = '';
         for(i=0; i<select_user.length; i++){
            txt += "<div class='select_user' onclick='click_user("+'"'+select_user[i]+'"'+",this)'>"+select_user[i]+"</div>";
         }
         $("#select_user").html(txt);
      }
   }

   //사용자 선택 저장
   function saveUserModal(){
      var txt ='';
      for(i=0; i <$(".select_user").length; i++){
         var val = $(".select_user").eq(i).text().split(' ');
         if(i == 0){
            txt += val[0]+" "+val[1];
         }else{
            txt += "," + val[0]+" "+val[1];
         }
         $("#"+$("#select_user_id").val()).val(txt);
         $("#group_tree_modal").hide();
      }
   }

   // groupView();

   //상위 그룹에서 하위 그룹 보기
   function viewMore(button){
   var parentGroup = (button.id).replace('Btn','');
   if($(button).attr("src")==="<?php echo $misc; ?>img/btn_add.jpg"){
      var src = "<?php echo $misc; ?>img/btn_del0.jpg";
      $.ajax({
         type: "POST",
         cache: false,
         url: "<?php echo site_url(); ?>/ajax/childGroup",
         dataType: "json",
         async: false,
         data: {
         parentGroup:parentGroup
         },
         success: function (data) {
         var text = '<ul id="'+parentGroup+'Group" class="'+parentGroup+'" >';
         for(i=0; i<data.length; i++){
               text += '<li><ins>&nbsp;</ins><span style="cursor:pointer;" id="'+data[i].groupName+'" onclick="groupView(this)"><ins>&nbsp;</ins>'+data[i].groupName+'</span></li>';
         }
         text += '</ul>'
         //   $("#"+parentGroup).html($("#"+parentGroup).html()+text);
         $("#"+parentGroup).after(text);

         }
      }); 
   }else{
      var src = "<?php echo $misc; ?>img/btn_add.jpg";
      $("#"+parentGroup+"Group").hide();
      $("."+parentGroup).remove();
   }
   $("#"+parentGroup+"Btn").attr('src', src); 
   }

   //그룹 클릭했을 떄 해당하는 user 보여주기
   function groupView(group){
   if(group == undefined){
      var groupName = "all";
   }else{
      var groupName = $(group).attr("id");
   }
   
   $.ajax({
         type: "POST",
         cache: false,
         url: "<?php echo site_url(); ?>/ajax/groupView",
         dataType: "json",
         async: false,
         data: {
         group:groupName
         },
         success: function (data) {
            var txt = '';
            for(i=0; i<data.length; i++){
                  txt +=  "<div class='click_user' onclick='click_user("+'"'+data[i].user_name+'",this'+");'>"+data[i].user_name+" "+data[i].user_duty+" "+data[i].user_group+ "</div>";
            }
            $(".click_group_user").html(txt);
         }
   });
   }

   //user || approver 선택
   function click_user(name,obj){
      $(".click_user").css('background-color','');
      $(".select_user").css('background-color','');
      $(".select_approver").css('background-color','');
      $(".click_user").attr('id','');
      $(".select_user").attr('id','');
      $(".select_approver").attr('id','');
      $(obj).css('background-color','#f8f8f9');
      $(obj).attr('id','click_user');
   }

   //user 추가
   function select_user_add(type){
      if(type == 'all'){
         var result = confirm("회사 내 전체 조직원을 선택하시겠습니까?");
         if(result){
            $.ajax({
               type: "POST",
                  cache: false,
                  url: "<?php echo site_url(); ?>/ajax/groupView",
                  dataType: "json",
                  async :false,
                     data: {
                        group: 'all'
                     },
                     success: function (data) {
                        var html = '';
                        for (i = 0; i < data.length; i++) {
                           html += "<div class='select_user' onclick='click_user("+'"'+data[i].user_name+'"'+",this)'>"+data[i].user_name+" "+data[i].user_duty+" "+data[i].user_group+"</div>";
                        }
                        $("#select_user").html(html);
                     }
            });
         }else{
         return false;
         }
      }else{
         var duplicate_check = false;
         for(i=0; i<$(".select_user").length; i++){
            if($("#click_user").html() == $(".select_user").eq(i).text()){
               duplicate_check = true
            }
         }
         if(duplicate_check == true || $("#click_user").html() == undefined){
            return false;
         }else{
            var html = "<div class='select_user' onclick='click_user("+'"'+$("#click_user").html()+'"'+",this)'>"+$("#click_user").html()+"</div>";
            $("#select_user").html($("#select_user").html()+html);
         }
      }

   }

   //추가된 user 중에 삭제
   function select_user_del(type){
      if(type == "all"){
         $(".select_user").remove();
      }else{
         if($("#click_user").attr('class') == 'select_user'){
            $("#click_user").remove();
         }
      }
   }

   //사용자 선택 모달 닫아
   function closeModal(){
      var check = confirm("이 페이지에서 나가시겠습니까? 작성중인 내용은 저장 되지 않습니다.")
      if(check == true){ 
         $(".searchModal").hide();
      }else{
         return false;
      }
   }

   function select_approval_modal(){
      $("#click_user").remove();
      $("#select_approval_modal").show();
   }

   //결재선 추가
   function approver_add(){
      var duplicate_check = false;
      for(i=0; i<$(".select_approver").length; i++){
         if($(".select_approver").eq(i).html().indexOf($("#click_user").html())!= -1){
            duplicate_check = true
         }
      }

      var approval_type = $('input:radio[name=approval_type]:checked').val();
      if(duplicate_check == true || $("#click_user").html() == undefined){
         return false;
      }else{
         for(i=0; i < $("#select_approver").find($("td")).length; i++){
            if($("#select_approver").find($("td")).eq(i).html() == "최종"){
               $("#select_approver").find($("td")).eq(i).html("");
            }
         }
         var html = "<tr class='select_approver' onclick='click_user("+'"'+$("#click_user").html()+'"'+",this)'>";
         html += "<td height=30>최종</td><td onclick='change_approval_type(this);' style='cursor:pointer;'>"+approval_type+"</td><td>"+$("#click_user").html()+"</td>";
         html += "</tr>";
         $("#select_approver").html($("#select_approver").html()+html);
      }

   }

   //결재선 삭제
   function approver_del(){
      if($("#click_user").attr('class') == 'select_approver'){
         $("#click_user").remove();
         finalReferrer();
      }
   }

   //sortable tr 상하이동
   $(".sortable").sortable({
      start: function(event, ui) {
         finalReferrer();
      },
      stop: function(event, ui) {
         finalReferrer();
      },
   });

   //결재선 마지막 줄 최종으로 표시
   function finalReferrer(){
      for(i=0; i < $("#select_approver").find($("td")).length; i++){
         if($("#select_approver").find($("td")).eq(i).html() == "최종"){
            $("#select_approver").find($("td")).eq(i).html("");
         }else if(i == ($("#select_approver").find($("td")).length)-3){
            $("#select_approver").find($("td")).eq(i).html("최종");
         }
      }
   }

   //결재 <-> 합의 바꿔
   function change_approval_type(obj){
      if($(obj).html()=="결재"){
         $(obj).html("합의");
      }else{
         $(obj).html("결재");
      }
   }

   //결재선 저장
   function saveApproverLineModal(){
      var tr = $("#select_approver").find($("tr"));
      $("#approver_line_table").find($("tr")).eq(0).html('<td height=40 rowspan=2 class="basic_td" width="20px" bgcolor="f8f8f9" >결재</td>');
      $("#approver_line_table").find($("tr")).eq(1).html("");
      
      $("#agreement_line_table").find($("tr")).eq(0).html('<td height=40 rowspan=2 class="basic_td" width="20px" bgcolor="f8f8f9" >합의</td>');
      $("#agreement_line_table").find($("tr")).eq(1).html("");
      for(i=0; i<tr.length; i++){
         if(tr.eq(i).html().indexOf("결재") != -1){ //결재부분
            var text = tr.eq(i).find($("td")).eq(tr.eq(i).find($("td")).length -1).html();
            text = text.split(' ');
            var duty = text[1];
            var name = text[0];
            $("#approver_line_table").find($("tr")).eq(0).append('<td class="basic_td" width="80px" bgcolor="f8f8f9">'+duty+'</td>');
            $("#approver_line_table").find($("tr")).eq(1).append("<td height=40>"+name+"</td>");
         }else{
            var text = tr.eq(i).find($("td")).eq(tr.eq(i).find($("td")).length -1).html();
            text = text.split(' ');
            var duty = text[1];
            var name = text[0];
            $("#agreement_line_table").find($("tr")).eq(0).append('<td class="basic_td" width="80px" bgcolor="f8f8f9">'+duty+'</td>');
            $("#agreement_line_table").find($("tr")).eq(1).append("<td height=40>"+name+"</td>");
         }
      }
      $("#select_approval_modal").hide();
   }

   function attach_view(seq){
      window.open('<?php echo site_url();?>/approval/electronic_approval_doc_view?seq='+seq,'_blank',"width = 1200, height = 1000, top = 100, left = 400, location = no,status=no,status=no,toolbar=no,scrollbars=no");

   }

   // function download(url){
   //    console.log(url)
   //    var test = "<?php echo $misc; ?>upload/electronic_approval/"+url;
   //    console.log(test)
   //    window.open(test);
   // }

   //결재모달
   function approval_ok(){
      $("#approval_modal").show();
   }
   
   function approval_save(t){
      if(t == '1'){
         $.ajax({
            type: "POST",
            cache: false,
            url: "<?php echo site_url(); ?>/approval/approval_save",
            dataType: "json",
            async :false,
            data: {
               seq : $("#approver_line_seq").val(),
               next_seq : $("#next_approver_line_seq").val(),
               approval_status: $("input[name=approval_status]:checked").val(),
               approval_opinion: $("#approval_opinion").val(),
               approval_doc_seq: $("#approval_doc_seq").val(),
               final_approval: "<?php echo $filnal_approval; ?>"
            },
            success: function (data) {
               if(data){
                  alert("결재가 저장되었습니다.");
                  location.reload();
               }else{
                  alert("결재저장 실패!");
               }
            }
         });
      }else{ //결재 취소 눌렀을때
         if(confirm("결재 취소 하시겠습니까?")){
            $.ajax({
               type: "POST",
               cache: false,
               url: "<?php echo site_url(); ?>/approval/approval_save",
               dataType: "json",
               async :false,
               data: {
                  seq : $("#approver_line_seq").val(),
                  next_seq : $("#next_approver_line_seq").val(),
                  approval_status: '',
                  approval_opinion: ''
               },
               success: function (data) {
                  if(data){
                     alert("결재가 취소되었습니다.");
                     location.reload();
                  }else{
                     alert("결재취소 실패!");
                  }
               }
            });
         }
      }
   }

   //진행현황 클릭!
   function progressStatus(){
      $("#progress_status_modal").show();
   }

   //결재회수
   function approval_withdraw(){
      $.ajax({
         type: "POST",
         cache: false,
         url: "<?php echo site_url(); ?>/approval/approval_withdraw",
         dataType: "json",
         async :false,
         data: {
            seq : $("#seq").val(),
            approval_doc_status : "004"
         },
         success: function (data) {
            if(data){
               alert("결재가 회수되었습니다.");
               location.reload();
            }else{
               alert("결재 회수가 실패하였습니다.");
            }
         }
      })
   }

   function hold(t){
      if(t == 1){ // 보류
         $("#hold_modal").show();

      }else if(t == 0){ //보류취소
         $.ajax({
            type: "POST",
            cache: false,
            url: "<?php echo site_url(); ?>/approval/approval_hold",
            dataType: "json",
            async :false,
            data: {
               seq : $("#seq").val(),
               approval_doc_hold : "N",
               hold_opinion: $("#hold_opinion").val()
            },
            success: function (data) {
               if(data){
                  alert("보류 취소 되었습니다.");
                  location.reload();
               }else{
                  alert("보류 취소 처리에 실패하였습니다.");
               }
            }
         })
      }else if (t == 'save'){
         $.ajax({
            type: "POST",
            cache: false,
            url: "<?php echo site_url(); ?>/approval/approval_hold",
            dataType: "json",
            async :false,
            data: {
               seq : $("#seq").val(),
               approval_doc_hold : "Y",
               hold_opinion: $("#hold_opinion").val()
            },
            success: function (data) {
               if(data){
                  alert("보류되었습니다.");
                  location.reload();
               }else{
                  alert("보류처리 실패하였습니다.");
               }
            }
         })
      }
   }
</script>
</body>
</html>
