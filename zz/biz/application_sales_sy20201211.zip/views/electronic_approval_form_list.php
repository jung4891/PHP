<?php
  include $this->input->server('DOCUMENT_ROOT')."/include/base.php";
  include $this->input->server('DOCUMENT_ROOT')."/include/sales_top.php";
  $mode = $_GET['mode'];
?>
<style>
   p, div, span, a, a:hover, a:visited, a:active, label, input, h1,h2,h3,h4,h5,h6{font-family: "Noto Sans KR";}
   .basic_td{
      border:1px solid;
      border-color:#d7d7d7;
   }
   .basic_table{
      border-collapse:collapse;
      border:1px solid;
      border-color:#d7d7d7;
   }

</style>
<link href="https://fonts.googleapis.com/css?family=Noto+Sans+KR" rel="stylesheet"> 
  
<script>
</script>
<body>
<form name="cform" action="<?php echo site_url(); ?>/approval/electronic_approval_form_popup" method="post" target="popup_window" onSubmit="javascript:openPopup();return false;">
   <input type="hidden" name="popup_id" value="">
   <input type="hidden" name="popup_multi" value="">
   <input type="hidden" name="popup_template" value="">
</form>
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
      <input type="hidden" id="seq" name="seq" value="">
      <!-- <input type="hidden" name="mode" value=""> -->
      <?php include $this->input->server('DOCUMENT_ROOT')."/include/sales_header.php"; ?>
      <tr>
         <td align="center" valign="top">
            <table width="90%" height="100%" cellspacing="0" cellpadding="0">
               <tr>
                  <td width="100%" align="center" valign="top">
                     <!--내용-->
                     <table width="100%" border="0" style="margin-top:50px; margin-bottom: 50px;">
                        <!--타이틀-->
                        <tr>
                           <?php if($mode == "admin"){
                              echo '<td class="title3">양식 관리</td>';
                           }else{
                              echo '<td class="title3">기안문작성</td>';
                           }?>
                        </tr>
                        <!--타이틀-->
                        <tr>
                           <td>&nbsp;</td>
                        </tr>
                        <tr>
                           <td height="60">
                              <select class="input2">
                                 <option value="">서식함</option>
                                 <?php foreach( $category as $ct){
                                    echo "<option value='{$ct['category_name']}'>{$ct['category_name']}</option>";
                                 }?>
                              </select>
                           </td>
                        </tr>                       
                        <tr>
                           <td height="30">
                              <h3>전자결재 양식 목록</h3>
                           </td>
                        </tr>
                        <tr>
                           <!-- 내용 -->
                           <td> 
                              <table class="basic_table" width="100%" style="font-family:Noto Sans KR">
                                 <tr class="t_top" align="center" bgcolor="f8f8f9" >
                                    <td height=50 class="basic_td">NO</td>
                                    <td class="basic_td">시스템</td>
                                    <td class="basic_td">서식함</td>
                                    <td class="basic_td">즐겨찾기</td>
                                    <td class="basic_td">양식명</td>
                                    <!-- <td class="basic_td">담당부서</td>
                                    <td class="basic_td">담당자</td> -->
                                 </tr>
                                 <?php 
                                 $idx = 1;
                                 foreach($view_val as $form){
                                    echo "<tr align='center' onmouseover='this.style.backgroundColor=".'"'."#FAFAFA".'"'."' onmouseout='this.style.backgroundColor=".'"'.'#fff'.'"'."' style='cursor:pointer;' onclick='eletronic_approval_view({$form['seq']})'>";
                                    echo "<td height='40' class='basic_td'>{$idx}</td>";
                                    echo "<td class='basic_td'></td>";
                                    echo "<td class='basic_td'>{$form['template_category']}</td>";
                                    echo "<td class='basic_td'></td>";
                                    echo "<td class='basic_td'>{$form['template_name']}</td>";
                                    // echo "<td class='basic_td'></td>";
                                    // echo "<td class='basic_td'></td>";
                                    echo "</tr>";
                                    $idx ++;
                                 }
                                 ?>

                              </table>
     
                           </td>
                        </tr>
                     </table>
                     <?php if($mode == "admin"){ ?>
                     <input type="button" class="basicBtn" value="양식작성" style="float:right;margin-bottom:20px;" onclick="approval_form_input();" />
                     <?php } ?>
                     <!--내용-->
                  </td>
               </tr>
            </table>
         </td>
      </tr>
      <!--하단-->
      <tr>
         <td align="center" height="100" bgcolor="#CCCCCC">
            <table width="1130" cellspacing="0" cellpadding="0">
               <tr>
                  <td width="197" height="100" align="center" background="<?php echo $misc;?>img/customer_f_bg.png"><img
                        src="<?php echo $misc;?>img/f_ci.png" /></td>
                  <td><?php include $this->input->server('DOCUMENT_ROOT')."/include/sales_bottom.php"; ?></td>
               </tr>
            </table>
         </td>
      </tr>
</table>
<script>
   function eletronic_approval_view(seq){
      <?php if($mode == "admin"){ ?>
        location.href="<?php echo site_url(); ?>/approval/electronic_approval_form?seq="+seq+"&mode=modify";
      <?php }else{ ?>
        location.href="<?php echo site_url(); ?>/approval/electronic_approval_doc_input?seq="+seq;
      <?php }?>
      
      // location.href="<?php echo site_url(); ?>/approval/electronic_approval_form_input?seq="+seq;
   }

   function approval_form_input(){
      location.href="<?php echo site_url(); ?>/approval/electronic_approval_form?mode=input";
   }
  
</script>
</body>
</html>
