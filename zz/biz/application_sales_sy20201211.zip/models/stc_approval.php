<?php
header("Content-type: text/html; charset=utf-8");

class STC_Approval extends CI_Model {

	function __construct() {

		parent::__construct();
		$this->user_id = $this->phpsession->get( 'id', 'rms' );
		$this->name = $this->phpsession->get( 'name', 'stc' );
		$this->id = $this->phpsession->get( 'id', 'stc' );
	}

	//서식함 카테고리 가져오기
	function select_format_category() {
		$sql = "select * from format_category";
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	//전자결재 양식 작성 결재정보 저장
	function approval_info_save($data,$mode){
		if($mode == "insert"){
			$this->db->insert('electronic_approval_form',$data);
			return $this->db->insert_id();
		}else{
			$result = $this->db->update('electronic_approval_form',$data,array('seq' => $data['seq']));
			return $result;
		}
		
	}

	//전자결재 양식 작성 양식내용 저장
	function template_info_save($data,$seq){
		$result = $this->db->update('electronic_approval_form',$data,array('seq' => $seq));
		return $result;
	}

	//조직도 그룹 별로 보기 & 부서변경 페이지에서 memeber 보기
	function groupView($group){
		if(strpos($group,",") === false){
			if($group == "all"){
				$sql = "select * from user order by seq asc";
			}else{
				$sql = "select * from user where user_group='".$group."' order by seq asc";
			}
		}else{
			$seq = explode(',',$group);
			$sql = "select * from user where seq ='{$seq[1]}' ";

			for($i=2; $i<count($seq); $i++){
				$sql .= "or seq = '{$seq[$i]}'" ;
			}

		}

		$query = $this->db->query( $sql );

		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->result_array();
		}
	}

	//그룹 전체 가져오기
	function group(){
		$sql = "select * from user_group ";
		$query = $this->db->query( $sql );

		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->result_array();
		}
	}
	

	//상위그룹 가져오기
	function parentGroup(){
		$sql = "select * from user_group where groupName=parentGroupName order by seq asc";
		$query = $this->db->query( $sql );

		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->result_array();
		}
	}

	//상위 그룹에 맞는 하위그룹 가져오기
	function childGroup($parentGroup){
		$sql = "select * from user_group where parentGroupName='{$parentGroup}' and groupName<>'{$parentGroup}'";
		$query = $this->db->query( $sql );

		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->result_array();
		}
	}

	//전자결재 폼 list
	function approval_form_list(){
		$sql = "select * from electronic_approval_form";
		$query = $this->db->query( $sql );
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->result_array();
		}
	}

	//전자결재 폼 보여줘
	function approval_form_view($seq){
		$sql = "select * from electronic_approval_form where seq={$seq}";
		$query = $this->db->query( $sql );
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->row_array();
		}
	}

	//기안문 저장!
	function electronic_approval_doc_insert($data){
		$result = $this->db->insert('electronic_approval_doc',$data);
		return $this->db->insert_id();
	}

	//기안문 뷰
	function approval_doc_view($seq){
		$sql = "select ead.*,eaf.template_name,eaf.template_category,eaf.editor_use,u.user_duty 
		FROM electronic_approval_doc AS ead 
		JOIN electronic_approval_form eaf 
		ON ead.approval_form_seq = eaf.seq
		join user as u
		on ead.writer_id = u.user_id 
		where ead.seq = {$seq}";
		$query = $this->db->query( $sql );
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->row_array();
		}
	}

	//결재요청함 / 임시저장함 리스트
	function approval_doc_list($type){
		if($type == "request"){ //결재요청함
			$sql = "SELECT ead.*,eaf.template_category FROM electronic_approval_doc AS  ead
			JOIN electronic_approval_form AS eaf
			ON ead.approval_form_seq = eaf.seq where ead.approval_doc_status != '005' and ead.writer_id = '{$this->id}'";
		}else{
			$sql = "SELECT ead.*,eaf.template_category FROM electronic_approval_doc AS  ead
			JOIN electronic_approval_form AS eaf
			ON ead.approval_form_seq = eaf.seq where ead.approval_doc_status = '005' and ead.writer_id = '{$this->id}'";
		}

		$query = $this->db->query( $sql );
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->result_array();
		}
	}

	function electronic_approval_line_insert($doc_seq,$user_seq,$step,$approval_type){
		if($step == '0'){
			$sql = "insert into electronic_approval_line (approval_doc_seq,user_seq,approval_type,assignment_date,step) values('{$doc_seq}','{$user_seq}','{$approval_type}','".date("Y-m-d H:i:s")."','{$step}')";
		}else{
			$sql = "insert into electronic_approval_line (approval_doc_seq,user_seq,approval_type,step) values('{$doc_seq}','{$user_seq}','{$approval_type}','{$step}')";
		}
		
		return $this->db->query( $sql );
	}
	
	function approval_list($type){
		if($type == "standby"){
			$sql ="SELECT eal.*,u.user_id,u.user_name,u.user_group,ead.*,eaf.template_category,eaf.template_name  FROM electronic_approval_line as eal JOIN user u
			ON eal.user_seq = u.seq
			JOIN electronic_approval_doc AS ead
			ON ead.seq = eal.approval_doc_seq
			JOIN electronic_approval_form AS eaf
			ON eaf.seq = ead.approval_form_seq 
			WHERE ead.approval_doc_status = '001' and eal.assignment_date != '' && eal.approval_date IS NULL AND u.user_id ='".$this->id."'";
        }else if($type== "progress"){
            $sql = "SELECT ead.*,al.*,eaf.template_category,eaf.template_name  FROM electronic_approval_doc AS ead
			LEFT JOIN (SELECT eal.approval_doc_seq,eal.user_seq,eal.approval_type,eal.approval_status,eal.assignment_date,eal.check_date,eal.approval_date,eal.approval_opinion,eal.details,eal.step,u.user_id,u.user_name from electronic_approval_line AS eal JOIN user AS u ON eal.user_seq = u.seq) AS al
			ON  al.approval_doc_seq = ead.seq
			JOIN electronic_approval_form AS eaf
			ON eaf.seq = ead.approval_form_seq
			WHERE ((al.user_name ='".$this->name."' and al.approval_date is not null)
			OR (ead.writer_name ='".$this->name."')) and ead.approval_doc_status = '001' GROUP BY ead.seq";
        }else if($type == "completion"){
			$sql = "SELECT ead.*,al.*,eaf.template_category,eaf.template_name FROM electronic_approval_doc AS ead
			LEFT JOIN (SELECT eal.approval_doc_seq,eal.user_seq,eal.approval_type,eal.approval_status,eal.assignment_date,eal.check_date,eal.approval_date,eal.approval_opinion,eal.details,eal.step,u.user_id,u.user_name from electronic_approval_line AS eal JOIN user AS u ON eal.user_seq = u.seq) AS al
			ON  al.approval_doc_seq = ead.seq
			JOIN electronic_approval_form AS eaf
			ON eaf.seq = ead.approval_form_seq
			WHERE (al.user_name ='".$this->name."' OR ead.writer_name ='".$this->name."') and ead.approval_doc_status = '002' and ead.completion_date IS not NULL GROUP BY ead.seq";
        }else if($type== "back"){
			$sql = "SELECT ead.*,al.*,eaf.template_category,eaf.template_name FROM electronic_approval_doc AS ead
			LEFT JOIN (SELECT eal.approval_doc_seq,eal.user_seq,eal.approval_type,eal.approval_status,eal.assignment_date,eal.check_date,eal.approval_date,eal.approval_opinion,eal.details,eal.step,u.user_id,u.user_name from electronic_approval_line AS eal JOIN user AS u ON eal.user_seq = u.seq) AS al
			ON  al.approval_doc_seq = ead.seq
			JOIN electronic_approval_form AS eaf
			ON eaf.seq = ead.approval_form_seq
			WHERE (al.user_name ='".$this->name."' OR ead.writer_name ='".$this->name."') and ead.approval_doc_status = '003' GROUP BY ead.seq";
        }else if($type == "reference"){
			$sql = "SELECT ead.*,al.*,eaf.template_category,eaf.template_name FROM electronic_approval_doc AS ead
			LEFT JOIN (SELECT eal.approval_doc_seq,eal.user_seq,eal.approval_type,eal.approval_status,eal.assignment_date,eal.check_date,eal.approval_date,eal.approval_opinion,eal.details,eal.step,u.user_id,u.user_name from electronic_approval_line AS eal JOIN user AS u ON eal.user_seq = u.seq) AS al
			ON  al.approval_doc_seq = ead.seq
			JOIN electronic_approval_form AS eaf
			ON eaf.seq = ead.approval_form_seq
			WHERE (ead.referrer like '%".$this->name."%') GROUP BY ead.seq";
		}

		$query = $this->db->query( $sql );
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->result_array();
		}
	}

	//결재자 라인에 내가 잇으면 가져와봥!
	function cur_approval_line($seq){
		$sql = "select eal.*,u.user_id,u.user_name,u.user_group from electronic_approval_line as eal join user as u on eal.user_seq=u.seq where approval_doc_seq = {$seq} and u.user_name ='{$this->name}'";
		$query = $this->db->query( $sql );
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->row_array();
		}
	}

	//내 다음 스텝의 결재자
	function next_approval_line($seq){
		$sql = "select eal.*,u.user_id,u.user_name,u.user_group from electronic_approval_line as eal join user as u on eal.user_seq=u.seq where eal.step = (select eal.step+1 as step from electronic_approval_line as eal join user as u on eal.user_seq=u.seq where approval_doc_seq = {$seq} and u.user_name ='{$this->name}') and approval_doc_seq = {$seq}";
		$query = $this->db->query( $sql );
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->row_array();
		}
	}

	function approval_line($seq){
		$sql = "select eal.*,u.user_id,u.user_name,u.user_group,u.user_duty from electronic_approval_line as eal join user as u on eal.user_seq=u.seq where eal.approval_doc_seq={$seq}"; 
		$query = $this->db->query( $sql );
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->result_array();
		}
	}

	//결재 저장 (승인인지 반려인지 결재 취소인지 등등)
	function approval_save($data,$next_seq){
		$result = $this->db->update('electronic_approval_line',$data,array('seq' => $data['seq']));

		if($next_seq != ""){
			if($data['approval_status'] =="Y"){//결재 
				$sql = "update electronic_approval_line set assignment_date = '".date("Y-m-d H:i:s")."' where seq = {$next_seq}";
			}else if($data['approval_status'] == ""){//결재취소할때
				$sql = "update electronic_approval_line set assignment_date = null where seq = {$next_seq}";
			}
			$result = $this->db->query( $sql );
		}
		return $result;
	}

	// 전자결재 기안문 수정
	function electronic_approval_doc_update($data){
		$result = $this->db->update('electronic_approval_doc',$data,array('seq' => $data['seq']));
		return $result;
	}

	// 결재라인 삭제
	function electronic_approval_line_delete($seq){
		$sql = "delete from electronic_approval_line where approval_doc_seq = '{$seq}'";
		$result = $this->db->query( $sql );
		return $result;
	}

	function electronic_approval_hold_insert($data,$mode){
		if($mode == "1"){//insert
			$result = $this->db->insert('electronic_approval_hold',$data);
		}else{//update
			$sql = "update electronic_approval_hold set 
			hold_status = '{$data['hold_status']}',
			processing_date = '{$data['processing_date']}'
			where approval_doc_seq = {$data['approval_doc_seq']} order by seq desc limit 1";
			$result = $this->db->query( $sql );
		}
		
		return $result;
	}

	
	function approval_hold_select($seq){
		$sql = "select * from electronic_approval_hold where approval_doc_seq= {$seq} ";
		$query = $this->db->query( $sql );
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->result_array();
		}
	}

	function electronic_approval_line_update($data){
		$result = $this->db->update('electronic_approval_line',$data,array('seq' => $data['seq']));
		return $result;
	}

	//사용자 결재선 저장
	function user_approval_line_save($data,$type){
		if($type == 1){ //insert
			return  $this->db->insert('user_approval_line',$data);
		}
	}
	
	//사용자 결재선 조회
	function user_approval_line_select($id){
		$sql = "select * from user_approval_line where user_id = '{$id}'";
		$query = $this->db->query($sql);
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->result_array();
		}
	}

	//사용자 가져오기
	function select_user($seq){
		$sql = "select * from user where seq = '{$seq}'";
		$query = $this->db->query($sql);
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->row_array();
		}
	}
	
	//위임저장
	function delegation_save($data){
		return $this->db->insert('electronic_approval_delegation',$data);
	}

	//위임 리스트
	function electronic_approval_delegation_list(){
		$sql = "select * from electronic_approval_delegation";
		$query = $this->db->query($sql);
		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->result_array();
		}
	}
}
?>