<?php
// 페이징 정적인 부분 처리
$config['num_links'] = 2;
$config['first_link'] = '<< &nbsp&nbsp';
$config['first_tag_open'] = '<span style="letter-spacing:0px;">';
$config['first_tag_close'] = '</span>';
$config['last_link'] = ' >>';
$config['last_tag_open'] = '<span style="letter-spacing:0px;">';
$config['last_tag_close'] = '</span>';
$config['next_link'] = '';
$config['prev_link'] = '';
$config['cur_tag_open'] = '<span style="color:red;">';
$config['cur_tag_close'] = '</span>';

 ?>
