<?php
$misc = base_url().'misc/';

 ?>
