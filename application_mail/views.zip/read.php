<?php
include $this->input->server('DOCUMENT_ROOT')."/include/base.php";
include $this->input->server('DOCUMENT_ROOT')."/include/mail_header.php";
include $this->input->server('DOCUMENT_ROOT')."/include/mail_side.php";
 ?>


<div id="main_contents">


</div>
<script type="text/javascript">



</script>
<?php
include $this->input->server('DOCUMENT_ROOT')."/include/mail_footer.php";
 ?>
