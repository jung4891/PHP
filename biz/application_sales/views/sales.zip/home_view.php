<?php
   include $this->input->server('DOCUMENT_ROOT')."/include/base.php";
   include $this->input->server('DOCUMENT_ROOT')."/include/sales_top.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php
  include $this->input->server('DOCUMENT_ROOT')."/include/sales_header.php";
?>

메인화면
<!-- footer -->
<?php include $this->input->server('DOCUMENT_ROOT')."/include/sales_bottom.php"; ?>
<!-- footer 끝 -->
</script>
</body>
</html>
