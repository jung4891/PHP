<?php
  include $this->input->server('DOCUMENT_ROOT')."/include/base.php";
  include $this->input->server('DOCUMENT_ROOT')."/include/customer_top.php";
  include $this->input->server('DOCUMENT_ROOT')."/misc/js/tech_schedule/tech_schedule2.php";
?>
<?php
  // if($_SERVER['SERVER_ADDR'] == '192.168.1.104'){
  //   echo "<meta http-equiv='refresh' content='5; url=http://dev.biz.durianit.co.kr/'>";
  //   print "로컬서버입니다.";
  // }
  // if($_SERVER['SERVER_ADDR'] == '192.168.1.101'){
  //   echo "<meta http-equiv='refresh' content='5; url=http://biz.durianit.co.kr/'>";
  // }
?>

<html>
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width = device-width, initial-scale = 1, maximum-scale = 1, viewport-fit = cover, user-scalable = no, shrink-to-fit = no ">
    <title></title>

  </head>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="<?php echo $misc; ?>js/touch-punch.js"></script>
  <link href='/misc/css/dashboard.css' rel='stylesheet' />
  <link href='/misc/css/tech_schedule/tech_schedule.css' rel='stylesheet' />
  <link href='/misc/css/tech_schedule/main.css' rel='stylesheet' />
  <link rel="stylesheet" href="/misc/css/bootstrap-datepicker.css">
  <link rel="stylesheet" href="/misc/css/bootstrap-timepicker.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jstree/3.2.1/themes/default/style.min.css" /> <!-- 조직도 생성 -->
  <link rel="stylesheet" href="/misc/css/tech_schedule/proton/style.min.css" /> <!-- 조직도 생성 -->
  <link rel="stylesheet" href="/misc/css/tech_schedule/jquery.minicolors.css" />
  <link rel="stylesheet" href="/misc/css/chosen.css">
  <!-- <link rel="stylesheet" href="/misc/css/bootstrap.css"> -->
  <script src='/misc/js/tech_schedule/main.js'></script>
  <script src='/misc/js/tech_schedule/ko.js'></script>
  <script src='/misc/js/chosen.jquery.js'></script>
  <!-- <script src='/misc/js/tech_schedule/tech_schedule2.js'></script> -->
  <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
  <!-- <script src='/misc/js/select2.min.js'></script> -->
  <script type="text/javascript" src="/misc/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript" src="/misc/js/bootstrap-timepicker.js"></script>
  <script type="text/javascript" src="/misc/js/jquery.bpopup-0.1.1.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.0/moment.min.js"></script>
  <script src="https://unpkg.com/popper.js/dist/umd/popper.min.js"></script>
  <script src="https://unpkg.com/tooltip.js/dist/umd/tooltip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jstree/3.2.1/jstree.min.js"></script> <!-- 조직도 생성 -->
  <script type="text/javascript" src="/misc/js/tech_schedule/jquery.minicolors.js"></script>


  <style>
/* 모바일 csss */
@media (max-width: 575px), (max-width: 768px) {

  /* #techReportInsert,#techReportModify{
    display:none;
  } */

  #add_conference_btn,#add_car_btn{
    margin:20px 0px  !important;
  }
  .select_time{
    font-size:14px;
    display:flex;
    display: -webkit-box;
    display: -ms-flexbox;
    overflow-x: auto;
    overflow-y: hidden;
  }
  .select_time_th{
    width:100% !important;
  }
  .select_time tbody{
    display:flex
  }
  .select_time th:first-child{
    display:block;
    height:30px !important;
  }
  .select_time th:not(:first-child){
    display:block;
    height:22px !important;
  }
  .select_time td{
    display:block;
  }
  .select_time td:first-child{
    height:30px !important;
  }

  .select_time td:not(:first-child){
    height:0px !important;
  }
  input,
  textarea,
  select {
      font-size: 16px !important;
  }
  #select_date,#select_car_date{
    width:220px !important;
    float: none !important;
    margin:20px 0px !important;
  }

  #select_table,#select_car_table{
    display:inline-block  !important;
    width:100% !important;
    margin:0px !important;
  }

  #conference_div{
    width:100% !important;
  }

  #car_reservation_div{
    width:100% !important;
  }

  li{
    list-style: none;
  }
  #addpopup, #updateSchedule{
    width:100% !important;
  }
  #addpopup input:not(#room_name,#car_name,.dayBtn,.timeBtn,.dateBtn,.basicBtn,.add_weekly_report),#addpopup textarea,
  #updateSchedule input:not(#de_room_name,#de_car_name,.dayBtn,.timeBtn,.dateBtn,.basicBtn,.add_weekly_report),#updateSchedule textarea{
    width:70% !important;
  }
  #room_name,#car_name,#de_room_name,#de_car_name{
    width:50% !important;
  }
  #searchDiv{
    width:25% !important;
    float:left !important;
  }
  #searchBtnDiv{
    width:20% !important;
    float:left !important;
    text-align: center;
  }
  #changeDiv{
    width:50% !important;
    float:left !important;
  }
  #searchSelect,#searchText{
    width:100% !important;
  }

  #scheduleSidebar,#company_schedule,#selectParticipantBtn {
    display : none !important;
  }
  #scheduleTop{
    width:100% !important;
    margin:0px !important;
  }
  #calendar{
    width:100% !important;
    height: 600px !important;

  }

  .fc .fc-toolbar{
    font-size: 10px;
    display: inline-block !important;
  }

  .fc-toolbar-title{
    margin-bottom:10px !important;
  }

  .fc .fc-daygrid-day-frame{
    min-height:100% !important;

  }

  .fc-button-group:first-child{
    margin-top:10px;
    width:100% !important;
  }

}

/* 모바일css끝 */


  #feedback { font-size: 1.4em; }
  #selectable .ui-selecting { background: #80dfff; }
  #selectable .ui-selected { background: #52b1fa; color: white; }
  #selectable { list-style-type: none; margin: 0; padding: 0; width: 60%; }

  #select_car_tbody .ui-selecting { background: #80dfff; }
  #select_car_tbody .ui-selected { background: #52b1fa; color: white; }
  #select_car_tbody { list-style-type: none; margin: 0; padding: 0; width: 60%; }

  div.scheduleHint {
    font-size:18px; position:absolute; width:450px; line-height:1.5em; padding:5px 8px 7px; border: 1px solid #cccccc;  border-radius: 4px; background:#fff;  /* z-index:10001; */
    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
  }

  h3 {
    padding:0;
    margin: 0;
    font-weight: bold;
    line-height: 1.1;
    display: block;
    font-size: 1.17em;
    margin-block-start:1em;
    margin-block-end:1em;
    margin-inline-start:0px;
    margin-inline-end:0px;
  }

  .event_color_button {
    display: inline-block;
    vertical-align: middle;
    width: 15px;
    height: 15px;
  }


/* @@ */
  .fc .fc-button {
      display: inline-block;
      font-weight: 400;
      text-align: center;
      vertical-align: middle;
      -webkit-user-select: none;
         -moz-user-select: none;
          -ms-user-select: none;
              user-select: none;
      background-color: transparent;
      border: 1px solid transparent;
      padding: 0.4em 0.65em;
      font-size: 1em;
      line-height: 1.5;
      border-radius: 50px;
    }
  .fc .fc-button:hover {
      text-decoration: none;
    }
  .fc .fc-button:focus {
      outline: 0;
      box-shadow: 0 0 0 0.2rem rgba(44, 62, 80, 0.25);
    }
  .fc .fc-button:disabled {
      opacity: 0.65;
    }

/* @@ */
  .fc .fc-button-primary {
      color: #41beeb;;
      color: var(--fc-button-text-color, #41beeb);
      background-color: #fff;;
      background-color: var(--fc-button-bg-color, #fff);
      border-color: #41beeb;;
      border-color: var(--fc-button-border-color, #41beeb);
      font-weight: bold;
      /* height: 30px; */
      /* border:2px solid; */
      /* border:0.2em solid; */
    }
  .fc .fc-button-primary:hover {
      color: #fff;
      color: var(--fc-button-text-color, #fff);
      background-color: #41beeb;;
      background-color: var(--fc-button-hover-bg-color, #41beeb);
      border-color: #41beeb;;
      border-color: var(--fc-button-hover-border-color, #41beeb);
    }
  .fc .fc-button-primary:disabled { /* not DRY */
      color: #fff;
      color: var(--fc-button-text-color, #fff);
      background-color: #41beeb;
      background-color: var(--fc-button-bg-color, #41beeb);
      border-color: #41beeb;
      border-color: var(--fc-button-border-color, #41beeb); /* overrides :hover */
    }
  .fc .fc-button-primary:focus {
      box-shadow: 0 0 0 0.2rem rgba(76, 91, 106, 0.5);
    }

  /* @@ */
  .fc .fc-button-primary:not(:disabled):active,
    .fc .fc-button-primary:not(:disabled).fc-button-active {
      color: #fff;
      color: var(--fc-button-text-color, #fff);
      background-color: #41beeb;;
      background-color: var(--fc-button-active-bg-color, #41beeb);
      border-color: #41beeb;;
      border-color: var(--fc-button-active-border-color, #41beeb);
    }
  .fc .fc-button-primary:not(:disabled):active:focus,
    .fc .fc-button-primary:not(:disabled).fc-button-active:focus {
      box-shadow: 0 0 0 0.2rem rgba(76, 91, 106, 0.5);
    }

/* @@ */
  .fc-direction-ltr .fc-button-group > .fc-button:not(:first-child) {
      margin-left: 4px;
      border-top-left-radius: 50px;
      border-bottom-left-radius: 50px;
    }
  .fc-direction-ltr .fc-button-group > .fc-button:not(:last-child) {
      border-top-right-radius: 50px;
      border-bottom-right-radius: 50px;
    }
  .fc-direction-rtl .fc-button-group > .fc-button:not(:first-child) {
      margin-right: 4px;
      border-top-right-radius: 50px;
      border-bottom-right-radius: 50px;
    }
  .fc-direction-rtl .fc-button-group > .fc-button:not(:last-child) {
      border-top-left-radius: 50px;
      border-bottom-left-radius: 50px;
    }

/* @@ */
  .fc .fc-toolbar.fc-header-toolbar {
      margin-bottom: 1em;
  }

/* @@ */
  .fc-next-button, .fc-prev-button{
      /* width:30px; */
      width:35px;
      height:35px;
    }
  button.fc-prev-button.fc-button.fc-button-primary{
      /* padding-left: 2px; */
      padding-left: 3px;
      padding-top: 4px;
      border:0.2em solid;
    }
  button.fc-next-button.fc-button.fc-button-primary{
      /* padding-left: 3px; */
      padding-left: 5px;
      padding-top: 4px;
      border:0.2em solid;
    }
  .fc-icon-chevron-left:before, .fc-icon-chevron-right:before {
      margin-bottom:10px;
      font-weight: bold;
    }
  /* 일정 두께 및 갯수 조절 */
  .fc-daygrid-block-event .fc-event-time, .fc-daygrid-block-event .fc-event-title {
      padding: 0px;
    }
  .fc .fc-daygrid-event {
      z-index: 6;
      margin-top: 0px;
    }
  .fc .fc-daygrid-day-number {
      position: relative;
      z-index: 4;
      /* padding: 0px; */
      padding: 1px;
    }
  .fc .fc-daygrid-day-frame {
      position: relative;
      min-height: 145px;
      max-height: 145px;
    }

<?php foreach($work_color as $wc){ ?>
<?php echo '.event_class_type'.$wc->seq; ?> { border: 1px solid #474889; border-radius: 50%; background: <?php echo $wc->color; ?> !important; color: #fff !important;
   -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
   -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
   box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
}
<?php } ?>

  .text-point { color:#d3292c !important; }
  .text-normal { color:black !important; }


  /* .ui-tooltip {
    color: blue;
    background-color: white;
    border-radius: 20px;
    box-shadow: 0 0 7px green;
    z-index:10000;
    position: relative;
    width: :300px;
  } */

  .tooltip-content{
    visibility: hidden;
    width: 450px;
    /* background-color: white; */
    padding:5px 8px 7px;
    line-height:1.5em;
    margin-top: 10px;
    position: absolute;
    z-index: 1;
    color:black;
    font-size: 18px;
    border: 1px solid #cccccc;
    border-radius: 4px;
    background:#fff;  /* z-index:10001; */
    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
  }
  </style>

  <script>
  // $(document).ready(function () {
  //   $(".koHolidays").parent('div').parent('div').parent('div').css("background-color","#FFF7F7");
  // });

document.addEventListener('DOMContentLoaded', function(){
  $('.demo').each( function() {
    $(this).minicolors({
      control: $(this).attr('data-control') || 'hue',
      defaultValue: $(this).attr('data-defaultValue') || '',
      format: $(this).attr('data-format') || 'hex',
      keywords: $(this).attr('data-keywords') || '',
      inline: $(this).attr('data-inline') === 'true',
      letterCase: $(this).attr('data-letterCase') || 'lowercase',
      opacity: $(this).attr('data-opacity'),
      position: $(this).attr('data-position') || 'bottom',
      swatches: $(this).attr('data-swatches') ? $(this).attr('data-swatches').split('|') : [],
      change: function(value, opacity) {
        if( !value ) return;
        if( opacity ) value += ', ' + opacity;
        if( typeof console === 'object' ) {
        }
      },
      theme: 'bootstrap'
    });
  });
})

function list_search(){
  var act = "<?php echo site_url();?>/biz/schedule/tech_schedule";
  $("#searchWord").attr('action', act).submit();
}


// // KI1 20210125 고객사 포캐스팅형/유지보수형으로 변경에 적용되는 함수들
function searchFunction(id) {
  var myDropdown = $("#" + id).parent().find('div').attr('id');
  if(myDropdown == 'de_myDropdown'){
    var workname = 'de_workname';
    var dropdown_option = 'de_dropdown_option';
  }else{
    var workname = 'workname';
    var dropdown_option = 'dropdown_option';
  }

  if( $("#"+workname).val() == "납품설치" || $("#"+workname).val() == "미팅" || $("#"+workname).val() == "데모(BMT)지원" ){
    $("#"+dropdown_option).html(
      <?php
      echo "'";
      //KI1 20210208
      echo '<a onClick="show_input_customerName(this)" value="">직접입력</a>';
      //KI2 20210208
      foreach ($customer2 as $val) {
          echo '<a ';
          echo 'onclick ="clickCustomerName(this,0,'.$val['forcasting_seq'].','.$val['forcasting_seq'].')" >'. $val['customer'].' - '.addslashes($val['project_name']).'</a>';
      }
      echo "'";
      ?>
    );
  }else if(workname ==''){
    $("#"+myDropdown).toggle();
    alert('작업구분을 먼저 선택해주세요.');
    $("#"+workname).focus();
  }else{
    $("#"+dropdown_option).html(
    <?php
       echo "'";
       //KI1 20210208
       echo '<a onClick="show_input_customerName(this)" value="">직접입력</a>';
       //KI2 20210208
      foreach ($customer as $val) {
        // if (strtotime(date("Y-m-d")) > strtotime(date($val['maintain_end']))) {
        //   echo '<a style="color:red;" ';
        //   echo 'onclick ="clickCustomerName(this,' . strtotime(date($val['maintain_end'])) . ','.$val['maintain_seq'].','.$val['forcasting_seq'].')" >' . $val['customer'].' - '.addslashes($val['project_name']).'</a>';
        // } else {
        //   echo '<a ';
        //   echo 'onclick ="clickCustomerName(this,' . strtotime(date($val['maintain_end'])) . ','.$val['maintain_seq'].','.$val['forcasting_seq'].')" >'. $val['customer'].' - '.addslashes($val['project_name']).'</a>';
        // }

        if($val['maintain_seq'] == null){
          echo '<a ';
          echo 'onclick ="clickCustomerName(this, 0 ,'.$val['forcasting_seq'].','.$val['forcasting_seq'].')" >'. $val['customer'].' - '.addslashes($val['project_name']).'</a>';
        }else{
          echo '<a ';
          echo 'onclick ="clickCustomerName(this,' . strtotime(date($val['maintain_end'])) . ','.$val['maintain_seq'].','.$val['forcasting_seq'].')" >'. $val['customer'].' - '.addslashes($val['project_name']).'</a>';
        }
      }
      echo "'";
      ?>
    );
  }
  $("#"+myDropdown).toggle();
  // $("#myDropdown").toggle();
  $(".searchInput").focus();
}

//고객사 선택
function clickCustomerName(customerName, maintainEnd, seq , forcasting_seq) {
  var parent_id = $(customerName).closest("div").attr("id");
  // alert(parent_id);
  // alert(JSON.stringify(parent_id));
  // alert(JSON.stringify(parent_id));
  // var parent_id = $(this).parent('div').attr('id');
  // console.log('customerName: '+customerName+'  maintainEnd: '+maintainEnd+'  seq: '+seq+'  forcasting_seq: '+forcasting_seq+' parent_id: '+parent_id);
  if(parent_id == 'de_dropdown_option'){
    var customerName_id = 'de_customerName';
    var project_id = 'de_project';
    var customer_id = 'de_customer';
    var forcasting_seq_id = 'de_forcasting_seq';
    var maintain_seq_id = 'de_maintain_seq';
    var workname_id = 'de_workname';
    var myDropdown = 'de_myDropdown';
  }else{
    var customerName_id = 'customerName';
    var project_id = 'project';
    var customer_id = 'customer';
    var forcasting_seq_id = 'forcasting_seq';
    var maintain_seq_id = 'maintain_seq';
    var workname_id = 'workname';
    var myDropdown = 'myDropdown';
  }
  //KI1 20210208
  $('#'+customerName_id).attr('readonly',true);
  $('#'+project_id).attr('readonly',true);
  //KI2 20210208

  var customerCompanyName = ($(customerName).text()).split(' - ')[0];
  var projectName = ($(customerName).text()).split(' - ')[1];
  $('#'+customerName_id).val(customerCompanyName);
  $('#'+project_id).val(projectName);
  $("#"+customer_id).val(seq);
  $("#"+forcasting_seq_id).val('');
  $("#"+forcasting_seq_id).val(forcasting_seq);
  $("#"+maintain_seq_id).val('');
  $("#"+maintain_seq_id).val(seq);

  if($("#"+workname_id).val() != "납품설치" && $("#"+workname_id).val() != "미팅" && $("#"+workname_id).val() != "데모(BMT)지원" ){ //유지보수
      // test3($("#"+customer_id).val(),'maintain');
      // if (<?php echo strtotime(date("Y-m-d")) ?> > maintainEnd) {
      //   $("#"+customer_id).val('');
      //   $('#'+customerName_id).val('');
      //   $('#'+project_id).val('');
      // }

    if(maintainEnd != '0'){
      test3($("#"+customer_id).val(),'maintain');
      if (<?php echo strtotime(date("Y-m-d")) ?> > maintainEnd) {
        $("#"+customer_id).val('');
        $('#'+customerName_id).val('');
        $('#'+project_id).val('');
      }
    }else{
      test3($("#"+customer_id).val(),'forcasting');
      $("#"+maintain_seq_id).val('');
    }
  }else{ //포캐스팅
    test3($("#"+customer_id).val(),'forcasting');
    $("#"+maintain_seq_id).val('');
  }
  $("#"+myDropdown).toggle();
}

//고객사 입력 검색
function filterFunction(customerName) {
  var input, filter, ul, li, a, i;
  input = document.getElementById(customerName.id);
  filter = input.value.toUpperCase();
  myDropDown = $(customerName).parent().attr('id');
  div = document.getElementById(myDropDown);
  a = div.getElementsByTagName("a");
  for (i = 0; i < a.length; i++) {
    txtValue = a[i].textContent || a[i].innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      a[i].style.display = "";
    } else {
      a[i].style.display = "none";
    }
  }
}

// 고객사 담당자 가져오는 함수
function test3(name,mode) {
  var settings = 'height=500,width=1000,left=0,top=0';
  var popup = window.open('/index.php/tech/tech_board/search_manager?name=' + name+'&mode='+mode+'&page=sch', '_blank');
  window.focus();
}

// 외부영역 클릭 시 팝업 닫기
$(document).mouseup(function (e){
  var LayerPopup = $("#dropdown");
  if(LayerPopup.has(e.target).length === 0){
    $("#myDropdown").hide();
  }

  var de_LayerPopup = $("#de_dropdown");
  if(de_LayerPopup.has(e.target).length === 0){
    $("#de_myDropdown").hide();
  }
});
// KI2 20210125

//KI1 20210208
function show_input_customerName(customerName){
  var parent_id = $(customerName).closest("div").attr("id");
  if(parent_id == 'de_dropdown_option'){
    var customerName_id = 'de_customerName';
    var project_id = 'de_project';
    var customer_manager_id = 'de_customer_manager';
    // var customer_tmp_id = 'de_customer_tmp';
    var forcasting_seq_id = 'de_forcasting_seq';
    var maintain_seq_id = 'de_maintain_seq';
    var tech_report_id = 'de_tech_report';
    var myDropdown = 'de_myDropdown';
  }else{
    var customerName_id = 'customerName';
    var project_id = 'project';
    var customer_manager_id = 'customer_manager';
    // var customer_tmp_id = 'customer_tmp';
    var forcasting_seq_id = 'forcasting_seq';
    var maintain_seq_id = 'maintain_seq';
    var tech_report_id = 'tech_report';
    var myDropdown = 'myDropdown';
  }
  $('#'+customerName_id).attr('readonly',false);
  $('#'+project_id).attr('readonly',false);
  $('#'+customerName_id).css('border','2px solid');
  $('#'+customerName_id).css('border-color','black');
  $('#'+customerName_id).css('border-radius','5px');
  $('#'+customerName_id).val('');
  $('#'+customer_manager_id).val('');
  // $('#'+customer_tmp_id).val('');
  $('#'+project_id).val('');
  $('#'+forcasting_seq_id).val('');
  $('#'+maintain_seq_id).val('');
  $('#'+tech_report_id).val('Y');
  $("#"+myDropdown).toggle();
}
//KI2 20210208

function popupClose(close_popup_id) {
 $("#show_day_select_popup").bPopup().close();
}

function show_day_select() {
  $("#show_day_select_popup").bPopup();
}
  </script>
<body>
<?php
  if($this->agent->is_mobile()){
    include $this->input->server('DOCUMENT_ROOT')."/include/mobile_header.php";
  }else{
    include $this->input->server('DOCUMENT_ROOT')."/include/sales_header.php";
  }
?>
<table id="zg" width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="top">
      <!-- //여기부터 -->

      <!-- 일정 추가 팝업 -->
      <!-- 일정 추가 팝업 -->
  <div id='addpopup' style="display: none; background-color: white; width:30%; height: auto;">
        <!-- KI1 20210125 고객사 담당자를 불러오기 위해 name=cform으로 적용-->
      <article class="layerpop_area">
        <form name="cform" id="cform" action="<?php echo site_url();?>/biz/schedule/add_schedule" method="post">
        <!-- KI2 20210125 -->
          <!-- <table> -->
          <div align="center" class="modal_title">일정등록
            <a style="float:right" onclick="$('#addpopup').bPopup().close();">
              <img src="/misc/img/btn_del2.jpg"/>
            </a>
          </div>
            <table width="100%" border="0" callspacing="0" cellspacing="0">
              <tbody align="left">
                <!-- KI1 20210125 고객사 담당자 적용을 위한 hidden input 적용, 프로젝트 input 추가 -->
                <input type="hidden" name="customer_manager" id="customer_manager" class="input2">
                <!-- <input type="hidden" name="maintain_end" id="maintain_end" class="input2">

                <input type="hidden" id="row_max_index" name="row_max_index" value="0" />
                <input type="hidden" id="customer_tmp" name="customer_tmp" value="" /> -->
                <!-- ↑customerName과 동일 -->
                <input type="hidden" id="forcasting_seq" name="forcasting_seq" value="" />
                <input type="hidden" id="maintain_seq" name="maintain_seq" value="" />
                <input type="hidden" id="work_type" name="work_type" value="" />
                <!-- <input type="hidden" id="checkListForm" name="checkListForm" value="" /> -->
                <!-- KI1 20210208 -->
                <input type="hidden" id="tech_report" name="tech_report" value="" />
                <!-- KI2 20210208 -->
                <tr>
                  <td colspan="10" height="2" bgcolor="#173162"></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                   <td>
                     <td align="center">
                       <table border="0" cellspacing="0" cellpadding="0" width="95%" style="table-layout:fixed;">
                          <colgroup>
                            <col width="25%" />
                            <col width="25%" />
                            <col width="25%" />
                            <col width="25%" />
                          </colgroup>
                         <tbody>
                           <tr>
                             <td colspan="4" height="2" bgcolor="#797c88"></td>
                           </tr>
                           <tr>
                             <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">구분</td>
                             <td colspan="1" class="t_border" style="padding-left:10px;">
                               <select name="workname" id="workname" onchange="">
                                 <option value="" selected disabled hidden>선택하세요</option>
                                  <?php
                                  if ($this->group == '기술연구소') {
                                    echo "<option value='기술연구소'>기술연구소</option>";
                                  }
                                  foreach ($work_name as $val) {
                                    echo "<option value='{$val->work_name}' >{$val->work_name}</option>";
                                  }
                                  ?>
                               </select>
                             </td>
                             <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; width:90px" class="tech_div">지원방법</td>
                             <td class="t_border tech_div" style="padding-left:10px;">
                               <select name="supportMethod" id="supportMethod">
                                 <option value="" selected disabled hidden>선택하세요</option>
                                 <option value="현장지원">현장지원</option>
                                 <option value="원격지원">원격지원</option>
                               </select>
                             </td>

                           </tr>
                           <tr class="except_nondisclosure_div">
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr class="except_nondisclosure_div">
                             <td colspan="4">
                               <button type="button" id="conference" style="outline:none;" onclick="open_conference('insert');" class="basicBtn2" onMouseOver="this.style.backgroundColor='#333333',this.style.color='#ffffff'" onMouseOut="this.style.backgroundColor='#DBDBDb', this.style.color='#333333'">회의실 예약</button>
                               <input type="text" id="room_name" name="room_name" value="" readonly>
                               <button type="button" name="button" onclick="$('#room_name').val('');" style="width:25px; height:20px; outline:none;" class="basicBtn2" onMouseOver="this.style.backgroundColor='#333333',this.style.color='#ffffff'" onMouseOut="this.style.backgroundColor='#DBDBDb', this.style.color='#333333'">X</button>
                             </td>
                           </tr>
                           <tr class="except_nondisclosure_div">
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr class="except_nondisclosure_div">
                              <td colspan="4">
                                <button type="button" id="car_reservation" style="outline:none;" onclick="open_car_reservation('insert');" class="basicBtn2" onMouseOver="this.style.backgroundColor='#333333',this.style.color='#ffffff'" onMouseOut="this.style.backgroundColor='#DBDBDb', this.style.color='#333333'">차 량 예 약</button>
                                <input type="text" id="car_name" name="car_name" value="" readonly>
                                <button type="button" name="button" onclick="$('#car_name').val('');" style="width:25px; height:20px; outline:none;" class="basicBtn2" onMouseOver="this.style.backgroundColor='#333333',this.style.color='#ffffff'" onMouseOut="this.style.backgroundColor='#DBDBDb', this.style.color='#333333'">X</button>
                              </td>
                           </tr>
                           <tr>
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr>
                             <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">시작일자</td>
                             <td colspan="3" class="t_border" style="padding-left:10px;">
                              <?php if($this->agent->is_mobile()){ ?>
                                <input type="date" name="startDay" id="startDay" class="dayBtn" value="<?php echo date("Y-m-d"); ?>" autocomplete="off" onchange="conference_room_del('insert'); date_compare('');" style="width:40%;vertical-align:middle;">
                                <input type="time" name="startTime" id="startTime" class="timeBtn" value="" autocomplete="off" style="width:30%;vertical-align:middle;">
                              <?php }else{?>
                                  <input type="text" name="startDay" id="startDay" class="dayBtn" value="<?php echo date("Y-m-d"); ?>" autocomplete="off" onchange="conference_room_del('insert'); date_compare('');" style="width:40%">
                                  <input type="button" name="" id="startBtn" class="dateBtn" value=" " onclick="openStartDate();" style="width:10%" >
                                  <input type="text" name="startTime" id="startTime" class="timeBtn" value="" autocomplete="off" style="width:30%">
                              <?php } ?>
                             </td>
                           </tr>
                           <tr>
                             <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">종료일자</td>
                             <td colspan="3" class="t_border" style="padding-left:10px;">
                              <?php if($this->agent->is_mobile()){ ?>
                                <input type="date" name="endDay" id="endDay" class="dayBtn" value="<?php echo date("Y-m-d"); ?>" autocomplete="off" onchange="conference_room_del('insert'); date_compare('');" style="width:40%;vertical-align:middle;">
                                <input type="time" name="endTime" id="endTime" class="timeBtn" value="" autocomplete="off" style="width:30%;vertical-align:middle;">
                              <?php }else{?>
                               <input type="text" name="endDay" id="endDay" class="dayBtn" value="<?php echo date("Y-m-d"); ?>" autocomplete="off" onchange="conference_room_del('insert'); date_compare('');" style="width:40%">
                               <input type="button" name="" id="endBtn" class="dateBtn" value=" " onclick="openEndDate();" style="width:10%">
                               <input type="text" name="endTime" id="endTime" class="timeBtn" value="" autocomplete="off" style="width:30%">
                              <?php } ?>
                              </td>
                           </tr>
                           <tr class="general_div sch_title_div">
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr class="general_div sch_title_div">
                             <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">제목</td>
                             <td colspan="3" class="t_border" style="padding-left:10px">
                               <input type="text" name="title" id="title" value="" style="width:70%">
                             </td>
                           </tr>
                           <tr class="general_div sch_loc_div">
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr class="general_div sch_loc_div">
                             <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">장소</td>
                             <td colspan="3" class="t_border" style="padding-left:10px">
                               <input type="text" name="place" id="place" value="" style="width:70%">
                             </td>
                           </tr>
                           <!-- <tr> -->
                           <tr class="except_company_div">
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr class="except_company_div">
                             <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; " >고객사</td>
                             <td colspan="3" class="t_border" style="padding-left:10px;">
                                 <div class="dropdown tech_div" id="dropdown">
                                   <p onclick="searchFunction(this.id)" id="dropbtn" class="dropbtn">검색</p>
                                   <input id="customerName" name ="customerName" type="text" class="customerName" value="" style="border:none;width:200px;font-weight:bold;text-align:center;">
                                   <input type="hidden" id="customer" name="customer" value="" style="border:none" readonly>
                                   <div id="myDropdown" class="dropdown-content">
                                     <input type="text" name="0" placeholder="고객사를 입력하세요" id="searchInput" class="searchInput" onkeyup="filterFunction(this)" autocomplete="off">
                                     <div id="dropdown_option" style="overflow:scroll; width:277px; height:300px;">
                                     </div>
                                   </div>
                                 </div>
                                 <div class="general_div except_company_div">
                                   <input type="text" id="customerName2" name="customerName2" value="" style="width:70%">
                                 </div>

                             </td>
                           </tr>
                           <tr class="tech_div">
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr class="tech_div">
                             <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">프로젝트</td>
                             <td colspan="3" class="t_border" style="padding-left:10px">
                               <input type="text" id="project" name="project" value="" style="width:70%">
                             </td>
                           </tr>
                           <tr class="except_company_div except_nondisclosure_div">
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr class="except_company_div except_nondisclosure_div">
                             <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">참석자</td>
                             <td colspan="3" class="t_border" style="padding-left:10px; padding-bottom:5px;">
                               <!-- <input type="text" name="participant" id="participant" value="" placeholder="" size='45'>
                               <input type="image" src="<?php echo $misc; ?>/img/participant_add.jpg" id="addUserBtn" class="btn" style="width:25px; height:25px; vertical-align:middle;" onclick="addUser_Btn();return false;"> -->
                               <li size='45'>
                                 <div class="" size='45' style="padding:5px 0;">
                                   <input type="text" name="participant_input" id="participant_input" value="" placeholder="" onkeypress="keypress(event,this.value,'participant')" autocomplete="off">
                                   <input type="hidden" name="participant" id="participant" value="" placeholder="">
                                   <img src="<?php echo $misc; ?>/img/participant_add.png" id="addUserBtn" class="btn" style="width:17px; height:17px; border:1px solid lightgray; padding:2px; vertical-align:middle;" onclick="addUser_Btn();return false;">
                                   <!-- <input type="image" src="<?php echo $misc; ?>/img/participant_add.jpg" id="addUserBtn" class="btn" style="width:25px; height:25px; vertical-align:middle;" onclick="addUser_Btn();return false;"> -->
                                 </div>
                               </li>
                               <li size='45'>
                                 <div id="participant_box" name="participant_box" max-size='45' style="max-height:40px; max-width:380px; overflow-x:auto;">

                                 </div>
                               </li>
                             </td>
                           </tr>
                           <tr>
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr class="general_div explanation_div" style="display:none;">
                             <td colspan="1" height="3" bgcolor="#f8f8f9"></td>
                             <td colspan="3" height="3" bgcolor="#f8f8f9" class="t_border">
                               <div class="" style="float:left; width:50%; text-align:left;">
                                 <span style="font-size:10px; font-weight:bold;">주간업무</span>
                               </div>
                               <div class="" style="display:inline-block; width:50%; text-align:right;">
                                 <span style="font-size:10px; font-weight:bold;">추가/삭제</span>
                               </div>
                             </td>
                           </tr>
                           <!-- <tr>
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr> -->
                           <!-- KI_20210405_내용분할1 -->
                           <tr id="contents_tr_0">
                             <td align="center" bgcolor="f8f8f9" style="font-weight:bold; ">내용</td>
                             <td class="t_border" colspan="3" bgcolor="f8f8f9" align="left">
                               <input type="checkbox" class="add_weekly_report" id="add_weekly_report_0" name="add_weekly_report" value="" style="vertical-align:middle;width:10%;float:left">
                               <textarea rows="2" name='contents' id="contents_0" placeholder="상세내용" style="resize:none; vertical-align:middle; margin:2px -1.8px;width:70%;float:left" maxlength="300"></textarea>
                               <input type="hidden" name="contents_num" id="contents_num_0" value="0">
                               <img src="<?php echo $misc; ?>img/btn_add.jpg" id="contents_add" name="contents_add" onclick="contents_add_action('contents');return false;" style="cursor:pointer;vertical-align:middle;float:right" />
                             </td>
                           </tr>

                           <!-- 기술연구소 -->
                           <tr height="40" id="lab_contents_tr" class="lab_contents_tr" style="display:none;">
                              <td align="center" bgcolor="f8f8f9" style="font-weight:bold">개발구분</td>
                              <td class="t_border" bgcolor="f8f8f9" align="left" style="padding-left:10px">
                                <select id="dev_type" name="dev_type">
                                  <option value="" selected disabled hidden>선택하세요</option>
                                  <option value="신규개발">신규개발</option>
                                  <option value="기능개선">기능개선</option>
                                  <option value="버그수정">버그수정</option>
                                </select>
                              </td>
                              <td class="t_border" align="center" bgcolor="f8f8f9" style="font-weight:bold">페이지</td>
                              <td class="t_border" bgcolor="f8f8f9" align="left" style="padding-left:10px">
                                <input type="text" id="dev_page" name="dev_page" value="" style="width:90%;">
                              </td>
                           </tr>
                           <tr class="lab_contents_tr">
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr height="40" id="lab_contents_tr" class="lab_contents_tr" style="display:none;">
                             <td align="center" bgcolor="f8f8f9" style="font-weight:bold">요청자</td>
                             <td colspan="3" class="t_border" bgcolor="f8f8f9" align="left" style="padding-left:10px">
                               <input type="text" id="dev_requester" name="dev_requester" value="" style="width:96.5%;">
                             </td>
                           </tr>
                           <tr class="lab_contents_tr">
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr height="40" id="lab_contents_tr" class="lab_contents_tr" style="display:none;">
                             <td align="center" bgcolor="f8f8f9" style="font-weight:bold">개발사항</td>
                             <td colspan="3" class="t_border" bgcolor="f8f8f9" align="left" style="padding-left:10px">
                               <textarea id="dev_develop" name="dev_develop" rows="5" cols="52" style="resize:none; vertical-align:middle; margin:2px -1.8px;width:96.5%;float:left"></textarea>
                             </td>
                           </tr>
                           <tr class="lab_contents_tr">
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr height="40" id="lab_contents_tr" class="lab_contents_tr" style="display:none;">
                              <td align="center" bgcolor="f8f8f9" style="font-weight:bold;">완료여부</td>
                              <td class="t_border" style="padding-left:10px">
                                <input type="checkbox" id="dev_complete" name="dev_complete" value="">
                              </td>
                           </tr>
                           <!-- 기술연구소 -->

                             <!-- KI_20210405_내용분할2 -->
                           </tr>
                           <tr class="report_div" style="display:none;">
                             <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                           </tr>
                           <tr class="report_div" style="display:none;">
                             <td align="center" bgcolor="f8f8f9" style="font-weight:bold; ">비공개</td>
                             <td colspan="1" class="t_border" style="padding-left:10px;">
                               <input type="checkbox" id="nondisclosure_sch" name="nondisclosure_sch" value="" onclick="nondisclosure_form('nondisclosure')">
                             </td>
                           </tr>
                           <tr>
                             <td colspan="4" height="2" bgcolor="#797c88"></td>
                           </tr>
                           <tr>
                             <td>&nbsp;</td>
                           </tr>
                         </tbody>
                       </table>
                    <button type="button" name="scheduleAdd" id="scheduleAdd" class="basicBtn">등록</button>
                     </td>
                   </td>
                </tr>
            </table>
        </form>
      </article>
  </div>
<!-- 팝업 끝 -->

<!-- KI1 20210125 참여자 추가 형태를 검색 참여자 추가 형태로 변경  -->
<!-- 참여자 팝업 추가 -->
<div id="addUserpopup">
  <img id="addUserpopupCloseBtn" src="<?php echo $misc;?>img/btn_del2.jpg" onclick="closeBtn()" width=25  style="cursor:pointer;margin:0% 0% 0% 92%"/>
  <!-- <span id="addUserpopupCloseBtn" class="btn" onclick="closeBtn()" style="margin:0% 0% 0% 96%; color:white;">X</span> -->
  <div id="modal-body">
    <div id="modal-grouptree">
      <div id="usertree">
        <ul>
          <li>(주)두리안정보기술
            <ul>
            <?php
            foreach ($parentGroup as $pg){
            ?>

            <?php
            if ($pg->childGroupNum==1 && $pg->depth==1){
            ?>
              <li>
                <?php echo $pg->parentGroupName;
                  foreach ($userInfo as $ui){
                      if ($pg->groupName==$ui->user_group){
                ?>
                <ul>
                  <li id="<?php echo $ui->user_name; ?>" seq="<?php echo $ui->seq; ?>" ><?php echo $ui->user_name." ".$ui->user_duty; ?></li>
                </ul>
                <?php
                      }
                  }
                ?>
              </li>
              <?php
              } else if ($pg->childGroupNum>1 && $pg->depth==1){
              ?>
              <li>
              <?php echo $pg->parentGroupName;
              foreach ($user_group as $ug) {
                if ($pg->parentGroupName==$ug->parentGroupName){
              ?>
                <ul>
                  <?php
                  foreach ($userDepth as $ud){
                      if ($ug->groupName == $ud->groupName){
                        echo '<li id="'.$ud->user_name.'" seq="'.$ui->seq.'">'.$ud->user_name." ".$ud->user_duty.'</li>';
                      }
                  }
                  if ($ug->groupName != $pg->groupName){
                    echo "<li>".$ug->groupName;
                  }
                  ?>
                    <ul>
                    <?php
                      foreach($userInfo as $ui) {
                        if ($ug->groupName==$ui->user_group){
                          echo '<li id="'.$ui->user_name.'" seq="'.$ui->seq.'" >'.$ui->user_name." ".$ui->user_duty.'</li>';
                        }
                      }
                    ?>
                    </ul>
                  </li>
                </ul>
              <?php
                }
              }
              ?>
              </li>
              <?php
              }
              ?>
            <?php
            }
            ?>
            </ul>
          </li>
        </ul>
      </div>
    </div>
        <div id="btnDiv">
          <input type="button" style="float:right;" class="basicBtn" id="insertUserBtn" name="" value="적용" onclick="addUser(this.id)">
        </div>
      </div>
    </div>
    <!-- 참여자 팝업 끝 -->
    <!-- KI2 20210125 -->

    <!-- 검색 참여자 팝업 추가 -->
    <div id="searchAddUserpopup">
      <span id="searchAddUserpopupCloseBtn" class="btn" onclick="searchCloseBtn()" style="margin:0% 0% 0% 96%; color:white;">X</span>
      <div id="search-modal-body">
        <div id="search-modal-grouptree">
          <div id="search-usertree">
            <ul>
              <li>(주)두리안정보기술
                <ul>
                <?php
                foreach ($parentGroup as $pg){
                ?>

                <?php
                if ($pg->childGroupNum==1 && $pg->depth==1){
                ?>
                  <li>
                    <?php echo $pg->parentGroupName;
                      foreach ($userInfo as $ui){
                          if ($pg->groupName==$ui->user_group){
                    ?>
                    <ul>
                      <li id="<?php echo $ui->user_name; ?>"><?php echo $ui->user_name." ".$ui->user_duty; ?></li>
                    </ul>
                    <?php
                          }
                      }
                    ?>
                  </li>
                  <?php
                  } else if ($pg->childGroupNum>1 && $pg->depth==1){
                  ?>
                  <li>
                  <?php echo $pg->parentGroupName;
                  foreach ($user_group as $ug) {
                    if ($pg->parentGroupName==$ug->parentGroupName){
                  ?>
                    <ul>
                      <?php
                      foreach ($userDepth as $ud){
                          if ($ug->groupName == $ud->groupName){
                            echo '<li id="'.$ud->user_name.'">'.$ud->user_name." ".$ud->user_duty.'</li>';
                          }
                      }
                      if ($ug->groupName != $pg->groupName){
                        echo "<li>".$ug->groupName;
                      }
                      ?>
                        <ul>
                        <?php
                          foreach($userInfo as $ui) {
                            if ($ug->groupName==$ui->user_group){
                              echo '<li id="'.$ui->user_name.'">'.$ui->user_name." ".$ui->user_duty.'</li>';
                            }
                          }
                        ?>
                        </ul>
                      </li>
                    </ul>
                  <?php
                    }
                  }
                  ?>
                  </li>
                  <?php
                  }
                  ?>
                <?php
                }
                ?>
                </ul>
              </li>
            </ul>
          </div>
        </div>
        <div id="search-btnDiv">
        <input type="button" style="float:right;" class="basicBtn" id="searchChosenBtn" name="" value="적용" onclick="addUser(this.id)">
        </div>
      </div>
    </div>
        <!-- 검색 참여자 팝업 끝 -->

<!-- 색상 커스터미이징 팝업 -->

      <div id='customPop' style="display : none; background-color: white; width: 700px; height: 700px;">
        <h3 style="text-align:center; color:#aaa;">작업별 색상 설정</h3>
        <div class="well">
          <div class="row">
            <table id="workColor_tbl">
              <tbody style="width:100%">


<?php
foreach($work_color as $val){
  if($val->work_type == 'tech'){
    echo '<tr id="'.$val->seq.'" style="border-bottom: 30px solid #f5f5f5; width:100%; height:90%;">';
    echo '<td style="width:30%"><label for="hue-demo">'.$val->work_name.'</label>';
    echo '<input style="height:30px" type="text" name="work_color" class="form-control demo work_color" data-control="hue" value="'.$val->color.'" onchange="colorCustom(this);"/></td>';
    echo '<td style="width:30%"><label for="saturation-demo">글자색</label>';
    echo '<input style="height:30px" type="text" name="text_color" class="form-control demo text_color" data-control="saturation" value="'.$val->textColor.'" onchange="colorCustom(this);"/></td>';
    echo '<td style="width:30%"><label for="saturation-demo">출력</label>';
    echo '<input type="text" class="form-control printDemo" data-control="saturation" value="'.$val->work_name.'" style="background-color:'.$val->color.'; color:'.$val->textColor.'; height:30px"/></td></tr>';
  }
}
 ?>
            </tbody>
          </table>
          <button style="float:right" type="button" class="btn" name="button" onclick="save_workColor_close();" class="">닫기</button>
          <button style="float:right" type="button" class="btn" name="button" onclick="save_workColor();">저장</button>

          </div>
        </div>
      </div>
<!-- 색상 커스터미이징 팝업 끝-->

<!-- 기술지원보고서 알림 팝업 시작 -->
<div id="unwrittenpopup" >
  <a style="margin:0% 0% 0% 96%;cursor:pointer;"><span id="unwrittenpopupCloseBtn" onclick="report_closeBtn()"><span style="color:black;">X</span></span></a>
  <input type="hidden" id="session_name" value= "<?php echo $session_name?>"/>
</div>
<!-- 기술지원보고서 알림 팝업 끝 -->
      <div id='updateform' style="display: none; background-color: white; width: 450px; height: 500px;">
        <form name="hiddenSeq" action="<?php echo site_url();?>/biz/schedule/tech_schedule_detail" method="GET">
          <input type="text" name="hiddenSeq" id="hiddenSeq" value="">
          <input type="text" id="login_pgroup" name="login_pgroup" value= "<?php echo $pGroupName?>"/>
          <input type="text" id="login_group" name="login_group" value= "<?php echo $login_group?>"/>
          <input type="text" id="login_user_duty" name="login_user_duty" value= "<?php echo $login_user_duty?>"/>
          <input type="submit" name="seqBtn" id="seqBtn" >
        </form>
        <input type="text" id="session_id" value= "<?php echo $session_id;?>"/>
      </div>
      <div id="body_contain">
      <div id="sd_contain">
        <div id="scheduleTop" style="margin-bottom:50px;">
              <!-- <button <?php if($session_id!='kkj'){echo 'style="display:none;"';} ?> type="button" name="button" onclick="customPop();" class="fc-addSchedule-button fc-button fc-button-primary"><img src="<?php echo $misc?>/img/setting.png" style="width:25px; height:25px; vertical-align:middle;"></button> -->
              <form id="searchWord" method="POST">
                <br>
                <div class="searchbox searchDiv" id="searchDiv" >
                  <select id="searchSelect" class="input" style="vertical-align:middle; border-radius:20px; height:23px; outline:none;"  onchange="searchSelFunc()">
                    <option value="participant">참석자</option>
                    <option value="user_name">등록자</option>
                    <option value="work_name">구분</option>
                    <option value="support_method">지원방법</option>
                    <option value="customer">고객사</option>
                    <option value="contents">내용</option>
                    <option value="group">부서</option>
                  </select>
                </div>
                <div class="searchbox changeDiv" id="changeDiv">
                  <input type="text" id="searchText" class="input2" style="vertical-align:middle; border-radius:20px; outline:none;" placeholder="검색어를 입력하세요." autocomplete="off" onfocus="onFoc(this.id)">
                  <!-- <input type="text" id="searchText" class="input2" style="vertical-align:middle; border-radius:20px; outline:none;" placeholder="검색어를 입력하세요." autocomplete="off" onfocus="onFoc(this.id)" onClick="searchAddUserBtn()" readonly> -->

                  <!-- onkeyup="this.value = onlyKor(this.value);"  -->
                  <!-- onkeyup="onlyKor(this);" -->
                  <!-- style="width: 270px;" -->
                  <img src="<?php echo $misc; ?>/img/participant_add.png" id="selectParticipantBtn" class="btn" style="width:22px; height:22px; margin:0 3px; vertical-align:middle;" onclick="searchAddUserBtn()">
                </div>
                <div class="searchbox changeDiv2" id="changeDiv2" style="display:none;">
                  <select class="input" id="work_nameSelect" style="height:23px; border-radius:20px; outline:none;" onfocus="onFoc(this.id)" >
                    <!-- style="width: 275px;" -->
                    <option value="" selected disabled hidden>선택하세요</option>
                    <?php
                      foreach ($work_name as $val2) {
                        echo "<option value = '{$val2->work_name}'>{$val2->work_name}</option>";
                      }
                    ?>
                </select>
                </div>
                <div class="searchbox changeDiv3" id="changeDiv3" style="display:none;">
                  <select class="input" id="support_methodSelect" style="height:23px;  border-radius:20px; outline:none;" onfocus="onFoc(this.id)" >
                    <!-- style="width: 275px;" -->
                    <option value="" selected disabled hidden>선택하세요</option>
                    <option value="현장지원">현장지원</option>
                    <option value="원격지원">원격지원</option>
                  </select>
                </div>
                <div class="searchbox changeDiv4" id="changeDiv4" style="display:none;">
                  <select class="input" id="customerSelect" style="height:23px; border-radius:20px; outline:none;" onfocus="onFoc(this.id)" onmouseover="select2(this);">
                    <option value="" selected disabled hidden >선택하세요</option>
                    <?php
                    foreach ($search_customer as $val) {
                      echo "<option value = '".$val['customer']."'>".$val['customer']."</option>";
                    }
                    ?>
                  </select>
                </div>
                <div class="searchbox searchBtnDiv" id="searchBtnDiv">
                  <img id="searchBtn" style="height:23px;width:23px; text-align:middle; cursor:pointer;" onclick="func_search()" src="<?php echo $misc; ?>img/dashboard/btn/btn_search.png">
                  <!-- <button type="button" name="submit" id="searchBtn" style="height:25px; text-align:middle;" onclick="func_search()" class="basicBtn">검색</button> -->
                  <input class="basicBtn" type="submit" id="searchReset" style="display:none;height:25px;" onclick="list_search()" value="초기화">
                  <button type="button" name="button" onclick="excelExport();" class="fc-addSchedule-button fc-button fc-button-primary basicBtn" id="excelDownload" style="display:none; height:25px; width:80px;">엑셀 다운</button>
              </div>
            </form><br><br>
        </div>
        <div class="" style="text-align:left;" id="company_schedule">
          <input type="checkbox" id="company_schedule_checkbox" onclick="company_schedule_check()" checked>공지사항 보기
        </div>
        <div id="scheduleSidebar" style="text-align: left;">
          <!-- <h2>sidebar</h2> -->
          <!-- @@ ↓ -->

          <div id="tree">
            <ul>
              <li>(주)두리안정보기술
                <ul>
                <?php
                foreach ($parentGroup as $pg){
                ?>
                  <?php
                  if ($pg->childGroupNum==1 && $pg->depth==1){
                  ?>
                    <li>
                      <?php echo $pg->parentGroupName;
                      foreach ($userInfo as $ui){
                          if ($pg->groupName==$ui->user_group){
                      ?>
                      <ul>
                        <li id="<?php echo $ui->user_name; ?>"><?php echo $ui->user_name." ".$ui->user_duty; ?></li>
                      </ul>
                      <?php
                          }
                      }
                      ?>
                    </li>
                  <?php
                  } else if ($pg->childGroupNum>1 && $pg->depth==1){
                  ?>
                  <li>
                    <?php echo $pg->parentGroupName;
                    foreach ($user_group as $ug) {
                      if ($pg->parentGroupName==$ug->parentGroupName){
                    ?>
                    <ul>
                    <?php
                      foreach ($userDepth as $ud){
                        if ($ug->groupName == $ud->groupName){
                          echo '<li id="'.$ud->user_name.'">'.$ud->user_name." ".$ud->user_duty.'</li>';
                        }
                      }
                      if ($ug->groupName != $pg->groupName){
                        echo "<li>".$ug->groupName;
                      }
                    ?>
                        <ul>
                          <?php
                          foreach($userInfo as $ui) {
                            if ($ug->groupName==$ui->user_group){
                              echo '<li id="'.$ui->user_name.'">'.$ui->user_name." ".$ui->user_duty.'</li>';
                            }
                          }
                          ?>
                        </ul>
                      </li>
                    </ul>
                    <?php
                      }
                    }
                    ?>
                  </li>
                    <?php
                  }
                    ?>
                <?php
                }
                ?>
                </ul>
              </li>
            </ul>

          </div>
          <!-- @@ ↑ -->
        </div>
        <div id='calendar' style="padding-bottom:100px;">
          <!-- 여기 달력뷰 -->
        </div>
      </div>
      <!-- <div id="scheduleBottom"> </div> -->
      <!-- ↑sd 컨테인 끝 -->

      <div id = 'updateSchedule' style="display: none; background-color: white; width:30%; height: auto;" class="layerpop" >
        <article class="layerpop_area">
          <form id="de_hiddenSeq" name="de_cform" method="GET">
            <!-- KI2 20210125 -->
            <div align="center" class="modal_title">일정 상세
              <a style="float:right" onclick="$('#updateSchedule').bPopup().close();">
                <img src="/misc/img/btn_del2.jpg"/>
              </a>
            </div>

                  <table width="100%" border="0" callspacing="0" cellspacing="0">
                    <!-- KI1 20210125 고객사 담당자 선택을 위한 name=cform 적용-->
                      <!-- KI2 20210125 -->
                      <!-- <form name="hiddenSeq" action="<?php echo site_url();?>/schedule/modify" method="post"> -->
                      <!-- <tbody> -->
                      <!-- 일정의 seq -->
                      <input type="hidden" name="de_seq" id="de_seq" value="">
                      <input type="hidden" id ="de_work_type" name="de_work_type" value="">
                      <input type="hidden" id="de_mode" name="de_mode" value="">
                      <input type="hidden" id="de_link" name="de_link" value="">
                      <!-- KI1 20210125 고객사 담당자 적용을 위한 hidden input 적용, 프로젝트 input 추가 -->
                      <input type="hidden" name="de_customer_manager" id="de_customer_manager" class="input2" value="">
                      <!-- <input type="hidden" name="de_maintain_end" id="de_maintain_end" class="input2">
                      <input type="hidden" id="de_row_max_index" name="de_row_max_index" value="0" />
                      <input type="hidden" id="de_customer_tmp" name="de_customer_tmp" value="" /> -->
                      <!-- ↑customerName과 동일 -->
                      <input type="hidden" id="de_forcasting_seq" name="de_forcasting_seq" value="" />
                      <input type="hidden" id="de_maintain_seq" name="de_maintain_seq" value="" />
                      <tr>
                        <td colspan="10" height="2" bgcolor="#173162"></td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                     </tr>
                     <tr>
                       <td>
                         <td align="center">
                           <table border="0" cellspacing="0" cellpadding="0" width="95%" style="table-layout:fixed;">
                           <colgroup>
                            <col width="25%" />
                            <col width="25%" />
                            <col width="25%" />
                            <col width="25%" />
                          </colgroup>
                              <tbody>
                               <tr>
                                 <td colspan="4" height="2" bgcolor="#797c88"></td>
                               </tr>
                               <tr>
                                 <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">구분</td>
                                 <td colspan="1" class="t_border" style="padding-left:10px;">
                                   <select name="de_workname" id="de_workname" onchange="">
                                     <option value="" selected disabled hidden>선택하세요</option>
                                      <?php
                                      foreach ($work_name as $val) {
                                        echo "<option value='{$val->work_name}' >{$val->work_name}</option>";
                                      }
                                      ?>
                                   </select>
                                 </td>
                                 <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; " class="de_tech_div">지원방법</td>
                                 <td class="t_border de_tech_div" style="padding-left:10px;">
                                   <select name="de_supportMethod" id="de_supportMethod">
                                     <option value="" selected disabled hidden>선택하세요</option>
                                     <option value="현장지원">현장지원</option>
                                     <option value="원격지원">원격지원</option>
                                   </select>
                                 </td>

                               </tr>
                               <tr class="de_except_nondisclosure_div">
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr class="de_except_nondisclosure_div">
                                 <td colspan="4">
                                   <button type="button" id="de_conference" style="outline:none;" onclick="open_conference('detail');" class="basicBtn2" onMouseOver="this.style.backgroundColor='#333333',this.style.color='#ffffff'" onMouseOut="this.style.backgroundColor='#DBDBDb', this.style.color='#333333'">회의실 예약</button>
                                   <input type="text" id="de_room_name" name="de_room_name" value="" readonly>
                                   <button type="button" name="button" onclick="$('#de_room_name').val('');" style="width:25px; height:20px; outline:none;" class="basicBtn2" onMouseOver="this.style.backgroundColor='#333333',this.style.color='#ffffff'" onMouseOut="this.style.backgroundColor='#DBDBDb', this.style.color='#333333'">X</button>
                                 </td>
                               </tr>
                               <tr class="de_except_nondisclosure_div">
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr class="de_except_nondisclosure_div">
                                  <td colspan="4">
                                    <button type="button" id="de_car_reservation" style="outline:none;"  onclick="open_car_reservation('detail');" class="basicBtn2" onMouseOver="this.style.backgroundColor='#333333',this.style.color='#ffffff'" onMouseOut="this.style.backgroundColor='#DBDBDb', this.style.color='#333333'">차 량 예 약</button>
                                    <input type="text" id="de_car_name" name="de_car_name" value="" readonly>
                                    <button type="button" name="button" onclick="$('#de_car_name').val('');" style="width:25px;height:20px; outline:none;" class="basicBtn2" onMouseOver="this.style.backgroundColor='#333333',this.style.color='#ffffff'" onMouseOut="this.style.backgroundColor='#DBDBDb', this.style.color='#333333'">X</button>
                                  </td>
                               </tr>
                               <tr>
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr>
                                 <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">시작일자</td>
                                 <td colspan="3" class="t_border" style="padding-left:10px;">
                                  <?php if($this->agent->is_mobile()){ ?>
                                    <input type="date" name="de_startDay" id="de_startDay" class="dayBtn" value="" autocomplete="off" onchange="conference_room_del('update'); date_compare('de_');" style="width:50%;vertical-align:middle;">
                                    <input type="time" name="de_startTime" id="de_startTime" class="timeBtn" value="" autocomplete="off" style="width:30%;vertical-align:middle;">
                                  <?php }else{?>
                                    <input type="text" name="de_startDay" id="de_startDay" class="dayBtn" value="" autocomplete="off" onchange="conference_room_del('update'); date_compare('de_');" style="width:40%;">
                                    <input type="button" name="" id="de_startBtn" class="dateBtn" onclick="openStartDate('de');" style="width:10%;vertical-align:middle;" >
                                    <input type="text" name="de_startTime" id="de_startTime" class="timeBtn" value="" autocomplete="off" style="width:30%">
                                  <?php } ?>
                                  </td>
                               </tr>
                               <tr>
                                 <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">종료일자</td>
                                 <td colspan="3" class="t_border" style="padding-left:10px;">
                                  <?php if($this->agent->is_mobile()){ ?>
                                    <input type="date" name="de_endDay" id="de_endDay" class="dayBtn" value="" autocomplete="off" onchange="conference_room_del('update'); date_compare('de_');" style="width:40%;vertical-align:middle;">
                                    <input type="time" name="de_endTime" id="de_endTime" class="timeBtn" value="" autocomplete="off" style="width:30%;vertical-align:middle;">
                                  <?php }else{?>
                                    <input type="text" name="de_endDay" id="de_endDay" class="dayBtn" value="" autocomplete="off" onchange="conference_room_del('update'); date_compare('de_');" style="width:40%">
                                    <input type="button" name="" id="de_endBtn" class="dateBtn" value=" " onclick="openEndDate('de');" style="width:10%">
                                    <input type="text" name="de_endTime" id="de_endTime" class="timeBtn" value="" autocomplete="off" style="width:30%">
                                  <?php } ?>
                                 </td>
                               </tr>
                               <tr class="de_general_div de_sch_title_div">
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr class="de_general_div de_sch_title_div">
                                 <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">제목</td>
                                 <td colspan="3" class="t_border" style="padding-left:10px">
                                   <input type="text" name="de_title" id="de_title" value="" style="width:70%;">
                                 </td>
                               </tr>
                               <tr class="de_general_div de_sch_loc_div">
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr class="de_general_div de_sch_loc_div">
                                 <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">장소</td>
                                 <td colspan="3" class="t_border" style="padding-left:10px">
                                   <input type="text" name="de_place" id="de_place" value="" style="width:70%;">
                                 </td>
                               </tr>
                               <!-- <tr> -->
                               <tr class="de_except_company_div">
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr class="de_except_company_div">
                               <!-- <tr class="de_tech_div"> -->
                                 <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">고객사</td>
                                 <td colspan="3" class="t_border" style="padding-left:10px;">

                                     <div class="dropdown de_tech_div" id="de_dropdown">
                                       <p onclick="searchFunction(this.id)" id="de_dropbtn" class="dropbtn">검색</p>
                                       <input id="de_customerName" name ="de_customerName" type="text" class="customerName" value="" style="border:none;width:200px;font-weight:bold;text-align:center;">
                                       <!-- <input id="de_customerName" name ="de_customerName" type="text" class="customerName" value="" style="border:none;width:200px;font-weight:bold;text-align:center;" onchange="customerNameChange(this.value);"> -->

                                       <input type="hidden" id="de_customer" name="de_customer" value="" style="border:none" readonly>
                                       <div id="de_myDropdown" class="dropdown-content">
                                         <input type="text" name="0" placeholder="고객사를 입력하세요" id="de_searchInput" class="searchInput" onkeyup="filterFunction(this)" autocomplete="off">
                                         <div id="de_dropdown_option" style="overflow:scroll; width:277px; height:300px;">
                                         </div>
                                       </div>
                                     </div>
                                     <div class="de_general_div">
                                       <input type="text" id="de_customerName2" name="de_customerName2" value="" style="width:70%;" >
                                     </div>

                                 </td>
                               </tr>
                               <tr class="de_tech_div">
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr class="de_tech_div">
                                 <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">프로젝트</td>
                                 <td colspan="3" class="t_border" style="padding-left:10px">
                                   <input type="text" id="de_project" name="de_project" value="" style="width:70%;" />
                                 </td>
                               </tr>
                               <tr class="de_except_company_div de_except_nondisclosure_div">
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr class="de_except_company_div de_except_nondisclosure_div">
                                 <!-- <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">참석자</td>
                                 <td colspan="3" class="t_border" style="padding-left:10px">
                                   <input type="text" name="de_participant" id="de_participant" value="" placeholder="" size='45' autocomplete="off">
                                   <input type="image" src="<?php echo $misc; ?>/img/participant_add.jpg" id="de_addUserBtn" class="btn" style="width:25px; height:25px; vertical-align:middle;" onclick="addUser_Btn();return false;">
                                 </td> -->
                                 <td height="40" align="center" bgcolor="f8f8f9" style="font-weight:bold; ">참석자</td>
                                 <td colspan="3" class="t_border" style="padding-left:10px; padding-bottom:5px;">
                                   <li>
                                     <div class="" size='45' style="padding:5px 0;">
                                       <input type="text" name="de_participant_input" id="de_participant_input" value="" placeholder="" onkeypress="keypress(event,this.value,'de_participant')" autocomplete="off">
                                       <input type="hidden" name="de_participant" id="de_participant" value="" placeholder="">
                                       <img src="<?php echo $misc; ?>/img/participant_add.png" id="addUserBtn" class="btn" style="width:17px; height:17px; border:1px solid lightgray; padding:2px; vertical-align:middle;" onclick="addUser_Btn();return false;">
                                       <!-- <input type="image" src="<?php echo $misc; ?>/img/participant_add.jpg" id="addUserBtn" class="btn" style="width:25px; height:25px; vertical-align:middle;" onclick="addUser_Btn();return false;"> -->
                                     </div>
                                   </li>
                                   <li>
                                     <div id="de_participant_box" name="de_participant_box" max-size='45' style="max-height:40px; max-width:380px; overflow-x:auto;">

                                     </div>
                                   </li>
                                 </td>
                               </tr>
                               <tr>
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr class="de_general_div de_explanation_div" style="display:none;">
                                 <td colspan="1" height="3" bgcolor="#f8f8f9"></td>
                                 <td colspan="3" height="3" bgcolor="#f8f8f9" class="t_border">
                                   <div class="" style="float:left; width:50%; text-align:left;">
                                     <span style="font-size:10px; font-weight:bold;">주간업무</span>
                                   </div>
                                   <div class="" style="display:inline-block; width:50%; text-align:right;">
                                     <span style="font-size:10px; font-weight:bold;">추가/삭제</span>
                                   </div>
                                 </td>
                               </tr>
                               <tr id="de_contents_tr_0">
                                 <td align="center" bgcolor="f8f8f9" style="font-weight:bold; ">내용</td>
                                 <td class="t_border" colspan="3" bgcolor="f8f8f9" align="left">
                                   <input type="checkbox" class="add_weekly_report" id="de_add_weekly_report_0" name="de_add_weekly_report" value="" style="vertical-align:middle;width:10%;float:left">
                                   <!-- textarea의 cols는 실질적으로 js에 있는 contents_split_type에서 41로 지정한 값이 반영된다. -->
                                   <textarea rows="2" name='de_contents' id="de_contents_0" placeholder="상세내용" style="resize:none; vertical-align:middle; margin:2px -1.8px;width:70%;float:left"></textarea>
                                   <input type="hidden" name="de_contents_num" id="de_contents_num_0" value="0">
                                   <!-- <img src="<?php echo $misc; ?>img/btn_add.jpg" id="contents_add" name="contents_add" onclick="contents_add_action('de_contents');return false;" style="cursor:pointer; vertical-align:middle;float:right;" /> -->
                                   <img src="<?php echo $misc; ?>img/btn_add.jpg" id="contents_add" name="contents_add" style="cursor:pointer; vertical-align:middle;float:right;" />
                                 </td>

                               <!-- 기술연구소 -->
                               <tr height="40" id="de_lab_contents_tr" class="de_lab_contents_tr" style="display:none;">
                                  <td align="center" bgcolor="f8f8f9" style="font-weight:bold">개발구분</td>
                                  <td class="t_border" bgcolor="f8f8f9" align="left" style="padding-left:10px">
                                    <select id="de_dev_type" name="dev_type">
                                      <option value="" selected disabled hidden>선택하세요</option>
                                      <option value="신규개발">신규개발</option>
                                      <option value="기능개선">기능개선</option>
                                      <option value="버그수정">버그수정</option>
                                    </select>
                                  </td>
                                  <td class="t_border" align="center" bgcolor="f8f8f9" style="font-weight:bold">페이지</td>
                                  <td class="t_border" bgcolor="f8f8f9" align="left" style="padding-left:10px">
                                    <input type="text" id="de_dev_page" name="de_dev_page" value="" style="width:90%;">
                                  </td>
                               </tr>
                               <tr class="de_lab_contents_tr">
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr height="40" id="de_lab_contents_tr" class="de_lab_contents_tr" style="display:none;">
                                 <td align="center" bgcolor="f8f8f9" style="font-weight:bold">요청자</td>
                                 <td colspan="3" class="t_border" bgcolor="f8f8f9" align="left" style="padding-left:10px">
                                   <input type="text" id="de_dev_requester" name="de_dev_requester" value="" style="width:96.5%;">
                                 </td>
                               </tr>
                               <tr class="de_lab_contents_tr">
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr height="40" id="de_lab_contents_tr" class="de_lab_contents_tr" style="display:none;">
                                 <td align="center" bgcolor="f8f8f9" style="font-weight:bold">개발사항</td>
                                 <td colspan="3" class="t_border" bgcolor="f8f8f9" align="left" style="padding-left:10px">
                                   <textarea id="de_dev_develop" name="de_dev_develop" rows="5" cols="52" style="resize:none; vertical-align:middle; margin:2px -1.8px;width:96.5%;float:left"></textarea>
                                 </td>
                               </tr>
                               <tr class="de_lab_contents_tr">
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr height="40" id="de_lab_contents_tr" class="de_lab_contents_tr" style="display:none;">
                                  <td align="center" bgcolor="f8f8f9" style="font-weight:bold;">완료여부</td>
                                  <td class="t_border" style="padding-left:10px">
                                    <input type="checkbox" id="de_dev_complete" name="de_dev_complete" value="">
                                  </td>
                               </tr>
                               <!-- 기술연구소 -->

                               <tr class="de_report_div" style="display:none;">
                                 <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
                               </tr>
                               <tr class="de_report_div" style="display:none;">
                                 <!-- <td align="center" bgcolor="f8f8f9" style="font-weight:bold; ">주간보고</td>
                                 <td colspan="1" class="t_border" style="padding-left:10px;">
                                   <input type="checkbox" id="de_add_weekly_report" name="de_add_weekly_report" value="">
                                 </td> -->
                                 <!-- 내용분할 전에 주간보고여부가 작성된 일정들을 위한 예외1 -->
                                 <!-- <input type="hidden" id="de_old_weekly_report" name="de_old_weekly_report" value=""> -->
                                 <!-- 내용분할 전에 주간보고여부가 작성된 일정들을 위한 예외2 -->
                                 <td align="center" bgcolor="f8f8f9" style="font-weight:bold; ">비공개</td>
                                 <td colspan="1" class="t_border" style="padding-left:10px;">
                                   <input type="checkbox" id="de_nondisclosure_sch" name="de_nondisclosure_sch" value="" onclick="nondisclosure_form('de_nondisclosure')">
                                 </td>
                               </tr>
                               <tr>
                                 <td colspan="4" height="2" bgcolor="#797c88"></td>
                               </tr>
                               <tr>
                                 <td>&nbsp;</td>
                               </tr>
                             </tbody>
                           </table>
                           <div id="schdule_contoller_btn2" style="display:none;">
                             <input type="button" name="updateSubmit" id="updateSubmit" class="basicBtn" onclick="modify('schedule_modify')" value="수정">
                           </div>
                           <div id="schdule_contoller_btn">
                             <input type="button" name="updateSubmit" id="updateSubmit" class="basicBtn" onclick="modify('schedule_modify')" value="수정">
                             <input type="button" name="delSubmit" id="delSubmit" class="basicBtn hidden_btn" onclick="modify('schedule_delete')" value="삭제">
                             <!-- KI -->
                             <input type="button" id="techReportInsert" name="techReportInsert" class="basicBtn hidden_btn" style="width:150px;" onclick="modify('report')" value="기술지원보고서 작성">
                             <input type="button" id="techReportModify" name="techReportModify" class="basicBtn hidden_btn" style="width:150px;" onclick="modify('modify')" value="기술지원보고서 수정">
                           </div>
                         </td>
                       </td>
                     </tr>
                   </table>
              </form>
            </article>
          </div>
    <!-- 디테일 디브 끝 -->
      </div>
<!-- 회의실 예약 시작 -->
<!-- <div id="conference_div" style="display:none; position: absolute; background-color: white; width: auto; height: auto;"> -->
<div id="conference_div" style="display:none; position: absolute; background-color: white; width: 1150px; height: auto;">
<!-- <div id="conference_div" style="display:none; position: absolute; background-color: white; width: 950px; height: 300px;"> -->
  <div style="background-color: #aaaab3;text-align:right;">
      <img id="addUserpopupCloseBtn" src="<?php echo $misc;?>img/btn_del2.jpg"  onclick="$('#conference_div').bPopup().close();" width=25 style="cursor:pointer;" />
      <!-- <span id="addUserpopupCloseBtn" class="btn" onclick="$('#conference_div').bPopup().close();" style="color:#e03b09;font-size:14px;">X</span> -->
  </div>
  <!-- <div id="select_date" style="width: 20%; height:90%; float:left; border: 1px solid #000; margin-bottom:20px;margin-top:20px;"> -->
  <div id="select_date" style="width: 18%; height:90%; float:left; border: 1px solid #000; margin:20px 0px 20px 20px;">
  <!-- <div>
    <input type="text" name="" value="" id="select_date"> -->
  </div>
  <!-- <div id="select_table" style="width: 78%; height:90%; float:right; border: none; margin-bottom:20px;margin-top:20px;"> -->
  <div id="select_table" style="width: 80%; height:90%; float:right; border:none; margin-top:20px;margin-bottom:20px;">
  <!-- <div id="select_table" style="width: 78%; height:90%; float:right; border: 1px solid #000;"> -->
    <input type="hidden" id="select_day" name="select_day" value="">
    <input type="hidden" id ="selected_room_name" name="selected_room_name" value="">
    <div>
      <table class="select_time" style="width:98%; margin-right:50px;">
      <!-- <table class="select_time"> -->
        <thead class="select_time_th">
        <tr>
          <th>회의실명</th>
          <th colspan="2">08</th>
          <th colspan="2">09</th>
          <th colspan="2">10</th>
          <th colspan="2">11</th>
          <th colspan="2">12</th>
          <th colspan="2">13</th>
          <th colspan="2">14</th>
          <th colspan="2">15</th>
          <th colspan="2">16</th>
          <th colspan="2">17</th>
          <th colspan="2">18</th>
          <th colspan="2">19</th>
          <th colspan="2">20</th>
          <th colspan="2">21</th>
        </tr>
        </thead>
        <tbody class="select_time_tb" id="selectable">
          <?php
            function plus_time($start){
              $last = strtotime('22:00');
              if($start < $last){
                $start_time = date("H:i", $start);
                $end = strtotime('+30 minutes', $start);
                $end_time = date("H:i", $end);
                $id_time = (int)str_replace(':','',$start_time);
                echo "<td class = 'td_item' style='cursor:pointer;' id='{$id_time}' onmouseover='tooltip(this);' onmouseout='tooltip_remove(this);'>{$start_time}{$end_time}<div class='tooltip-content'></div></td>";
                plus_time($end);
              }
            }
                   foreach ($rooms as $room) {

                     echo "<tr id='{$room->room_name}'>";
                     $start = strtotime('08:00');
                     echo "<td class='dragable' id='room_name_td' style='cursor:s-resize'>{$room->room_name}</td>";
                     plus_time($start);
                     echo "</tr>";

                   }
           ?>

        </tbody>
      </table>
    </div>
    <div>
      <p id="feedback" style="display:none;">
        <span>You&apos;ve selected:</span> <span id="select_room_result">none</span>
        <!-- <span id="select_room_name">/</span> -->
      </p>
      <button type="button" id="add_conference_btn" name="add_conference_btn" onclick="add_conference(this.name);" class="basicBtn">등록</button>
    </div>
  </div>
</div>
<!-- 회의실 예약 끝 -->

<!-- 차량 예약 시작 -->
<div id="car_reservation_div" style="display:none; position: absolute; background-color: white; width: 1150px; height: auto;">
<!-- <div id="car_reservation_div" style="display:none; position: absolute; background-color: white; width: auto; height: 300px;"> -->
  <div style="background-color: #aaaab3;text-align:right;">
    <img id="addUserpopupCloseBtn" src="<?php echo $misc;?>img/btn_del2.jpg" onclick="$('#car_reservation_div').bPopup().close();" width=25 style="cursor:pointer;"/>
      <!-- <span id="addUserpopupCloseBtn" class="btn" onclick="$('#car_reservation_div').bPopup().close();"style="margin:0% 0% 0% 96%; color:#e03b09">X</span> -->
  </div>
  <div id="select_car_date" style="width: 18%; height:90%; float:left; border: 1px solid #000; margin:20px 0px 20px 20px;">
  <!-- <div>
    <input type="text" name="" value="" id="select_date"> -->
  </div>
  <div id="select_car_table" style="width: 80%; height:90%; float:right; border: none; margin-bottom:20px;margin-top:20px;">
  <!-- <div id="select_car_table" style="width: 78%; height:90%; float:right; border: 1px solid #000;"> -->
    <input type="hidden" id="select_car_day" name="select_car_day" value="">
    <input type="hidden" id ="selected_car_name" name="selected_car_name" value="">
    <div>
      <table class="select_time" style="width:98%; margin-right:50px;">
        <thead class="select_time_th">
        <tr>
          <th>차종</th>
          <!-- <th>번호</th> -->
          <th colspan="2">08</th>
          <th colspan="2">09</th>
          <th colspan="2">10</th>
          <th colspan="2">11</th>
          <th colspan="2">12</th>
          <th colspan="2">13</th>
          <th colspan="2">14</th>
          <th colspan="2">15</th>
          <th colspan="2">16</th>
          <th colspan="2">17</th>
          <th colspan="2">18</th>
          <th colspan="2">19</th>
          <th colspan="2">20</th>
          <th colspan="2">21</th>
        </tr>
        </thead>
        <tbody class="select_time_tb" id="select_car_tbody">
          <?php

           foreach ($cars as $car) {

             echo "<tr id='{$car->type}{$car->number}'>";
             $start = strtotime('08:00');
             echo "<td name='car_info' id='car_name_td'>{$car->type}<br>{$car->number}</td>";
            //  echo "<td name='car_info' id='car_num_td'>{$car->number}</td>";
             plus_time($start);
             echo "</tr>";

           }
           ?>

        </tbody>
      </table>
    </div>
    <div style="bottom: 0;">
      <p id="feedback" style="display:none;">
        <span>You&apos;ve selected:</span> <span id="select_car_result">none</span>
      </p>
      <button type ="button" id ="add_car_btn" name = "add_car_btn" onclick="add_car(this.name);" class="basicBtn">등록</button>
    </div>
  </div>
</div>
<!-- 차량 예약 끝 -->

<!-- 팝업뜰때 배경 -->
<div id="mask2"></div>
<!--schedule detail Popup Start -->
<!-- <form class="" name="" action="index.html" method="post"> -->
<div id="show_day_select_popup" name="show_day_select_popup" class="layerpop" style="width: 550px; height: 470px;">
  <article class="layerpop_area">
    <div align="center" class="modal_title">일정 선택</div>
    <a href="javascript:popupClose('show_day_select_popup');" class="layerpop_close" id="layerbox_close"><img src="/misc/img/btn_del2.jpg"/></a>
    <table width="100%" border="0" callspacing="0" cellspacing="0">
      <tr>
        <td colspan="10" height="2" bgcolor="#173162"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>
          <td align="center"><table border="0" cellspacing="0" cellpadding="0" style="">
            <colgroup>
              <col width="3%" />
              <col width="15%" />
              <col width="20%" />
              <col width="15%" />
            </colgroup>
            <tr>
              <td colspan="4" height="2" bgcolor="#797c88"></td>
            </tr>
            <tr bgcolor="f8f8f9" class="t_top">
              <td height="40" align="center"></td>
              <td align="center" class="t_border">일차</td>
              <td align="center" class="t_border">작업일</td>
              <td align="center" class="t_border">보고서 작성</td>
            </tr>
            <tr>
              <td colspan="4" height="1" bgcolor="#e8e8e8"></td>
            </tr>
            <tbody id="select_day_body"></tbody>
            <tr>
              <td colspan="4" height="2" bgcolor="#797c88"></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
          <div id="select_day_btn"></div>
        </td>
      </td>
    </tr>
  </table>
</article>
</div>
<!--schedule insert Popup End -->


<!-- 일정 중복방지 팝업창 시작 -->

<div id="duple_sch_popup" name="duple_sch_popup" class="layerpop" style="display:none; width:700px; height:auto;">
  <article class="layerpop_area" align="center">
  <div align="center" class="modal_title">유사 일정 목록</div>
  <table width="100%" border="0" callspacing="0" cellspacing="0">
  	<tr>
  	   <td colspan="10" height="2" bgcolor="#173162" align="center"></td>
  	</tr>
    <tr >
      <td style="padding:10px 0;">
        <!-- 유사한 일정이 다음과 같이 존재합니다. 일정 등록을 계속 진행하시겠습니까?
        <br> -->
        ※유사한 일정이 다음과 같이 존재합니다. 중복 일정이 있는지 확인 후 등록해주세요.※
      </td>
    </tr>
  </table>

  <table border="0" cellspacing="0" cellpadding="0" style="width:90%" align="center" id="duple_sch_list">
  </table>
  <table>
    <button type="button" name="duple_sch_continue" id="duple_sch_continue" class="basicBtn" onclick="duple_sch_chk='true'; $('#scheduleAdd').click(); $('#duple_sch_popup').bPopup().close();">등록</button>
    &nbsp;
    <button type="button" name="duple_sch_stop" id="duple_sch_stop" class="basicBtn" onclick="$('#duple_sch_popup').bPopup().close(); $('#addpopup').bPopup().close();" >취소</button>
  </table>
  </article>
</div>
<!-- 일정 중복방지 팝업창 끝 -->


      <!-- //여기까지 -->
    </td>
  </tr>
  <tr>
    <td align="center">
      <div style="width:90%;text-align:right;margin-top:15px;<?php if($session_id!='kkj'){echo 'display:none;';} ?>">

          <img src="<?php echo $misc?>/img/setting.png" style="width:20px;height:20px;cursor:pointer;" onclick="customPop();">

      </div>
    </td>
  </tr>
  <!--하단-->
</table>
<?php include $this->input->server('DOCUMENT_ROOT')."/include/sales_bottom.php"; ?>
<script>
// KI2 20210125
// function modify(mode){
//   $('#detail_contain').hide();
//   $('#sd_contain').show();
//     calendarRefresh();
// if(mode = 'schedule_delete'){
//   }
// }


function modify(mode){
  var seq = $("#de_seq").val();
  var work_type = $('#de_work_type').val();
  // var customer_manager = $("#de_customer_manager").val();
  var start_day = $("#de_startDay").val();
  var start_time = $("#de_startTime").val();
  var end_day = $("#de_endDay").val();
  var end_time = $("#de_endTime").val();
  var work_name = $("#de_workname").val();
  var customerName = $("#de_customerName").val();
  var customerName2 = $("#de_customerName2").val();
  var forcasting_seq = $("#de_forcasting_seq").val();
  var maintain_seq = $("#de_maintain_seq").val();
  var project = $("#de_project").val();
  var tech_report = $("#de_tech_report").val();
  var support_method = $("#de_supportMethod").val();
  var participant = $("#de_participant").val();
  // var contents = $("#de_contents").val();
  var title = $("#de_title").val();
  var place = $("#de_place").val();
  var sday = $('#de_startDay').val();
  var eday = $('#de_endDay').val();
  var room_name = $('#de_room_name').val();
  var car_name = $('#de_car_name').val();
  if(room_name == '' && car_name != ''){
    var name = car_name;
    var type = 'car_name';
  }else{
    var name = room_name;
    var type = "room_name";
  }
  // if($('#de_add_weekly_report').is(":checked") == true){
  //   var weekly_report = "Y";
  // }else{
  //   var weekly_report = "N";
  // }
  // if($('#de_old_weekly_report').val() != null){
  //
  // }
  if($('#de_nondisclosure_sch').is(":checked") == true){
    var nondisclosure = "Y";
  }else{
    var nondisclosure = "N";
  }

  //내용분할1
  //일정 내용 분할 값과 주간보고 여부를 배열로 만들어서 보내기
  var contents= [];
  // if(work_type != 'tech' && work_type !='lab'){
  if(work_type != 'lab'){

    var length = $('textarea[name=de_contents]').length;

    if(length > 1){
      for(var j = 1; j < length; j++){
        //contents_0을 제외하고 나머지 contents들이 빈값인 상태일때는 해당 칸을 삭제하고 입력한다.
        if (($('#de_contents_'+j).val()== "") || ($('#de_contents_'+j).val()== "undefined")) {
          alert(j+1 + "번째 내용이 비었습니다.");
          return false;
        }
      }
    }

    for(var i = 0; i < length; i++){ //내용이 분할 안된 것들도 0번 한번은 돌게 되어있기에 내용이 수정된다.
      var contents_val = $('#de_contents_'+i).val();
      var contents_num_val = $('#de_contents_num_'+i).val();
      if($('#de_add_weekly_report_'+i).is(':checked') == true){
        var weekly_report_val = 'Y';
      }else{
        var weekly_report_val = 'N';
      }
      if(work_type == 'tech'){
        var weekly_report_val = 'Y';
      }
      contents.push({
        'contents':contents_val,
        'contents_num':contents_num_val,
        'weekly_report':weekly_report_val
      })
    }

  }else{
    var dev_type = $("#de_dev_type").val();
    var dev_page = $("#de_dev_page").val();
    var dev_requester = $("#de_dev_requester").val();
    var dev_develop = $("#de_dev_develop").val();
    if ($("#de_dev_complete").is(':checked')==true){
      var dev_complete = 'Y';
    } else {
      var dev_complete = 'N';
    }

    var contents_val = "dev_type:::"+dev_type+",,,dev_page:::"+dev_page+",,,dev_requester:::"+dev_requester+",,,dev_develop:::"+dev_develop+",,,dev_complete:::"+dev_complete;
    contents.push({
      'contents': contents_val,
      'contents_num': 0,
      'weekly_report': 'Y'
    })
  }
  //내용분할2

  if(mode == 'schedule_delete'){
    var result = confirm("정말 삭제 하시겠습니까?");
    if(result){
      var seq = $('#de_seq').val();
      $.ajax({
        type: "POST",
        dataType : "json",
        url: "<?php echo site_url();?>/biz/schedule/delete",
        data: {
          seq: seq
        },
        success: function(result){
          // console.log(result);
          if (result == "report_written"){
            alert('보고서가 작성된 일정은 삭제할 수 없습니다.\n작성된 기술지원보고서를 먼저 삭제해주세요.');
            calendar.refetchEvents();
          }

          if(result == "true"){
            calendarRefresh();
            // $('#detail_contain').hide();
            // $('#sd_contain').show();
            $('#updateSchedule').bPopup().close();
          }
        }
      });
    }
  }

  if(mode == 'schedule_modify'){
    //KI1 20210125 입력시 빈칸이 있으면 넘어가지 않도록 조건 제한
    if( $('#de_work_type').val() == 'tech' ){

      if($('#de_startDay').val() == ''){
        alert('시작날짜를 입력해주세요.');
        $('#de_startDay').focus();
        return false;
      }
      if($('#de_endDay').val() == ''){
        alert('종료날짜를 입력해주세요.');
        $('#de_endDay').focus();
        return false;
      }
      if($('#de_startTime').val() == ''){
        alert('시작시간을 입력해주세요.');
        $('#de_startTime').focus();
        return false;
      }
      if($('#de_endTime').val() == ''){
        alert('종료시간을 입력해주세요.');
        $('#de_endTime').focus();
        return false;
      }
      if($('#de_workname').val() == ''){
        alert('작업구분을 입력해주세요.');
        $('#de_workname').focus();
        return false;
      }
      if($('#de_supportMethod').val() == ''){
        alert('지원방법을 입력해주세요.');
        $('#de_supportMethod').focus();
        return false;
      }
      if($('#de_customerName').val() == ''){
        alert('고객사를 선택해주세요.');
        $('#de_customerName').focus();
        return false;
      }
      if($('#de_project').val() == ''){
        alert('프로젝트란이 비어있습니다. 고객사를 다시 선택해주세요.');
        $('#de_customerName').val('');
        $('#de_customerName').focus();
        // $('#de_project').focus();
        return false;
      }
      if(($('#de_participant').val() == '') && ($('#de_work_type').val() != 'company')){
        alert('참석자를 선택해주세요.');
        $('#de_participant').focus();
        return false;
      }
    } else if ( $('#de_work_type').val() == 'lab' ) {
      if ($('#de_dev_type').val() == '') {
        alert('개발구분을 선택해주세요.');
        $('#de_work_type').focus();
        return false;
      }
      if ($('#de_dev_page').val() == '') {
        alert('개발 페이지를 입력해주세요.');
        $('#de_work_page').focus();
        return false;
      }
      if ($('#de_dev_develop').val() == '') {
        alert('개발사항을 입력해주세요.');
        $('#de_dev_develop').focus();
        return false;
      }
    } else{
      if($('#de_title').val() == ''){
        alert('제목을 입력해주세요.');
        $('#de_title').focus();
        return false;
      }
      if($('#de_endDay').val() == ''){
        alert('종료날짜를 입력해주세요.');
        $('#de_endDay').focus();
        return false;
      }
      if($('#de_endTime').val() == ''){
        alert('종료시간을 입력해주세요.');
        $('#de_endTime').focus();
        return false;
      }
      // if($('#de_place').val() == ''){
      //   alert('장소를 입력해주세요.');
      //   $('#de_place').focus();
      //   return false;
      // }
      if(($('#de_participant').val() == '') && ($('#de_work_type').val() != 'company')){
        alert('참석자를 선택해주세요.');
        $('#de_participant').focus();
        return false;
      }
    }
    //KI2 20210125
    var start_time_2 = moment(start_time,'HH:mm').format('HH:mm');
    var end_time_2 = moment(end_time,'HH:mm').format('HH:mm');
    if (start_time == '' && end_time != ''){
      alert("시작시간을 먼저 작성해 주세요.");
      $('#de_endTime').val('');
      return false;
    }
    if((start_day == end_day) && (start_time_2 > end_time_2)) {
        alert("종료시간이 시작시간보다 이전입니다.");
        $('#de_endTime').val('');
        return false;
    }

// alert('forcasting_seq:'+forcasting_seq+' maintain_seq:'+maintain_seq)

    // var act = "<?php echo site_url();?>/biz/schedule/modify"
    // $("#de_hiddenSeq").attr('action', act).submit();
    // var seq = $('#de_seq').val();
    $.ajax({
      type: "POST",
      url:"<?php echo site_url();?>/biz/schedule/duplicate_check",
      // url:"<?php //echo site_url();?>/biz/schedule/duplicate_checkroom",
      dataType:"json",
      data:{
        schedule_seq: seq,
        select_day: start_day,
        start:start_time,
        end:end_time,
        name: name,
        type: type
      },
      cache:false,
      async:false,
      success: function(data) {
        // console.log(data);
        if(data == 'dupl'){
          alert('중복되는 차량 혹은 회의실 일정이 있습니다.');
          stopPropagation();
        }
      }
    });

    $.ajax({
      type: "POST",
      url:"<?php echo site_url();?>/biz/schedule/sch_report_approval",
      dataType:"json",
      data:{
        schedule_seq: seq
      },
      cache:false,
      async:false,
      success: function(data) {
        // console.log(data);
        // alert(data['approval_yn']);
        if(data === 'Y'){
          alert('주간업무보고 결제가 완료된 일정은 수정할 수 없습니다.');
          stopPropagation();
        }
      }
    });


    $.ajax({
      type: "GET",
      dataType : "json",
      url: "<?php echo site_url();?>/biz/schedule/modify",
      data: {
        seq: seq,
        work_type : work_type,
        // customer_manager: customer_manager,
        startDay: start_day,
        startTime: start_time,
        endDay: end_day,
        endTime: end_time,
        workname: work_name,
        customerName: customerName,
        customerName2: customerName2,
        forcasting_seq: forcasting_seq,
        maintain_seq: maintain_seq,
        project: project,
        supportMethod: support_method,
        tech_report: tech_report,
        participant: participant,
        contents: contents,
        title: title,
        place: place,
        room_name: room_name,
        car_name: car_name,
        // weekly_report:weekly_report,
        nondisclosure:nondisclosure
      },
      cache:false,
      async:false,
      success: function(result) {
        if (result == "report_written"){
          alert('보고서가 작성된 일정은 수정할 수 없습니다.');
          calendar.refetchEvents();
        }
        if(result == "true"){
          calendarRefresh();
          alert('수정되었습니다.');
          $('#updateSchedule').bPopup().close();
        }
      }
    });


  }

  if(mode == 'report'){
    //KI1 20210125 입력시 빈칸이 있으면 넘어가지 않도록 조건제한
    if($('#de_startDay').val() == ''){
      alert('시작날짜를 입력해주세요.');
      $('#startDay').focus();
      return false;
    }
    if($('#de_endDay').val() == ''){
      alert('종료날짜를 입력해주세요.');
      $('#de_endDay').focus();
      return false;
    }
    if($('#de_workname').val() == ''){
      alert('작업구분을 입력해주세요.');
      $('#de_workname').focus();
      return false;
    }
    if($('#de_supportMethod').val() == ''){
      alert('지원방법을 입력해주세요.');
      $('#de_supportMethod').focus();
      return false;
    }
    if($('#de_customerName').val() == ''){
      alert('고객사를 선택해주세요.');
      $('#de_customerName').focus();
      return false;
    }
    if(($('#de_participant').val() == '') && ($('#de_work_type').val() != 'company')){
      alert('참석자를 선택해주세요.');
      $('#de_participant').focus();
      return false;
    }
    //KI2 20210125
    if (sday==eday){
      var act = "<?php echo site_url();?>/tech/tech_board/tech_doc_input?schedule_seq="+seq;
      $("#de_hiddenSeq").attr('action', act);
      $("#de_hiddenSeq").attr('method', 'POST');
      $("#de_hiddenSeq").submit();
    } else {
      var listDate = [];

  		getDateRange(sday, eday, listDate);

  		var input = '';
  		var btn = '<button type="button" onclick="select_day('+"'"+'input'+"'"+')" style="width:50px;border-radius:5px;" class="basicBtn">선택</button>';

      $.ajax({
        url : "<?php echo site_url(); ?>/biz/schedule/select_report_day",
  			type : "POST",
  			dataType : "json",
  			data : {
  				seq : seq,
        },
        success : function(data) {
          show_day_select();
  				var rep_yn = 'X';
  				for (var i=0; i<listDate.length; i++){
  					for (var j=0; j<data.length; j++){
              if (data[j].end_work_day != null){ //수정 (기지보 일괄작성)
                var work_day_arr = [];
                getDateRange(data[j].income_time, data[j].end_work_day, work_day_arr);
                if($.inArray(listDate[i], work_day_arr)!= -1){
                  rep_yn = 'O';
                  modify_report_seq = data[j].seq;
                }
              } else if (listDate[i]==data[j].income_time) {
  							rep_yn = 'O';
  							modify_report_seq = data[j].seq;
  						}
  					}
  					if (rep_yn=='O'){
              input += '<tr><td height="40" align="center"><input type="checkbox" value="'+listDate[i]+'" name="income_day" style="display:none;"></td>';
  						input += '<td align="center" class="t_border">'+(i+1)+'일차</td>';
              input += '<td align="center" class="t_border" id="income_day">'+listDate[i]+'</td>';
  						input += '<td align="center" class="t_border">O</td></tr>';
  						input += '<tr><td colspan="6" height="1" bgcolor="#e8e8e8"></td></tr>'
  					} else {
              input += '<tr><td height="40" align="center"><input type="checkbox" value="'+listDate[i]+'" name="income_day"></td>';
  						input += '<td align="center" class="t_border">'+(i+1)+'일차</td>';
  						input += '<td align="center" class="t_border" id="income_day">'+listDate[i]+'</td>';
  						input += '<td align="center" class="t_border">X</td></tr>';
  						input += '<tr><td colspan="6" height="1" bgcolor="#e8e8e8"></td></tr>'
  					}
            rep_yn = 'X';
          }
          $('#select_day_body').html(input);
  				$('#select_day_btn').html(btn);
        }
      })
    }
  }

//@@@
  if(mode == 'modify'){
    var schedule_seq = $('#de_seq').val();

    if(sday == eday){
      $.ajax({
        type : "POST",
        url : "<?php echo site_url(); ?>/biz/schedule/tech_seq_find",
        dataType : "json",
        data : {
          schedule_seq : schedule_seq,
          start_day: start_day,
          customer: customerName
        },
        success : function(data){
          var seq = data[0].seq;

          location.href = "<?php echo site_url(); ?>/tech/tech_board/tech_doc_view?mode=view&seq="+seq;
        }
      })
    } else {
      var listDate = [];

  		getDateRange(sday, eday, listDate);

  		var input = '';
  		var btn = '<button type="button" onclick="select_day('+"'"+'modify'+"'"+')" style="width:50px;border-radius:5px;" class="basicBtn">선택</button>';

      $.ajax({
        url : "<?php echo site_url(); ?>/biz/schedule/select_report_day",
        type : "POST",
        dataType : "json",
        data : {
          seq : schedule_seq
        },
        success : function(data) {
          show_day_select();
  				var rep_yn = 'X';
  				var modify_report_seq = '';
  				for (var i=0; i<listDate.length; i++){
  					for (var j=0; j<data.length; j++){
              if (data[j].end_work_day != null){ //수정 (기지보 일괄작성)
                var work_day_arr = [];
                getDateRange(data[j].income_time, data[j].end_work_day, work_day_arr);
                if($.inArray(listDate[i], work_day_arr)!= -1){
                  rep_yn = 'O';
                  modify_report_seq = data[j].seq;
                  if (listDate[i]==work_day_arr[0]){
                    if (work_day_arr.length == 2){
                      var rowspan = 1;
                    } else {
                      var rowspan = 2;
                    }
                    input += '<tr><td height="40" align="center" rowspan="'+(work_day_arr.length+(work_day_arr.length-1))+'"><input type="checkbox" value="'+listDate[i]+'" onclick="checkOnlyOne(this)" name="income_day"></td>';
                  } else {
                    input += '<tr>';
                  }
                }
              } else if (listDate[i]==data[j].income_time) {
  							rep_yn = 'O';
  							modify_report_seq = data[j].seq;
                input += '<tr><td height="40" align="center"><input type="checkbox" value="'+listDate[i]+'" onclick="checkOnlyOne(this)" name="income_day"></td>';
  						}
  					}
            if (rep_yn=='O'){
  						input += '<input type="hidden" id="modify_report_seq" value="'+modify_report_seq+'">';
  						input += '<td height="40" align="center" class="t_border">'+(i+1)+'일차</td>';
  						input += '<td align="center" class="t_border" id="income_day">'+listDate[i]+'</td>';
  						input += '<td align="center" class="t_border">O</td></tr>';
  						input += '<tr><td colspan="6" height="1" bgcolor="#e8e8e8"></td></tr>'
  					} else {
              input += '<tr><td height="40" align="center"></td>';
  						input += '<td align="center" class="t_border">'+(i+1)+'일차</td>';
  						input += '<td align="center" class="t_border" id="income_day">'+listDate[i]+'</td>';
  						input += '<td align="center" class="t_border">X</td></tr>';
  						input += '<tr><td colspan="6" height="1" bgcolor="#e8e8e8"></td></tr>'
  					}
            rep_yn = 'X';
  					modify_report_seq = '';
          }
          $('#select_day_body').html(input);
  				$('#select_day_btn').html(btn);
        }
      })
    }
  }
}

function select_day(type){
	var seq = $("#de_seq").val();
	var income_day = '';
	var end_work_day = '';
	var report_seq = '';
	$("input:checkbox[name=income_day]:checked").each(function(){
		income_day = $(this).val();
		var tr = $(this).closest('tr');
		report_seq = tr.find('input[id=modify_report_seq]').val();
	})

	if(type=='input') {
		if (income_day == ''){
			alert('작성할 보고서의 작업일을 선택하세요.');
		} else {
 //수정 (기지보 일괄작성)
      var income = new Array();
      var income_day_arr = new Array();
      var i=0;
      $("input:checkbox[name=income_day]").each(function(index){
          if($(this).is(":checked")){
              income[i]=index;
              income_day_arr[i] = $(this).val();
              i++;
          }
      });
      if(income.length != 1){
        var temp = income[0];
        for(var k=1; k<income.length; k++){
            if(temp+k != income[k]){
              alert("연속된 일정만 보고서를 한번에 작성 가능합니다.");
              $("input:checkbox[name=income_day]").prop('checked',false);
              // $("input:checkbox[name=income_day]").each(function(){
              //   $(this).checked = false;
              // })
              return false;
            }
        }
      }
      if (income.length>1){
        var income_day = income_day_arr[0];
        var end_work_day = income_day_arr[income_day_arr.length-1];
      }

      var act = "<?php echo site_url();?>/tech/tech_board/tech_doc_input?schedule_seq="+seq+"&income_day="+income_day+"&end_work_day="+end_work_day;
      $("#de_hiddenSeq").attr('action', act);
      $("#de_hiddenSeq").attr('method', 'POST');
      $("#de_hiddenSeq").submit();
		}
	} else if (type=='modify'){
		if (income_day == ''){
			alert('작성할 보고서의 작업일을 선택하세요.');
		} else {
			location.href = "<?php echo site_url(); ?>/tech/tech_board/tech_doc_view?mode=view&seq="+report_seq;
		}
	}
}

function getDateRange(startDate, endDate, listDate){
	var dateMove = new Date(startDate);
	var strDate = startDate;

	if (startDate == endDate) {
		var strDate = dateMove.toISOString().slice(0,10);
		listDate.push(strDate);
	} else {
		while (strDate<endDate){
			var strDate = dateMove.toISOString().slice(0,10);
			listDate.push(strDate);
			dateMove.setDate(dateMove.getDate() + 1);
		}
	}
	return listDate;
}

function checkOnlyOne(el){
	// var checkboxes = document.getElementsByName('income_day');
	$("input:checkbox[name=income_day]:checked").each(function(){
		this.checked = false;
	})
	el.checked = true;
}

$(".select_time_tb tr td[id='room_name_td']").click(function(){
  $('#selected_room_name').val('');
});

//내용분할1
//일정 내용 영역 추가하기
function contents_add_action(mode){
  var length = $("textarea[name=" + mode + "]").length;
  var before_id = mode + "_tr_" + (length-1);
  var after_id = mode + "_tr_" + length;
  var split_mode = mode.split('_');
  if(split_mode.length > 1){
    var mode2 = 'de_';
  }else{
    var mode2 = '';
  }
  // $('#'+before_id).after("<tr id="+ after_id +"><td align='center' bgcolor='f8f8f9' style='font-weight:bold;'></td><td class='t_border' colspan='3' bgcolor='f8f8f9' align='left'><input type='checkbox' class='add_weekly_report' id='" + mode2 + "add_weekly_report_" + length + "' name='" + mode2 + "add_weekly_report' value='' style='vertical-align:middle;width:10%;float:left'><textarea rows='2' name='" + mode + "' id='" + mode + "_" + length + "' placeholder='상세내용' style='resize:none; vertical-align:middle; margin:2px -1.8px;width:70%;float:left'></textarea><input type='hidden' name='" + mode + "_num' id='" + mode + "_num_" + length + "' value='" + length + "'><img src='<?php echo $misc; ?>img/btn_del0.jpg' style='cursor:pointer; vertical-align:middle;float:right' id='" + mode2 + "contents_remove_" + length + "' name='" + mode2 + "contents_remove' onclick='contents_del(" + length + ',' + '"' + mode + '"' + ");return false;'/></td></tr>");
  $('#'+before_id).after("<tr id="+ after_id +"><td align='center' bgcolor='f8f8f9' style='font-weight:bold;'></td><td class='t_border' colspan='3' bgcolor='f8f8f9' align='left'><input type='checkbox' class='add_weekly_report' id='" + mode2 + "add_weekly_report_" + length + "' name='" + mode2 + "add_weekly_report' value='' style='vertical-align:middle;width:10%;float:left'><textarea rows='2' name='" + mode + "' id='" + mode + "_" + length + "' placeholder='상세내용' style='resize:none; vertical-align:middle; margin:2px -1.8px;width:70%;float:left' maxlength='300'></textarea><input type='hidden' name='" + mode + "_num' id='" + mode + "_num_" + length + "' value='" + length + "'><img src='<?php echo $misc; ?>img/btn_del0.jpg' style='cursor:pointer; vertical-align:middle;float:right' id='" + mode2 + "contents_remove_" + length + "' name='" + mode2 + "contents_remove' onclick='contents_del(" + length + ',' + '"' + mode + '"' + ");return false;'/></td></tr>");


}
//내용분할2

<?php
  if($this->agent->is_mobile()){?>
    $("#selectParticipantBtn").remove();
    $("#searchReset").remove();
    $("#excelDownload").remove();
    window.addEventListener('DOMContentLoaded', function(){
    $(".fc-today-button").insertBefore($(".fc-next-button"));
    $(".fc-toolbar-chunk").first().insertAfter($(".fc-view-harness"));
  });
<?php } ?>

</script>
</body>
</html>
