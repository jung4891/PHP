<?php
header("Content-type: text/html; charset=utf-8");

class STC_tech_doc extends CI_Model {

	function __construct() {

		parent::__construct();
//		$this->user_id = $this->phpsession->get( 'id', 'stc' );
	}


	// 고객사 정보 가저오기
	//카테고리 알아오기
	function get_customer() {
		$sql = "select distinct (customer_companyname) as customer, customer_username, exception_saledate2 as maintain_start, exception_saledate3 as maintain_end from sales_forcasting order by binary(customer)";

	//	$sql = "select distinct (customer_companyname) as customer from sales_forcasting order by binary(customer)";
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	// 기술지원보고서 문서번호 카운트 세기
	function tech_doc_num_count( $year = 0 ,$month = 0, $seq = 0 ) {
		if ($seq != 0) {
		
		$searchstring = " where YEAR(income_time) like ? AND MONTH(income_time) like ? AND seq BETWEEN 1 AND ? "; 
		$sql = "select seq from tech_doc_basic".$searchstring;
		$query = $this->db->query( $sql, array($year, $month, $seq-1) );

		}//  수정포인트 -
		if ($seq == 0){
		$searchstring = " where YEAR(income_time) like ? AND MONTH(income_time) like ?"; //  수정포인트 -
		$sql = "select seq from tech_doc_basic".$searchstring;
		$query = $this->db->query( $sql, array($year, $month) );
		}
		return $query->num_rows();
	}

        //기술지원 보고서 파일체크
	function tech_doc_file( $seq, $filelcname){

$sql = "select seq, file_realname, file_changename from tech_doc_basic where seq = ? and file_changename = ?";
                $query = $this->db->query( $sql, array($seq, $filelcname) );
                return $query->row_array();
}
        // 기술지원 보고서 파일삭제
        function tech_doc_filedel($seq) {
                $sql = "update tech_doc_basic set file_changename = ?, file_realname = ? where seq = ?";
                $result = $this->db->query($sql, array(NULL,NULL,$seq));
                return $result;

        }

	//기술지원보고서 리스트
	function tech_doc_list( $searchkeyword, $searchkeyword2, $search1, $start_limit = 0, $offset = 0) {
		$keyword = "%".$searchkeyword."%";
		$keyword2 = "%".$searchkeyword2."%";

		

		if($searchkeyword != "") {
			if($search1 == "001") {
				$searchstring = " where subject like ? "; //  수정포인트 -작업명
			} else if($search1 == "002" ) {
				$searchstring = " where customer like ? "; //  수정포인트 - 고객사
			} else if($search1 == "003" ) {
				$searchstring = " where writer like ? "; //  수정포인트 - 작성자
			} else if($search1 == "004" ) {
				$searchstring = " where income_time like ? "; //  수정포인트 - 작업일
			} else if($search1 == "005" ) {
				if($keyword=="%완료%"){
					$keyword="기술지원 완료%";
				}
				$searchstring = " where result like ? "; //  수정포인트 - 결과
			} else if($search1 == "006" ){
	
			$searchstring = " where produce like ? and version like '$keyword2'";			
			}

		} else {
			$searchstring = "";
		}

		$sql = "select * from tech_doc_basic".$searchstring." order by seq desc"; //  수정포인트

		if  ( $offset <> 0 )
			$sql = $sql." limit ?, ?";

		if  ( $searchkeyword != "" )
			if($searchkeyword2 == ""){
				$query = $this->db->query( $sql, array( $keyword, $start_limit, $offset ) );
			}else{
				$query = $this->db->query( $sql, array( $keyword, $start_limit, $offset ) );
			}
		else
			$query = $this->db->query( $sql, array( $start_limit, $offset ) );

		return array( 'count' => $query->num_rows(), 'data' => $query->result_array() );
	}


	// 기술지원보고서 리스트개수
	function tech_doc_list_count( $searchkeyword,$searchkeyword2, $search1, $start_limit = 0, $offset = 0) {
		$keyword = "%".$searchkeyword."%";
		$keyword2 = "%".$searchkeyword2."%";

		if($searchkeyword != "") {
			if($search1 == "001") {
				$searchstring = " where subject like ? "; //  수정포인트 -작업명
			} else if($search1 == "002" ) {
				$searchstring = " where customer like ? "; //  수정포인트 - 고객사
			} else if($search1 == "003" ) {
				$searchstring = " where writer like ? "; //  수정포인트 - 작성자
			} else if($search1 == "004" ) {
				$searchstring = " where income_time like ? "; //  수정포인트 - 작업일
			} else if($search1 == "005" ) {
				$searchstring = " where result like ? "; //  수정포인트 - 작업일
			} else if($search1 == "006" ) {
			
				$searchstring = " where produce like ? and version like '$keyword2'";
				
			}

		} else {
			$searchstring = "";
		}

		$sql = "select count(seq) as ucount from tech_doc_basic".$searchstring." order by seq desc"; //  수정포인트

		if  ( $searchkeyword != "" ){
			if( $searchkeyword2 == "" ){
				$query = $this->db->query( $sql, $keyword  );
			}else{
				$query = $this->db->query( $sql, $keyword);
			}
		}else{
			$query = $this->db->query( $sql );
		}
		return $query->row();
	}

	function tech_doc_insert( $data, $mode = 0 , $seq = 0) {
		if( $mode == 0 ) {
			return $this->db->insert('tech_doc_basic', $data );
		}
		else {
			//print_r($data);
			return $this->db->update('tech_doc_basic', $data, array('seq' => $seq));
		}
	}

	//	공지사항 뷰내용 가져오기
	function tech_doc_view( $seq  ) {
		$sql = "select * from tech_doc_basic where seq = ?";
		$query = $this->db->query( $sql, $seq );

		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->row_array() ;
		}
	}

	// 삭제
	function tech_doc_delete( $seq ) {
		$sql = "delete from tech_doc_basic where seq = ?";
		$query = $this->db->query( $sql, $seq );

		return	$query;
	}





	//===========================================================

	//Site 장비등록 관린 쿼리
	// db table : sales_forcasting_product
	//
	//
		// 추가및 수정
	function tech_device_insert( $data, $mode , $seq) {

			return $this->db->update('sales_forcasting_product', $data, array('seq' => $seq)) ;

		/*if( $mode == 0 ) {
			//return $this->db->insert('sales_forcasting_product', $data );
		}
		else {
		}*/
	}

	//	공지사항 뷰내용 가져오기
	function tech_device_view( $seq ) {
		$sql = "select * from sales_forcasting as t1 join sales_forcasting_product as t2 join product as t3 on t1.seq=t2.forcasting_seq and t2.product_code=t3.seq where t2.seq = ?";
		$query = $this->db->query( $sql, $seq );

		if ($query->num_rows() <= 0) {
			return false;
		} else {
			return $query->row_array() ;
		}
	}

	// 삭제
	function tech_device_delete( $seq ) {
		$sql = "delete from site_device where seq = ?";
		$query = $this->db->query( $sql, $seq );

		return	$query;
	}

	// 기술지원보고서 리스트
	function tech_device_list( $searchkeyword, $search1, $start_limit = 0, $offset = 0) {
		$keyword = "%".$searchkeyword."%";

		if($searchkeyword != "") {
			if($search1 == "001") {
				$searchstring = " where product_name like ? ";
			} else if($search1 == "002" ) {
				$searchstring = " where customer_companyname like ? ";
			} else if($search1 == "003" ) {
				$searchstring = " where product_serial like ? ";
			}

		} else {
			$searchstring = "";
		}

		//$sql = "select seq, customer, produce, writer, end_date from site_device".$searchstring." order by seq desc";
		$sql = "select t2.seq,customer_companyname,product_version,product_name,product_item,product_serial,product_state from sales_forcasting as t1 join sales_forcasting_product as t2 join product as t3 on t1.seq=t2.forcasting_seq and t2.product_code=t3.seq".$searchstring." order by t1.seq desc";

		if  ( $offset <> 0 )
			$sql = $sql." limit ?, ?";

		if  ( $searchkeyword != "" )
			$query = $this->db->query( $sql, array( $keyword, $start_limit, $offset ) );
			//$query = $this->db->query( $sql, array( $keyword, $start_limit, $offset ) );
		else
			$query = $this->db->query( $sql, array( $start_limit, $offset ) );

		return array( 'count' => $query->num_rows(), 'data' => $query->result_array() );
	}

	// 리스트개수
	function tech_device_list_count($searchkeyword, $search1) {
		$keyword = "%".$searchkeyword."%";

		if($searchkeyword != "") {
			if($search1 == "001") {
				$searchstring = " where product_name like ? ";
			} else if($search1 == "002" ) {
				$searchstring = " where customer_companyname like ? ";
			} else if($search1 == "003" ) {
				$searchstring = " where product_serial like ? ";
			}

		} else {
			$searchstring = "";
		}

		$sql = "select count(*) as ucount from sales_forcasting as t1 join sales_forcasting_product as t2 join product as t3 on t1.seq=t2.forcasting_seq and t2.product_code=t3.seq".$searchstring." order by t1.seq desc";

		if  ( $searchkeyword != "" )
			$query = $this->db->query( $sql, $keyword  );
		else
			$query = $this->db->query( $sql );
		return $query->row();
	}



}
?>
