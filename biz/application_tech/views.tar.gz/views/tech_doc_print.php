<?php
$misc = base_url().'misc/';
$img = $misc.'img/';
$id = $this->phpsession->get( 'id', 'stc' );
$name = $this->phpsession->get( 'name', 'stc' );
$lv = $this->phpsession->get( 'lv', 'stc' );
$email = $this->phpsession->get( 'email', 'stc' ); //김수성 수정-161228//이메일발송용
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?php echo $this->config->item('site_title');?></title>
	<link href="/misc/css/print_doc.css" type="text/css" rel="stylesheet">
	<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
	<script src="/misc/js/m_script.js"></script>
	<script type="text/javascript" src="/misc/js/jquery-ui.min.js"></script>
	<script type="text/javascript" src="/misc/js/jquery.min.js"></script>
	<script type="text/javascript" src="/misc/js/jquery-1.8.3.min"></script>
	<script type="text/javascript" src="/misc/js/common.js"></script>
	<script type="text/javascript" src="/misc/js/jquery.validate.js"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
	<div>

		<table border=0 cellpadding=0 cellspacing=0 width=730 style='border-collapse:
		collapse;table-layout:fixed;width:550pt'>
		<col width=27 span=3 style='mso-width-source:userset;mso-width-alt:864;
		width:20pt'>
		<col width=30 span=5 style='mso-width-source:userset;mso-width-alt:960;
		width:23pt'>
		<col width=21 style='mso-width-source:userset;mso-width-alt:672;width:16pt'>
		<col width=27 span=2 style='mso-width-source:userset;mso-width-alt:864;
		width:20pt'>
		<col width=13 style='mso-width-source:userset;mso-width-alt:416;width:10pt'>
		<col width=30 span=4 style='mso-width-source:userset;mso-width-alt:960;
		width:23pt'>
		<col width=3 style='mso-width-source:userset;mso-width-alt:96;width:2pt'>
		<col width=24 span=2 style='mso-width-source:userset;mso-width-alt:768;
		width:18pt'>
		<col width=35 span=2 style='mso-width-source:userset;mso-width-alt:1120;
		width:26pt'>
		<col width=65 style='mso-width-source:userset;mso-width-alt:2080;width:49pt'>
		<col width=35 span=3 style='mso-width-source:userset;mso-width-alt:1120;
		width:26pt'>
		<tr height=15 style='mso-height-source:userset;height:11.25pt'>
			<td colspan=3 rowspan=2 height=30 class=xl7223169 width=81 style='height:
			22.5pt;width:60pt'><a name="RANGE!A1:Y19">고객명</a></td>
			<td colspan=6 rowspan=2 class=xl7123169 width=171 style='width:131pt'><?php echo $view_val['customer'];?></td>
			<td colspan=3 rowspan=2 class=xl7223169 width=67 style='width:50pt'>작업명</td>
			<td colspan=5 rowspan=2 class=xl7123169 width=123 style='width:94pt'><?php echo $view_val['work_name'];?></td>
			<td colspan=2 rowspan=2 class=xl7123169 width=48 style='width:36pt'>고객사</td>
			<td colspan=3 rowspan=2 class=xl7123169 width=135 style='width:101pt'><?php echo $view_val['customer'];?></td>
			<td colspan=3 rowspan=2 class=xl7123169 width=105 style='width:78pt'>두리안정보기술</td>
		</tr>
		<tr height=15 style='mso-height-source:userset;height:11.25pt'>
		</tr>
		<tr height=14 style='mso-height-source:userset;height:10.5pt'>
			<td colspan=3 rowspan=2 height=28 class=xl7223169 style='height:21.0pt'>문서번호</td>
			<td colspan=6 rowspan=2 class=xl7123169><?php echo $view_val['doc_num'];?></td>
			<td colspan=3 rowspan=2 class=xl7223169>작성자</td>
			<td colspan=5 rowspan=2 class=xl7123169><?php echo $view_val['writer'];?></td>
			<td colspan=2 rowspan=4 class=xl7123169>확인</td>
			<td colspan=3 rowspan=4 class=xl7123169>　</td>
			<td colspan=3 rowspan=4 class=xl7123169>　</td>
		</tr>
		<tr height=14 style='mso-height-source:userset;height:10.5pt'>
		</tr>
		<tr height=14 style='mso-height-source:userset;height:10.5pt'>
			<td colspan=3 rowspan=2 height=28 class=xl7223169 style='height:21.0pt'>개정버전</td>
			<td colspan=6 rowspan=2 class=xl7123169>V1.0</td>
			<td colspan=3 rowspan=2 class=xl7223169>날짜</td>
			<td colspan=5 rowspan=2 class=xl7323169><?php echo substr($view_val['income_time'], 0, 10);?></td>
		</tr>
		<tr height=14 style='mso-height-source:userset;height:10.5pt'>
		</tr>
		<tr height=29 style='mso-height-source:userset;height:21.75pt'>
			<td height=29 class=xl6323169 style='height:21.75pt'></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
			<td class=xl6323169></td>
		</tr>
		<tr height=22 style='mso-height-source:userset;height:16.5pt'>
			<td colspan=25 rowspan=2 height=44 class=xl7423169 style='border-right:1.0pt solid black;
			border-bottom:1.0pt solid black;height:33.0pt'>기술지원보고서</td>
		</tr>
		<tr height=22 style='mso-height-source:userset;height:16.5pt'>
		</tr>
		<tr height=14 style='mso-height-source:userset;height:10.5pt'>
			<td height=14 class=xl1523169 style='height:10.5pt'></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
			<td class=xl1523169></td>
		</tr>
		<tr height=22 style='height:16.5pt'>
			<td colspan=4 height=22 class=xl6723169 style='height:16.5pt'>고객명</td>
			<td colspan=9 class=xl6723169 style='border-left:none'><?php echo $view_val['customer'];?></td>
			<td colspan=3 class=xl6723169 style='border-left:none'>담당자명</td>
			<td colspan=9 class=xl6723169 style='border-left:none'><?php echo $view_val['customer_manager'];?></td>
		</tr>

<?php if($view_val['work_name']=="장애지원"){?>
              <tr height=22 style='height:16.5pt'>
                <td colspan=4 height="22" class=xl6723169 style='height:16.5pt'>장애구분</td>
                <td colspan=9 class=xl6723169 style='border-left:none'><?php echo $view_val['err_type'];?></td>
                <td colspan=3 class=xl6723169 style='border-left:none'>심각도</td>
                <td colspan=9 class=xl6723169 style='border-left:none'><?php 
					switch($view_val['warn_level']){
						case '001': echo "전체서비스중단";break;
						case '002': echo "일부서비스중단/서비스지연";break;
						case '003': echo "관리자불편/대고객신뢰도저하";break;
						case '004': echo "특정기능장애";break;
						case '005': echo "서비스무관단순장애";break;
					}?></td>
              </tr>
              <tr height=22 style='height:16.5pt'>
                <td colspan=4 height="22" class=xl6723169 style='height:16.5pt'>장애유형</td>
                <td colspan=9 class=xl6723169 style='border-left:none'><?php
					switch($view_val['warn_type']){
                                                case '001': echo "파워불량";break;
                                                case '002': echo "하드웨어결함";break;
                                                case '003': echo "인터페이스불량";break;
                                                case '004': echo "DISK 불량";break;
                                                case '005': echo "LED 불량";break;
                                                case '006': echo "FAN 불량";break;
                                                case '007': echo "하드웨어 소음";break;
                                                case '008': echo "설정 오류";break;
                                                case '009': echo "고객 과실";break;
                                                case '010': echo "기능 버그";break;
                                                case '011': echo "OS 오류";break;
                                                case '012': echo "펌웨어 오류";break;
                                                case '013': echo "타사제품문제";break;
                                                case '014': echo "호환문제";break;
                                                case '015': echo "시스템부하";break;
                                                case '016': echo "PC문제";break;
                                                case '017': echo "원인불명";break;
                                                case '018': echo "기타오류";break;
					}?></td>
                <td colspan=3 class=xl6723169 style='border-left:none'>장애처리방법</td>
                <td colspan=9 class=xl6723169 style='border-left:none'><?php
					switch($view_val['work_action']){
						case '001': echo "기술지원";break;
						case '002': echo "설정지원";break;
						case '003': echo "장비교체";break;
						case '004': echo "업그레이드";break;
						case '005': echo "패치";break;
						case '006': echo "협의중";break;
					}
				}?></td>
              </tr>


		<tr height=22 style='height:16.5pt'>
			<td colspan=4 height=22 class=xl6623169 style='height:16.5pt'>날짜</td>
			<td colspan=9 class=xl6823169 style='border-left:none'><?php echo substr($view_val['income_time'], 0, 10);?></td>
			<td colspan=3 class=xl6423169 style='border-left:none'>투입시간</td>
			<td colspan=9 class=xl6523169 style='border-left:none'><?php echo substr($view_val['total_time'],0,5);?></td>
		</tr>
		<tr height=22 style='height:16.5pt'>
			<td colspan=4 height=22 class=xl6723169 style='height:16.5pt'>시작시간</td>
			<td colspan=9 class=xl7023169 style='border-left:none'><?php echo substr($view_val['start_time'],0,5);?></td>
			<td colspan=3 class=xl6923169 style='border-left:none'>종료시간</td>
			<td colspan=9 class=xl7023169 style='border-left:none'><?php echo substr($view_val['end_time'],0,5);?></td>
		</tr>
		<tr height=22 style='height:16.5pt'>
			<td colspan=4 height=22 class=xl6723169 style='height:16.5pt'>담당SE</td>
			<td colspan=9 class=xl6723169 style='border-left:none'><?php echo $view_val['engineer'];?></td>
			<td colspan=3 class=xl6723169 style='border-left:none'>지원방법</td>
			<td colspan=9 class=xl6723169 style='border-left:none'><?php echo $view_val['handle'];?></td>
		</tr>
		<tr height=37 style='mso-height-source:userset;'>
			<td colspan=4 rowspan=2 height=74 class=xl6723169 >지원
				시스템
			</td>
			<td colspan=3 class=xl6723169 style='border-left:none'>제품명</td>
			<td colspan=6 class=xl8823169 width=148 style='border-left:none;width:112pt'>
				<?php
				$tmp1 = explode(",", $view_val['produce']);
				for($i=0;$i<=count($tmp1)-1;$i++) 
					echo $tmp1[$i]."<br />";
					?>						</td>
			<td colspan=3 class=xl6723169 style='border-left:none'>버전정보</td>
			<td colspan=9 class=xl6723169 style='border-left:none'>
				<?php
				$tmp1 = explode(",", $view_val['version']);
				for($i=0;$i<=count($tmp1)-1;$i++) 
					echo $tmp1[$i]."<br />";
					?>				
			</td>
		</tr>
		<tr height=37 style='mso-height-source:userset;'>
			<td colspan=3 height=37 class=xl6723169 style='border-left:none'>서버</td>
			<td colspan=6 class=xl6723169 style='border-left:none'>
				<?php
				$tmp1 = explode(",", $view_val['hardware']);
				for($i=0;$i<=count($tmp1)-1;$i++) echo $tmp1[$i]."<br />";
					?>				
			</td>
			<td colspan=3 class=xl6723169 style='border-left:none'>라이선스</td>
			<td colspan=9 class=xl6723169 style='border-left:none'>
				<?php
				$tmp1 = explode(",", $view_val['license']);
				for($i=0;$i<=count($tmp1)-1;$i++) echo $tmp1[$i]."<br />";
					?>				
			</td>
		</tr>
		<tr height=28 style='mso-height-source:userset;height:21.0pt'>
			<td colspan=4 height=28 class=xl6723169 style='height:21.0pt'>회의주제</td>
			<td colspan=21 class=xl9323169 style='border-left:none'><?php echo $view_val['subject'];?></td>
		</tr>
		<tr height=22 style='height:16.5pt'>
			<td colspan=4 height=22 class=xl8023169 style='border-right:.5pt solid black;
			height:16.5pt'>시간</td>
			<td colspan=21 class=xl8923169 style='font-weight: 700px; border-right:.5pt solid black;
			border-left:none'>지원 내역</td>
		</tr>
		<?php
		$tmp = explode(";;", $view_val['work_process_time']);
		$process_txt =  explode(";;", $view_val['work_process']);

		for($i=0;$i<count($tmp)-1;$i++){

			$time = explode("-",$tmp[$i]);

			?>

			<tr height=90 style='mso-height-source:userset;min-height:67.5pt'>
				<td colspan=2 height=90 class=xl6523169 style='min-height:67.5pt'><?php echo $time[0];?></td>
				<td colspan=2 class=xl6523169 style='border-left:none'><?php echo $time[1];?></td>
				<td colspan=21 class=xl8523169 width=619 style='border-right:.5pt solid black;
				border-left:none;width:467pt'><?php echo $process_txt[$i];?></td>
			</tr>

			<?php
		}

		?>





			<!-- 반복 구간 

/*
			<tr height=90 style='mso-height-source:userset;height:67.5pt'>
				<td colspan=2 height=90 class=xl6523169 style='height:67.5pt'><?php echo $view_val['work_process_time'];?></td>
				<td colspan=2 class=xl6523169 style='border-left:none'><?php echo $view_val['work_process_time'];?></td>
				<td colspan=21 class=xl8523169 width=619 style='border-right:.5pt solid black;
				border-left:none;width:467pt'><?php echo $view_val['work_process'];?>
			</td>
		</tr>
		반복 구간 -->
		<tr height=55 style='mso-height-source:userset;min-height:41.25pt'>
			<td colspan=4 height=55 class=xl8023169 style='min-height:41.25pt'>지원의견</td>
			<td colspan=21 class=xl8223169 width=619 style='border-right:.5pt solid black;
			width:467pt'><?php echo $view_val['comment'];?></td>
		</tr>
		<tr height=55 style='mso-height-source:userset;min-height:41.25pt'>
			<td colspan=4 height=55 class=xl8023169 style='min-height:41.25pt'>지원결과</td>
			<td colspan=21 class=xl8223169 width=619 style='border-right:.5pt solid black;
			width:467pt'><?php echo $view_val['result'];?></td>
		</tr>

	</table>

</div>



</body>
</html>
