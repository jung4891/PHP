<?php
        include $this->input->server('DOCUMENT_ROOT')."/include/base.php";
        include $this->input->server('DOCUMENT_ROOT')."/include/customer_top.php";
  // tech_device_list 김수성
?>
<body>
<form>
            <table width="890" border="0" style="margin-top:20px;">
              <tr>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td colspan="5" height="2" bgcolor="#797c88"></td>
                  </tr>
                  <tr bgcolor="f8f8f9" class="t_top">
                    <td width="5%" height="40" align="center" class="t_border">선택</td>
                    <td width="15%" align="center" class="t_border">담당자</td>
                    <td width="15%" align="center" class="t_border">유지보수만료일</td>
                  </tr>
                 <?php

                        foreach($input as $entry){

?>
                 <tr bgcolor="f8f8f9" class="t_top">

                    <td width="5%" align="center" class="t_border"><input type="checkbox" name="check"></td>
                    <td width="15%" align="center" class="t_border"><input type="hidden" name="customer_username"  value="<?php echo $entry->customer_username?>"><?php echo $entry->customer_username;?></td>
                    <td width="15%" align="center" class="t_border"><input type="text" name="maintain_end"  value="<?php echo $entry->exception_saledate3?>"><?php echo $entry->exception_saledate3;?></td>
                  </tr>
<?php
                        }
                ?>

                  <tr>
                    <td colspan="5" height="1" bgcolor="#797c88"></td>
                  </tr>
              <tr>
                <td height="10"></td>
              </tr>
              <tr>
                <td align="right"><input type='submit' name="check" value='선택' onclick="submitCharge();"></td>
              </tr>
            </table>
</form>
</body>
</html>

<script>
window.onload = function(){

	submitCharge();

}


function submitCharge(){
        len = document.getElementsByName('check').length;
        total_customer_username="";
        total_maintain_end="";

        total_customer_username += document.getElementsByName('customer_username')[0].value;
        total_maintain_end += document.getElementsByName('maintain_end')[0].value;

var now = new Date();
var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

var tmp_date = total_maintain_end.split("-");
var maintain_end = new Date(tmp_date[1]+"/"+tmp_date[2]+"/"+tmp_date[0]);

if(total_maintain_end.length==0){
	alert("유지보수 만료일이 설정되지 않았습니다. 설정 후 이용해 주세요.");
	opener.document.cform.customer.selectedIndex = 0;

}else{

	if(today.getTime() > maintain_end.getTime()){
		alert("고객사 유지보수 기간이 "+tmp_date[0]+"년 "+tmp_date[1]+"월 " + tmp_date[2]+"부로 종료 되었습니다. 영업 부서에 확인 후 이용바랍니다.");
		opener.document.cform.customer.selectedIndex = 0;
	}else{
		alert("고객사 유지보수 기간은 "+tmp_date[0]+"년 "+tmp_date[1]+"월 " + tmp_date[2]+"일 까지 입니다.");
	}
}
opener.document.cform.customer_manager.value=total_customer_username;

self.close();
}
</script>


