<link href="/devmail/misc/css/sidebar.css" type="text/css" rel="stylesheet">

<div id="main">
    <div id="sideBar">
      <div class="">
        <ul>
          <a href="<?php echo site_url(); ?>/admin/manager/adminlist"><img src="<?php echo $misc;?>img/icon/schedule.svg" width="20">관리자</a>
        </ul>

        <ul>
          <a href="<?php echo site_url(); ?>/admin/mailbox/mail_list"><img src="<?php echo $misc;?>img/icon/schedule.svg" width="20"> 메일박스</a>
        </ul>

        <ul>
          <a href="<?php echo site_url(); ?>/admin/alias/alias_list"><img src="<?php echo $misc;?>img/icon/schedule.svg" width="20"> 그룹메일</a>
        </ul>
        <ul>
          <a href="<?php echo site_url(); ?>/admin/main/viewlog"><img src="<?php echo $misc;?>img/icon/schedule.svg" width="20"> 로그</a>
        </ul>
      </div>
    </div>
    <div id="sideMini">
aa
    </div>
