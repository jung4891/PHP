<?php
// if(!isset($_SESSION)){
//     session_start();
// }
$misc = base_url().'misc/';
$img = $misc.'img/';
// $id = $_SESSION['userid'];
// $roles = $_SESSION['roles'];
// $domain = $_SESSION['domain'];
?>
